import { $ as e, A as t, B as n, C as r, D as i, E as a, F as o, G as s, H as c, I as l, J as u, K as d, L as f, M as p, N as m, O as h, P as g, Q as _, R as v, T as y, U as b, V as x, W as S, X as C, Y as w, Z as T, _ as E, a as ee, b as D, c as O, d as k, et as A, f as j, g as te, h as M, i as ne, j as re, k as N, l as ie, m as ae, n as P, nt as F, o as I, p as oe, q as L, r as se, rt as ce, s as R, t as le, tt as z, u as ue, v as B, x as V, y as H, z as U } from "./index-client-wMK2iX6C.js";
//#region frontend/node_modules/@gradio/theme/dist/src/colors.js
var de = [
	{
		color: "red",
		primary: 600,
		secondary: 100
	},
	{
		color: "green",
		primary: 600,
		secondary: 100
	},
	{
		color: "blue",
		primary: 600,
		secondary: 100
	},
	{
		color: "yellow",
		primary: 500,
		secondary: 100
	},
	{
		color: "purple",
		primary: 600,
		secondary: 100
	},
	{
		color: "teal",
		primary: 600,
		secondary: 100
	},
	{
		color: "orange",
		primary: 600,
		secondary: 100
	},
	{
		color: "cyan",
		primary: 600,
		secondary: 100
	},
	{
		color: "lime",
		primary: 500,
		secondary: 100
	},
	{
		color: "pink",
		primary: 600,
		secondary: 100
	}
], W = {
	inherit: "inherit",
	current: "currentColor",
	transparent: "transparent",
	black: "#000",
	white: "#fff",
	slate: {
		50: "#f8fafc",
		100: "#f1f5f9",
		200: "#e2e8f0",
		300: "#cbd5e1",
		400: "#94a3b8",
		500: "#64748b",
		600: "#475569",
		700: "#334155",
		800: "#1e293b",
		900: "#0f172a",
		950: "#020617"
	},
	gray: {
		50: "#f9fafb",
		100: "#f3f4f6",
		200: "#e5e7eb",
		300: "#d1d5db",
		400: "#9ca3af",
		500: "#6b7280",
		600: "#4b5563",
		700: "#374151",
		800: "#1f2937",
		900: "#111827",
		950: "#030712"
	},
	zinc: {
		50: "#fafafa",
		100: "#f4f4f5",
		200: "#e4e4e7",
		300: "#d4d4d8",
		400: "#a1a1aa",
		500: "#71717a",
		600: "#52525b",
		700: "#3f3f46",
		800: "#27272a",
		900: "#18181b",
		950: "#09090b"
	},
	neutral: {
		50: "#fafafa",
		100: "#f5f5f5",
		200: "#e5e5e5",
		300: "#d4d4d4",
		400: "#a3a3a3",
		500: "#737373",
		600: "#525252",
		700: "#404040",
		800: "#262626",
		900: "#171717",
		950: "#0a0a0a"
	},
	stone: {
		50: "#fafaf9",
		100: "#f5f5f4",
		200: "#e7e5e4",
		300: "#d6d3d1",
		400: "#a8a29e",
		500: "#78716c",
		600: "#57534e",
		700: "#44403c",
		800: "#292524",
		900: "#1c1917",
		950: "#0c0a09"
	},
	red: {
		50: "#fef2f2",
		100: "#fee2e2",
		200: "#fecaca",
		300: "#fca5a5",
		400: "#f87171",
		500: "#ef4444",
		600: "#dc2626",
		700: "#b91c1c",
		800: "#991b1b",
		900: "#7f1d1d",
		950: "#450a0a"
	},
	orange: {
		50: "#fff7ed",
		100: "#ffedd5",
		200: "#fed7aa",
		300: "#fdba74",
		400: "#fb923c",
		500: "#f97316",
		600: "#ea580c",
		700: "#c2410c",
		800: "#9a3412",
		900: "#7c2d12",
		950: "#431407"
	},
	amber: {
		50: "#fffbeb",
		100: "#fef3c7",
		200: "#fde68a",
		300: "#fcd34d",
		400: "#fbbf24",
		500: "#f59e0b",
		600: "#d97706",
		700: "#b45309",
		800: "#92400e",
		900: "#78350f",
		950: "#451a03"
	},
	yellow: {
		50: "#fefce8",
		100: "#fef9c3",
		200: "#fef08a",
		300: "#fde047",
		400: "#facc15",
		500: "#eab308",
		600: "#ca8a04",
		700: "#a16207",
		800: "#854d0e",
		900: "#713f12",
		950: "#422006"
	},
	lime: {
		50: "#f7fee7",
		100: "#ecfccb",
		200: "#d9f99d",
		300: "#bef264",
		400: "#a3e635",
		500: "#84cc16",
		600: "#65a30d",
		700: "#4d7c0f",
		800: "#3f6212",
		900: "#365314",
		950: "#1a2e05"
	},
	green: {
		50: "#f0fdf4",
		100: "#dcfce7",
		200: "#bbf7d0",
		300: "#86efac",
		400: "#4ade80",
		500: "#22c55e",
		600: "#16a34a",
		700: "#15803d",
		800: "#166534",
		900: "#14532d",
		950: "#052e16"
	},
	emerald: {
		50: "#ecfdf5",
		100: "#d1fae5",
		200: "#a7f3d0",
		300: "#6ee7b7",
		400: "#34d399",
		500: "#10b981",
		600: "#059669",
		700: "#047857",
		800: "#065f46",
		900: "#064e3b",
		950: "#022c22"
	},
	teal: {
		50: "#f0fdfa",
		100: "#ccfbf1",
		200: "#99f6e4",
		300: "#5eead4",
		400: "#2dd4bf",
		500: "#14b8a6",
		600: "#0d9488",
		700: "#0f766e",
		800: "#115e59",
		900: "#134e4a",
		950: "#042f2e"
	},
	cyan: {
		50: "#ecfeff",
		100: "#cffafe",
		200: "#a5f3fc",
		300: "#67e8f9",
		400: "#22d3ee",
		500: "#06b6d4",
		600: "#0891b2",
		700: "#0e7490",
		800: "#155e75",
		900: "#164e63",
		950: "#083344"
	},
	sky: {
		50: "#f0f9ff",
		100: "#e0f2fe",
		200: "#bae6fd",
		300: "#7dd3fc",
		400: "#38bdf8",
		500: "#0ea5e9",
		600: "#0284c7",
		700: "#0369a1",
		800: "#075985",
		900: "#0c4a6e",
		950: "#082f49"
	},
	blue: {
		50: "#eff6ff",
		100: "#dbeafe",
		200: "#bfdbfe",
		300: "#93c5fd",
		400: "#60a5fa",
		500: "#3b82f6",
		600: "#2563eb",
		700: "#1d4ed8",
		800: "#1e40af",
		900: "#1e3a8a",
		950: "#172554"
	},
	indigo: {
		50: "#eef2ff",
		100: "#e0e7ff",
		200: "#c7d2fe",
		300: "#a5b4fc",
		400: "#818cf8",
		500: "#6366f1",
		600: "#4f46e5",
		700: "#4338ca",
		800: "#3730a3",
		900: "#312e81",
		950: "#1e1b4b"
	},
	violet: {
		50: "#f5f3ff",
		100: "#ede9fe",
		200: "#ddd6fe",
		300: "#c4b5fd",
		400: "#a78bfa",
		500: "#8b5cf6",
		600: "#7c3aed",
		700: "#6d28d9",
		800: "#5b21b6",
		900: "#4c1d95",
		950: "#2e1065"
	},
	purple: {
		50: "#faf5ff",
		100: "#f3e8ff",
		200: "#e9d5ff",
		300: "#d8b4fe",
		400: "#c084fc",
		500: "#a855f7",
		600: "#9333ea",
		700: "#7e22ce",
		800: "#6b21a8",
		900: "#581c87",
		950: "#3b0764"
	},
	fuchsia: {
		50: "#fdf4ff",
		100: "#fae8ff",
		200: "#f5d0fe",
		300: "#f0abfc",
		400: "#e879f9",
		500: "#d946ef",
		600: "#c026d3",
		700: "#a21caf",
		800: "#86198f",
		900: "#701a75",
		950: "#4a044e"
	},
	pink: {
		50: "#fdf2f8",
		100: "#fce7f3",
		200: "#fbcfe8",
		300: "#f9a8d4",
		400: "#f472b6",
		500: "#ec4899",
		600: "#db2777",
		700: "#be185d",
		800: "#9d174d",
		900: "#831843",
		950: "#500724"
	},
	rose: {
		50: "#fff1f2",
		100: "#ffe4e6",
		200: "#fecdd3",
		300: "#fda4af",
		400: "#fb7185",
		500: "#f43f5e",
		600: "#e11d48",
		700: "#be123c",
		800: "#9f1239",
		900: "#881337",
		950: "#4c0519"
	}
};
de.reduce((e, { color: t, primary: n, secondary: r }) => ({
	...e,
	[t]: {
		primary: W[t][n],
		secondary: W[t][r]
	}
}), {});
//#endregion
//#region frontend/node_modules/svelte/src/store/index-client.js
function G(e) {
	let t, n = w((n) => {
		let r = !1, i = e.subscribe((e) => {
			t = e, r && n();
		});
		return r = !0, i;
	});
	function r() {
		return o() ? (n(), t) : C(e);
	}
	return "set" in e ? {
		get current() {
			return r();
		},
		set current(t) {
			e.set(t);
		}
	} : { get current() {
		return r();
	} };
}
var K = [
	"label",
	"info",
	"placeholder",
	"description",
	"title",
	"value"
], fe = /* @__PURE__ */ "elem_id.elem_classes.visible.interactive.server_fns.server.id.target.theme_mode.version.root.autoscroll.max_file_size.formatter.client.load_component.scale.min_width.theme.padding.loading_status.label.show_label.validation_error.show_progress.api_prefix.container.attached_events.register_component.unregister_component.dispatcher".split(".");
function pe(e) {
	return typeof e == "string" && e.includes("__i18n__");
}
var me = class {
	load_component;
	#e = L(b({}));
	get shared() {
		return m(this.#e);
	}
	set shared(e) {
		d(this.#e, e, !0);
	}
	#t = L(b({}));
	get props() {
		return m(this.#t);
	}
	set props(e) {
		d(this.#t, e, !0);
	}
	#n = L((e) => e);
	get i18n() {
		return m(this.#n);
	}
	set i18n(e) {
		d(this.#n, e, !0);
	}
	i18n_store;
	_i18n_from_store;
	translatable_props = {};
	dispatcher;
	last_update = null;
	shared_props = fe;
	mounted = !1;
	old_value;
	register_component;
	unregister_component;
	set_data_callback;
	get_data_callback;
	registered_id = null;
	last_shared_props;
	last_props;
	constructor(e, t) {
		for (let t in e.shared_props) this.shared[t] = e.shared_props[t];
		for (let t in e.props) t !== "i18n_store" && (this.props[t] = e.props[t]);
		if (t) for (let e in t) this.props[e] === void 0 && (this.props[e] = t[e]);
		this.i18n = this.props.i18n ?? ((e) => e), this.i18n_store = e.props.i18n_store, this._i18n_from_store = this.i18n_store ? G(this.i18n_store) : void 0;
		for (let t of K) this.shared[t] = this._translate_and_store("shared", t, e.shared_props[t]), this.props[t] = this._translate_and_store("props", t, e.props[t]);
		this.load_component = this.shared.load_component, this.register_component = this.shared.register_component || (() => {}), this.unregister_component = this.shared.unregister_component || (() => {}), this.dispatcher = this.shared.dispatcher || (() => {}), this.set_data_callback = this.set_data.bind(this), this.get_data_callback = this.get_data.bind(this), this.register_component(this.shared.id, this.set_data_callback, this.get_data_callback), this.registered_id = this.shared.id, this.last_shared_props = e.shared_props, this.last_props = e.props, U(() => {
			let t = e.shared_props.id;
			if (this.last_shared_props !== e.shared_props) {
				for (let t in e.shared_props) {
					let n = e.shared_props[t];
					n !== void 0 && (this._is_i18n_managed(`shared.${t}`, n) || (this.shared[t] = n));
				}
				this.last_shared_props = e.shared_props;
			}
			if (this.last_props !== e.props) {
				for (let t in e.props) {
					if (t === "i18n_store") continue;
					let n = e.props[t];
					n !== void 0 && (this._is_i18n_managed(`props.${t}`, n) || (this.props[t] = n));
				}
				this.last_props = e.props;
			}
			this.registered_id !== null && this.registered_id !== t && this.unregister_component(this.registered_id, this.set_data_callback), this.register_component(t, this.set_data_callback, this.get_data_callback), this.registered_id = t, g(() => {
				this.shared.id = t;
			});
		}), U(() => () => {
			this.registered_id !== null && this.unregister_component(this.registered_id, this.set_data_callback);
		}), U(() => {
			if (this.i18n_store) return this.i18n_store.subscribe(() => {
				for (let [e, t] of Object.entries(this.translatable_props)) {
					let [n, r] = e.split("."), i = this.i18n(t);
					n === "shared" ? this.shared[r] = i : this.props[r] = i;
				}
			});
		});
	}
	_is_i18n_managed(e, t) {
		let n = this.translatable_props[e];
		return n ? t === n || (delete this.translatable_props[e], !1) : !1;
	}
	_translate_and_store(e, t, n) {
		if (typeof n != "string") return n;
		let r = this.i18n(n);
		return r !== n && (this.translatable_props[`${e}.${t}`] = n), r;
	}
	live_i18n = (e) => (this._i18n_from_store?.current, this.i18n(e));
	dispatch(e, t) {
		this.dispatcher(this.shared.id, e, t);
	}
	async get_data() {
		return e(this.props);
	}
	update(e) {
		this.set_data(e);
	}
	set_data(e) {
		for (let t in e) {
			let n = e[t], r = pe(n) ? this._translate_and_store(this.shared_props.includes(t) ? "shared" : "props", t, n) : n;
			if (this.shared_props.includes(t)) {
				let e = t;
				this.shared[e] = r;
				continue;
			}
			this.props[t] = r;
		}
	}
	watch_for_change() {
		U(() => {
			this.mounted ||= (this.old_value = this.props.value, !0), this.old_value != this.props.value && (this.old_value = this.props.value, this.dispatch("change"));
		});
	}
};
//#endregion
//#region frontend/node_modules/svelte/src/internal/flags/legacy.js
A();
//#endregion
//#region frontend/node_modules/@gradio/atoms/dist/src/Block.svelte
var he = h("<svg class=\"resize-handle svelte-1stq1b1\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 10 10\"><line x1=\"1\" y1=\"9\" x2=\"9\" y2=\"1\" stroke=\"gray\" stroke-width=\"0.5\" class=\"svelte-1stq1b1\"></line><line x1=\"5\" y1=\"9\" x2=\"9\" y2=\"5\" stroke=\"gray\" stroke-width=\"0.5\" class=\"svelte-1stq1b1\"></line></svg>"), ge = i("<!> <!>", 1), _e = i("<div class=\"placeholder svelte-1stq1b1\"></div>");
function ve(e, t) {
	_(t, !1);
	let n = P(t, "height", 8, void 0), r = P(t, "min_height", 8, void 0), i = P(t, "max_height", 8, void 0), o = P(t, "width", 8, void 0), u = P(t, "elem_id", 8, ""), h = P(t, "elem_classes", 24, () => []), b = P(t, "variant", 8, "solid"), C = P(t, "border_mode", 8, "base"), w = P(t, "padding", 8, !0), D = P(t, "type", 8, "normal"), k = P(t, "test_id", 8, void 0), A = P(t, "explicit_call", 8, !1), j = P(t, "container", 8, !0), M = P(t, "visible", 8, !0), N = P(t, "allow_overflow", 8, !0), F = P(t, "overflow_behavior", 8, "auto"), I = P(t, "scale", 8, null), oe = P(t, "min_width", 8, 0), L = P(t, "flex", 12, !1), se = P(t, "resizable", 8, !1), ce = P(t, "rtl", 8, !1), R = P(t, "fullscreen", 12, !1), le = P(t, "label", 8, void 0), z = S(R()), B = S(), H = D() === "fieldset" ? "fieldset" : "div", U = S(0), de = S(0), W = S(null), G = null, K = null;
	function fe(e) {
		R() && e.key === "Escape" && R(!1);
	}
	function pe() {
		let e = m(B).getRootNode();
		return m(B).closest(".gradio-container") ?? (e instanceof ShadowRoot ? e : document.body);
	}
	function me(e) {
		let t = document.createElement("div");
		t.style.cssText = "position: fixed; top: 0; left: 0; width: 100%; height: 100%; visibility: hidden; pointer-events: none;", e.appendChild(t);
		let n = t.getBoundingClientRect();
		return t.remove(), n;
	}
	function ve(e) {
		let t = m(B).parentNode;
		if (!t || t === e) return !1;
		let n = me(t), r = me(e);
		return Math.abs(n.top - r.top) > 1 || Math.abs(n.left - r.left) > 1 || Math.abs(n.width - r.width) > 1 || Math.abs(n.height - r.height) > 1;
	}
	function q(e) {
		!m(B).parentNode || m(B).parentNode === e || (G = m(B).parentNode, K = document.createComment("fullscreen block"), G.insertBefore(K, m(B)), e.appendChild(m(B)));
	}
	function J() {
		if (!G) return;
		let e = K && K.parentNode === G ? K : null;
		G.insertBefore(m(B), e), e?.remove(), G = null, K = null;
	}
	let Y = (e) => {
		if (e !== void 0) {
			if (typeof e == "number") return e + "px";
			if (typeof e == "string") return e;
		}
	}, X = (e) => {
		let t = e.clientY, n = (e) => {
			let n = e.clientY - t;
			t = e.clientY, s(B, m(B).style.height = `${m(B).offsetHeight + n}px`);
		}, r = () => {
			window.removeEventListener("mousemove", n), window.removeEventListener("mouseup", r);
		};
		window.addEventListener("mousemove", n), window.addEventListener("mouseup", r);
	};
	l(() => (p(R()), m(z), m(B)), () => {
		if (R() !== m(z)) {
			if (d(z, R()), R()) {
				d(W, m(B).getBoundingClientRect()), d(U, m(B).offsetHeight), d(de, m(B).offsetWidth);
				let e = pe();
				ve(e) && q(e), window.addEventListener("keydown", fe);
			} else J(), d(W, null), window.removeEventListener("keydown", fe);
		}
	}), l(() => p(M()), () => {
		M() || L(!1);
	}), f(), ne();
	var Z = a(), ye = x(Z), be = (e) => {
		var a = ge(), s = x(a);
		te(s, () => H, !1, (e, a) => {
			ee(e, (e) => d(B, e), () => m(B)), ue(e, (e, t) => ({
				"data-testid": k(),
				id: u(),
				class: `block ${e ?? ""}`,
				dir: ce() ? "rtl" : "ltr",
				"aria-label": le(),
				style: "",
				[O]: {
					hidden: M() === "hidden",
					padded: w(),
					flex: L(),
					border_focus: C() === "focus",
					border_contrast: C() === "contrast",
					"hide-container": !A() && !j(),
					fullscreen: R(),
					animating: R() && m(W) !== null,
					"auto-margin": I() === null
				},
				[ie]: t
			}), [() => (p(h()), g(() => h()?.join(" ") || "")), () => ({
				height: (p(R()), p(n()), g(() => R() ? void 0 : Y(n()))),
				"min-height": (p(R()), p(r()), g(() => R() ? void 0 : Y(r()))),
				"max-height": (p(R()), p(i()), g(() => R() ? void 0 : Y(i()))),
				"--start-top": (m(W), g(() => m(W) ? `${m(W).top}px` : "0px")),
				"--start-left": (m(W), g(() => m(W) ? `${m(W).left}px` : "0px")),
				"--start-width": (m(W), g(() => m(W) ? `${m(W).width}px` : "0px")),
				"--start-height": (m(W), g(() => m(W) ? `${m(W).height}px` : "0px")),
				width: (p(R()), p(o()), g(() => R() ? void 0 : typeof o() == "number" ? `calc(min(${o()}px, 100%))` : Y(o()))),
				"border-style": b(),
				overflow: N() ? F() : "hidden",
				"flex-grow": I(),
				"min-width": `calc(min(${oe()}px, 100%))`
			})], void 0, void 0, "svelte-1stq1b1");
			var s = ge(), l = x(s);
			E(l, t, "default", {}, null);
			var f = c(l, 2), _ = (e) => {
				var t = he();
				re("mousedown", t, X), y(e, t);
			};
			V(f, (e) => {
				se() && e(_);
			}), y(a, s);
		});
		var l = c(s, 2), f = (e) => {
			var t = _e();
			let n;
			v(() => n = ae(t, "", n, {
				height: m(U) + "px",
				width: m(de) + "px"
			})), y(e, t);
		};
		V(l, (e) => {
			R() && e(f);
		}), y(e, a);
	};
	V(ye, (e) => {
		(M() === !0 || M() === "hidden") && e(be);
	}), y(e, Z), T();
}
//#endregion
//#region frontend/node_modules/@gradio/atoms/dist/src/SelectSource.svelte
N(["click"]), N(["click"]);
var q = new class {
	#e;
	get playing() {
		return m(this.#e);
	}
	set playing(e) {
		d(this.#e, e, !0);
	}
	#t;
	get offset() {
		return m(this.#t);
	}
	set offset(e) {
		d(this.#t, e, !0);
	}
	#n;
	get loopFrom() {
		return m(this.#n);
	}
	set loopFrom(e) {
		d(this.#n, e, !0);
	}
	#r;
	get loopTo() {
		return m(this.#r);
	}
	set loopTo(e) {
		d(this.#r, e, !0);
	}
	#i;
	get levels() {
		return m(this.#i);
	}
	set levels(e) {
		d(this.#i, e, !0);
	}
	#a;
	get repeat() {
		return m(this.#a);
	}
	set repeat(e) {
		d(this.#a, e, !0);
	}
	constructor() {
		this.context = null, this.master = null, this.buffers = {}, this.gains = {}, this.sources = [], this.startedAt = 0, this.fingerprint = "", this.selectionFingerprint = "", this.#e = L(!1), this.#t = L(0), this.#n = L(null), this.#r = L(null), this.#i = L(b({})), this.anchor = null, this.#a = L(!0);
	}
	position() {
		if (!this.context || !this.playing) return this.offset;
		let e = this.offset + (this.context.currentTime - this.startedAt);
		if (this.loopFrom !== null && this.loopTo !== null && e > this.loopTo) {
			let t = this.loopTo - this.loopFrom;
			e = this.loopFrom + (e - this.loopFrom) % t;
		}
		return e;
	}
	bytesFrom(e) {
		let t = atob(e), n = new Uint8Array(t.length);
		for (let e = 0; e < t.length; e++) n[e] = t.charCodeAt(e);
		return n.buffer;
	}
	computeFingerprint(e) {
		return e.map((e) => {
			let t = e.wav;
			return e.name + ":" + t.length + ":" + t.slice(0, 24) + ":" + t.slice(-24);
		}).join("|");
	}
	noteLayers(e) {
		let t = this.computeFingerprint(e);
		t !== this.selectionFingerprint && (this.clearLoop(), this.selectionFingerprint = t);
	}
	async ensureAudio(e) {
		if (!this.context) {
			this.context = new (window.AudioContext || window.webkitAudioContext)();
			let e = this.context.createGain();
			e.gain.value = .7;
			let t = this.context.createDynamicsCompressor();
			t.threshold.value = -6, t.knee.value = 0, t.ratio.value = 20, t.attack.value = .003, t.release.value = .15, e.connect(t), t.connect(this.context.destination), this.master = e;
		}
		let t = this.computeFingerprint(e);
		if (this.fingerprint !== t) {
			for (let e of Object.keys(this.gains)) this.gains[e].disconnect();
			this.buffers = {}, this.gains = {};
			for (let t of e) {
				let e = this.context.createGain();
				e.gain.value = this.levels[t.name] ?? t.level, e.connect(this.master), this.gains[t.name] = e, this.buffers[t.name] = await this.context.decodeAudioData(this.bytesFrom(t.wav));
			}
			this.fingerprint = t;
		}
	}
	stopSources() {
		for (let e of this.sources) {
			e.onended = null;
			try {
				e.stop();
			} catch {}
			e.disconnect();
		}
		this.sources = [];
	}
	async play(e, t) {
		let n = t ?? this.offset;
		if (this.stopSources(), this.playing = !1, await this.ensureAudio(e), this.context) {
			this.context.state === "suspended" && await this.context.resume(), this.offset = n, this.startedAt = this.context.currentTime, this.playing = !0;
			for (let t of e) {
				let e = this.context.createBufferSource();
				e.buffer = this.buffers[t.name], this.loopFrom !== null && this.loopTo !== null && this.repeat && (e.loop = !0, e.loopStart = this.loopFrom, e.loopEnd = this.loopTo), e.connect(this.gains[t.name]), e.start(this.startedAt, this.offset), this.loopFrom !== null && this.loopTo !== null && !this.repeat && e.stop(this.startedAt + (this.loopTo - this.offset)), this.sources.push(e);
			}
			this.sources.length && (this.sources[0].onended = () => {
				this.playing = !1;
			});
		}
	}
	stop() {
		this.offset = this.position(), this.stopSources(), this.playing = !1;
	}
	select(e, t) {
		let n = this.loopFrom !== null && this.loopTo !== null, r = this.loopFrom, i = this.loopTo, a = n && e.start >= this.loopFrom - .001 && e.end <= this.loopTo + .001;
		if (t && this.anchor !== null && !n) {
			let t = Math.min(this.anchor.start, e.start), n = Math.max(this.anchor.end, e.end);
			this.loopFrom = t, this.loopTo = Math.max(n, t + .05), this.offset = this.loopFrom;
		} else !t && a ? this.offset = e.start : (this.anchor = e, this.loopFrom = e.start, this.loopTo = null, this.offset = e.start);
		return this.stopSources(), this.playing = !1, this.loopFrom !== r || this.loopTo !== i;
	}
	selectRange(e, t) {
		let n = this.loopFrom, r = this.loopTo;
		return this.anchor = null, this.loopFrom = e, this.loopTo = Math.max(t, e + .05), this.offset = e, this.stopSources(), this.playing = !1, this.loopFrom !== n || this.loopTo !== r;
	}
	clearLoop() {
		this.anchor = null, this.loopFrom = null, this.loopTo = null, this.offset = 0, this.stopSources(), this.playing = !1;
	}
	setLevel(e, t) {
		this.levels[e] = t, this.gains[e] && this.context && this.gains[e].gain.setTargetAtTime(t, this.context.currentTime, .01);
	}
}(), J = b({
	strip: !0,
	faders: !0,
	notes: !1,
	lyrics: !1,
	instruments: !1
}), Y = b({
	Melody: !0,
	"Harmony above": !1,
	"Harmony below": !1,
	Bass: !1
}), X = b({ value: !1 }), Z = b({ value: !1 }), ye = b({ value: !1 }), be = b({ value: !0 }), xe = b({ value: !1 }), Q = b({
	Piano: !1,
	Guitar: !1,
	"Violin, first position": !1,
	"Violin, third position": !1
}), $ = b({
	scale: !1,
	chord: !0
}), Se = b({ value: !1 }), Ce = b({ value: "wrap" }), we = i("<label class=\"repeat svelte-d89286\"><input type=\"checkbox\" class=\"svelte-d89286\"/> Repeat</label>"), Te = i("<label class=\"repeat svelte-d89286\"><input type=\"checkbox\" class=\"svelte-d89286\"/> Follow</label>"), Ee = i("<div class=\"transport svelte-d89286\"><button class=\"svelte-d89286\">Play</button> <button class=\"svelte-d89286\">Stop</button> <button class=\"svelte-d89286\">Clear selection</button> <!> <span class=\"time svelte-d89286\"> </span> <!></div>");
function De(e, i) {
	_(i, !0);
	let a = P(i, "follow", 15);
	var o = Ee(), s = n(o), l = c(s, 2), u = c(l, 2), d = c(u, 2), f = (e) => {
		var r = we(), a = n(r);
		k(a), z(), F(r), t("change", a, function(...e) {
			i.onToggleRepeat?.apply(this, e);
		}), I(a, () => q.repeat, (e) => q.repeat = e), y(e, r);
	};
	V(d, (e) => {
		q.loopFrom !== null && q.loopTo !== null && e(f);
	});
	var p = c(d, 2), m = n(p);
	F(p);
	var h = c(p, 2), g = (e) => {
		var t = Te(), r = n(t);
		k(r), z(), F(t), I(r, a), y(e, t);
	};
	V(h, (e) => {
		i.hasTimeline && e(g);
	}), F(o), v((e) => r(m, `${e ?? ""}s`), [() => i.playhead.toFixed(1)]), t("click", s, () => q.play(i.layers)), t("click", l, () => q.stop()), t("click", u, function(...e) {
		i.onClearSelection?.apply(this, e);
	}), y(e, o), T();
}
N(["click", "change"]);
//#endregion
//#region frontend/PanelToggles.svelte
var Oe = i("<label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Chart</label>"), ke = i("<label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Notes</label> <label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Lyrics</label>", 1), Ae = i("<label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Shrink to fit</label>"), je = i("<label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Instruments</label> <label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Beside mixer</label> <!>", 1), Me = i("<div class=\"panel-toggles svelte-1mngm7u\"><!> <!> <label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Mixer</label> <!></div>");
function Ne(e, r) {
	_(r, !0);
	var i = Me(), a = n(i), o = (e) => {
		var t = Oe(), r = n(t);
		k(r), z(), F(t), I(r, () => J.strip, (e) => J.strip = e), y(e, t);
	};
	V(a, (e) => {
		r.hasTimeline && e(o);
	});
	var s = c(a, 2), l = (e) => {
		var t = ke(), r = x(t), i = n(r);
		k(i), z(), F(r);
		var a = c(r, 2), o = n(a);
		k(o), z(), F(a), I(i, () => J.notes, (e) => J.notes = e), I(o, () => J.lyrics, (e) => J.lyrics = e), y(e, t);
	};
	V(s, (e) => {
		r.hasNotes && e(l);
	});
	var u = c(s, 2), d = n(u);
	k(d), z(), F(u);
	var f = c(u, 2), p = (e) => {
		var r = je(), i = x(r), a = n(i);
		k(a), z(), F(i);
		var o = c(i, 2), s = n(o);
		k(s), z(), F(o);
		var l = c(o, 2), u = (e) => {
			var r = Ae(), i = n(r);
			k(i), z(), F(r), v(() => oe(i, Ce.value === "shrink")), t("change", i, (e) => Ce.value = e.currentTarget.checked ? "shrink" : "wrap"), y(e, r);
		};
		V(l, (e) => {
			Se.value && e(u);
		}), I(a, () => J.instruments, (e) => J.instruments = e), I(s, () => Se.value, (e) => Se.value = e), y(e, r);
	};
	V(f, (e) => {
		r.hasDiagrams && e(p);
	}), F(i), I(d, () => J.faders, (e) => J.faders = e), y(e, i), T();
}
N(["change"]);
//#endregion
//#region frontend/ChordStrip.svelte
var Pe = i("<button type=\"button\"><div class=\"number svelte-65z4tz\"> </div> <div class=\"chord svelte-65z4tz\"> </div> <div class=\"words svelte-65z4tz\"> </div></button>"), Fe = i("<div class=\"strip svelte-65z4tz\"></div> <p class=\"note svelte-65z4tz\"> </p>", 1);
function Ie(e, i) {
	_(i, !0);
	let o = u(() => i.timeline.find((e) => i.playhead >= e.start && i.playhead < e.end)), s = u(() => q.loopFrom === null ? i.timeline.length ? "Click a bar to select where Play starts. Shift-click a later bar to loop a stretch." : "" : q.loopTo === null ? `Play starts at ${q.loopFrom.toFixed(1)}s. Shift-click a later bar to select a stretch, or press Play.` : q.repeat ? `Repeating ${q.loopFrom.toFixed(1)}s to ${q.loopTo.toFixed(1)}s. Untick Repeat to play it once, or Clear selection to release it.` : `Selected ${q.loopFrom.toFixed(1)}s to ${q.loopTo.toFixed(1)}s, playing once. Tick Repeat to loop it.`), l = {};
	U(() => {
		i.follow && m(o) && l[m(o).bar] && l[m(o).bar].scrollIntoView({
			behavior: "smooth",
			inline: "center",
			block: "nearest"
		});
	});
	var d = a(), f = x(d), p = (e) => {
		var a = Fe(), u = x(a);
		H(u, 21, () => i.timeline, (e) => e.bar, (e, a) => {
			var s = Pe();
			let u;
			var d = n(s), f = n(d, !0);
			F(d);
			var p = c(d, 2), h = n(p, !0);
			F(p);
			var g = c(p, 2), _ = n(g, !0);
			F(g), F(s), ee(s, (e, t) => l[t.bar] = e, (e) => l?.[e.bar], () => [m(a)]), v(() => {
				u = M(s, 1, "bar svelte-65z4tz", null, u, {
					playing: m(o) === m(a),
					looped: q.loopFrom !== null && q.loopTo !== null && m(a).start >= q.loopFrom - .001 && m(a).end <= q.loopTo + .001
				}), j(s, "data-bar", m(a).bar), r(f, m(a).bar), r(h, m(a).name), r(_, m(a).words);
			}), t("click", s, (e) => i.onSelectBar(m(a), e)), t("keydown", s, (e) => {
				(e.key === "Enter" || e.key === " ") && (e.preventDefault(), i.onSelectBar(m(a), e));
			}), y(e, s);
		}), F(u);
		var d = c(u, 2), f = n(d, !0);
		F(d), v(() => r(f, m(s))), y(e, a);
	};
	V(f, (e) => {
		i.timeline.length && e(p);
	}), y(e, d), T();
}
N(["click", "keydown"]);
//#endregion
//#region frontend/FaderPanel.svelte
var Le = i("<div class=\"fader-row svelte-ma6git\"><span class=\"name svelte-ma6git\"> </span> <button class=\"mute svelte-ma6git\">M</button> <input type=\"range\" min=\"0\" max=\"1\" step=\"0.05\" class=\"svelte-ma6git\"/> <span class=\"value svelte-ma6git\"> </span></div>"), Re = i("<div class=\"faders\"></div>");
function ze(e, i) {
	_(i, !0);
	function a(e, t) {
		q.levels[e] = q.levels[e] > 0 ? 0 : t, i.onLevelChanged(e);
	}
	var o = Re();
	H(o, 21, () => i.layers, (e) => e.name, (e, o) => {
		var s = Le(), l = n(s), u = n(l, !0);
		F(l);
		var d = c(l, 2), f = c(d, 2);
		k(f);
		var p = c(f, 2), h = n(p);
		F(p), F(s), v((e) => {
			ae(l, `color:${m(o).colour ?? ""}`), r(u, m(o).name), r(h, `${e ?? ""}%`);
		}, [() => Math.round((q.levels[m(o).name] ?? 0) * 100)]), t("click", d, () => a(m(o).name, m(o).level)), t("input", f, () => i.onLevelChanged(m(o).name)), R(f, () => q.levels[m(o).name], (e) => q.levels[m(o).name] = e), y(e, s);
	}), F(o), y(e, o), T();
}
N(["click", "input"]);
//#endregion
//#region frontend/NotesPanel.svelte
var Be = h("<rect class=\"loop-region svelte-1nlxyec\" y=\"0\"></rect>"), Ve = h("<line class=\"bar-line svelte-1nlxyec\" y1=\"0\"></line>"), He = h("<text class=\"note-label svelte-1nlxyec\"> </text>"), Ue = h("<text class=\"note-word svelte-1nlxyec\"> </text>"), We = h("<g><rect class=\"note-box svelte-1nlxyec\"></rect><!><!></g>"), Ge = h("<line class=\"playhead svelte-1nlxyec\" y1=\"0\"></line>"), Ke = h("<svg><!><!><!><!></svg>"), qe = i("<label class=\"layer-toggle svelte-1nlxyec\"><input type=\"checkbox\" class=\"svelte-1nlxyec\"/> </label>"), Je = i("<label class=\"layer-toggle svelte-1nlxyec\"><input type=\"checkbox\" class=\"svelte-1nlxyec\"/> Side by side</label>"), Ye = i("<div class=\"notes-container next-page svelte-1nlxyec\"><!></div>"), Xe = i("<div><div class=\"notes-container svelte-1nlxyec\"><!></div> <!></div>"), Ze = i("<p class=\"note-empty svelte-1nlxyec\">No layers selected to show.</p>"), Qe = i("<div class=\"notes-toggles svelte-1nlxyec\"><!> <label class=\"layer-toggle preview-toggle svelte-1nlxyec\"><input type=\"checkbox\" class=\"svelte-1nlxyec\"/> Preview next phrase</label> <!> <label class=\"layer-toggle svelte-1nlxyec\"><input type=\"checkbox\" class=\"svelte-1nlxyec\"/> Word labels</label></div> <!>", 1);
function $e(e, t) {
	_(t, !0);
	let i = (e, i = ce, o = ce, s = ce) => {
		var l = Ke();
		let u;
		var d = n(l), f = (e) => {
			var t = Be();
			v((e, n) => {
				j(t, "x", e), j(t, "width", n), j(t, "height", i().height);
			}, [() => E(i(), Math.max(q.loopFrom, i().phrase.start)), () => Math.max(0, E(i(), Math.min(q.loopTo, i().phrase.end)) - E(i(), Math.max(q.loopFrom, i().phrase.start)))]), y(e, t);
		};
		V(d, (e) => {
			o() && q.loopFrom !== null && q.loopTo !== null && e(f);
		});
		var h = c(d);
		H(h, 17, () => i().bars, D, (e, t) => {
			var n = Ve();
			v((e, t) => {
				j(n, "x1", e), j(n, "x2", t), j(n, "y2", i().height);
			}, [() => E(i(), m(t).start), () => E(i(), m(t).start)]), y(e, n);
		});
		var g = c(h);
		H(g, 17, () => i().notes, D, (e, t) => {
			var o = We(), s = n(o);
			j(s, "height", a - 2);
			var l = c(s), u = (e) => {
				var o = He(), s = n(o, !0);
				F(o), v((e, n, i) => {
					j(o, "x", e), j(o, "y", n), j(o, "fill", m(t).colour), r(s, i);
				}, [
					() => E(i(), m(t).start) + m(t).length * i().pxPerSecond / 2,
					() => w(i(), m(t).midi) + a / 2,
					() => p(m(t).midi)
				]), y(e, o);
			};
			V(l, (e) => {
				m(t).length * i().pxPerSecond > 20 && e(u);
			});
			var d = c(l), f = (e) => {
				var o = Ue(), s = n(o, !0);
				F(o), v((e, n) => {
					j(o, "x", e), j(o, "y", n), r(s, m(t).word);
				}, [() => E(i(), m(t).start) + m(t).length * i().pxPerSecond / 2, () => w(i(), m(t).midi) + a + 10]), y(e, o);
			};
			V(d, (e) => {
				m(t).word && be.value && e(f);
			}), F(o), v((e, n, r) => {
				j(s, "x", e), j(s, "y", n), j(s, "width", r), j(s, "fill", m(t).colour), j(s, "fill-opacity", m(t).layer === "Melody" ? .22 : .14), j(s, "stroke", m(t).colour);
			}, [
				() => E(i(), m(t).start),
				() => w(i(), m(t).midi) + 1,
				() => Math.max(m(t).length * i().pxPerSecond - 1, 2)
			]), y(e, o);
		});
		var _ = c(g), b = (e) => {
			var n = Ge();
			v((e, t) => {
				j(n, "x1", e), j(n, "x2", t), j(n, "y2", i().height);
			}, [() => E(i(), t.playhead), () => E(i(), t.playhead)]), y(e, n);
		};
		V(_, (e) => {
			o() && e(b);
		}), F(l), v(() => {
			j(l, "width", i().width), j(l, "height", i().height), j(l, "viewBox", `0 0 ${i().width ?? ""} ${i().height ?? ""}`), u = M(l, 0, "svelte-1nlxyec", null, u, { dimmed: s() });
		}), y(e, l);
	}, a = 14, o = u(() => t.phrases.length ? t.phrases : t.notes.length ? [{
		start: 0,
		end: t.notes.reduce((e, t) => Math.max(e, t.start + t.length), 0),
		label: "1. Whole part"
	}] : []), s = u(() => {
		if (!m(o).length) return -1;
		let e = m(o).findIndex((e) => t.playhead < e.end);
		return e === -1 ? m(o).length - 1 : e;
	}), l = u(() => m(s) >= 0 ? m(o)[m(s)] : null), f = u(() => m(s) >= 0 && m(s) + 1 < m(o).length ? m(o)[m(s) + 1] : null);
	function p(e) {
		return [
			"C",
			"C#",
			"D",
			"D#",
			"E",
			"F",
			"F#",
			"G",
			"G#",
			"A",
			"A#",
			"B"
		][e % 12] + Math.floor(e / 12 - 1);
	}
	let h = L(null), g = L(600);
	U(() => {
		m(h) && d(g, m(h).clientWidth || m(g), !0);
	});
	function b(e, n) {
		if (!e) return null;
		let r = t.timeline.filter((t) => t.start < e.end && t.end > e.start), i = t.notes.filter((t) => Y[t.layer] && t.start >= e.start && t.start < e.end), a = 60, o = 72;
		if (i.length) {
			a = i[0].midi, o = i[0].midi;
			for (let e of i) e.midi < a && (a = e.midi), e.midi > o && (o = e.midi);
			--a, o += 1;
		}
		let s = (o - a + 1) * 14, c = e.end - e.start, l = c > 0 ? n / c : 60;
		return {
			phrase: e,
			bars: r,
			notes: i,
			pitchRange: {
				lowest: a,
				highest: o
			},
			width: n,
			height: s,
			pxPerSecond: l
		};
	}
	let S = u(() => {
		let e = X.value && Z.value ? (m(g) - 8) / 2 : m(g);
		return b(m(l), e);
	}), C = u(() => {
		if (!X.value) return null;
		let e = Z.value ? (m(g) - 8) / 2 : m(g);
		return b(m(f), e);
	});
	function w(e, t) {
		return (e.pitchRange.highest - t) * 14;
	}
	function E(e, t) {
		return (t - e.phrase.start) * e.pxPerSecond;
	}
	var O = Qe(), A = x(O), te = n(A);
	H(te, 17, () => Object.keys(Y), D, (e, t) => {
		var i = qe(), a = n(i);
		k(a);
		var o = c(a);
		F(i), v(() => r(o, ` ${m(t) ?? ""}`)), I(a, () => Y[m(t)], (e) => Y[m(t)] = e), y(e, i);
	});
	var ne = c(te, 2), re = n(ne);
	k(re), z(), F(ne);
	var N = c(ne, 2), ie = (e) => {
		var t = Je(), r = n(t);
		k(r), z(), F(t), I(r, () => Z.value, (e) => Z.value = e), y(e, t);
	};
	V(N, (e) => {
		X.value && e(ie);
	});
	var ae = c(N, 2), P = n(ae);
	k(P), z(), F(ae), F(A);
	var oe = c(A, 2), se = (e) => {
		var t = Xe();
		let r;
		var a = n(t), o = n(a);
		i(o, () => m(S), () => !0, () => !1), F(a);
		var s = c(a, 2), l = (e) => {
			var t = Ye(), r = n(t);
			i(r, () => m(C), () => !1, () => !0), F(t), y(e, t);
		};
		V(s, (e) => {
			m(C) && e(l);
		}), F(t), ee(t, (e) => d(h, e), () => m(h)), v(() => r = M(t, 1, "pages svelte-1nlxyec", null, r, { row: X.value && Z.value })), y(e, t);
	}, R = (e) => {
		var t = Ze();
		y(e, t);
	};
	V(oe, (e) => {
		m(S) ? e(se) : e(R, -1);
	}), I(re, () => X.value, (e) => X.value = e), I(P, () => be.value, (e) => be.value = e), y(e, O), T();
}
//#endregion
//#region frontend/PhraseList.svelte
var et = i("<button type=\"button\" class=\"phrase svelte-8xxexk\"> </button>"), tt = i("<div class=\"phrase-list svelte-8xxexk\"></div>");
function nt(e, i) {
	_(i, !0);
	var o = a(), s = x(o), c = (e) => {
		var a = tt();
		H(a, 21, () => i.phrases, D, (e, a) => {
			var o = et(), s = n(o, !0);
			F(o), v(() => r(s, m(a).label)), t("click", o, () => i.onSelectPhrase(m(a))), t("keydown", o, (e) => {
				(e.key === "Enter" || e.key === " ") && (e.preventDefault(), i.onSelectPhrase(m(a)));
			}), y(e, o);
		}), F(a), y(e, a);
	};
	V(s, (e) => {
		i.phrases.length && e(c);
	}), y(e, o), T();
}
N(["click", "keydown"]);
//#endregion
//#region frontend/LyricsPanel.svelte
var rt = i("<span> </span>"), it = i("<p class=\"sentence next svelte-4o08vh\"></p>"), at = i("<p class=\"sentence current svelte-4o08vh\"></p> <!>", 1), ot = i("<span class=\"word next svelte-4o08vh\"> </span>"), st = i("<span class=\"row-gap svelte-4o08vh\"></span> <!>", 1), ct = i("<div class=\"word-row svelte-4o08vh\"><!> <!></div>"), lt = i("<div><label class=\"style-toggle svelte-4o08vh\"><input type=\"checkbox\" class=\"svelte-4o08vh\"/> Sentence style</label> <label class=\"style-toggle svelte-4o08vh\"><input type=\"checkbox\" class=\"svelte-4o08vh\"/> Larger</label> <!></div>"), ut = i("<p class=\"lyrics-empty svelte-4o08vh\">No lyrics to show yet.</p>");
function dt(e, t) {
	_(t, !0);
	let i = u(() => t.notes.filter((e) => e.layer === "Melody" && e.word)), o = u(() => t.phrases.length ? t.phrases : m(i).length ? [{
		start: 0,
		end: m(i).reduce((e, t) => Math.max(e, t.start + t.length), 0),
		label: "Whole part"
	}] : []), s = u(() => {
		if (!m(o).length) return -1;
		let e = m(o).findIndex((e) => t.playhead < e.end);
		return e === -1 ? m(o).length - 1 : e;
	}), l = u(() => m(s) >= 0 ? m(o)[m(s)] : null), d = u(() => m(s) >= 0 && m(s) + 1 < m(o).length ? m(o)[m(s) + 1] : null);
	function f(e) {
		return e ? m(i).filter((t) => t.start >= e.start && t.start < e.end) : [];
	}
	let p = u(() => f(m(l))), h = u(() => f(m(d))), g = u(() => {
		let e = null;
		for (let n of m(p)) if (n.start <= t.playhead) e = n;
		else break;
		return e;
	});
	function b(e) {
		return e?.endsWith("-") ? "" : " ";
	}
	var S = a(), C = x(S), w = (e) => {
		var i = lt();
		let a;
		var o = n(i), s = n(o);
		k(s), z(), F(o);
		var l = c(o, 2), u = n(l);
		k(u), z(), F(l);
		var d = c(l, 2), f = (e) => {
			var i = at(), a = x(i);
			H(a, 21, () => m(p), D, (e, i) => {
				var a = rt();
				let o;
				var s = n(a);
				F(a), v((e) => {
					o = M(a, 1, "sentence-word svelte-4o08vh", null, o, { sung: m(i).start <= t.playhead }), r(s, `${m(i).word ?? ""}${e ?? ""}`);
				}, [() => b(m(i).word)]), y(e, a);
			}), F(a);
			var o = c(a, 2), s = (e) => {
				var t = it();
				H(t, 21, () => m(h), D, (e, t) => {
					var i = rt(), a = n(i);
					F(i), v((e) => r(a, `${m(t).word ?? ""}${e ?? ""}`), [() => b(m(t).word)]), y(e, i);
				}), F(t), y(e, t);
			};
			V(o, (e) => {
				m(h).length && e(s);
			}), y(e, i);
		}, _ = (e) => {
			var t = ct(), i = n(t);
			H(i, 17, () => m(p), D, (e, t) => {
				var i = rt();
				let a;
				var o = n(i, !0);
				F(i), v(() => {
					a = M(i, 1, "word svelte-4o08vh", null, a, { active: m(t) === m(g) }), r(o, m(t).word);
				}), y(e, i);
			});
			var a = c(i, 2), o = (e) => {
				var t = st(), i = c(x(t), 2);
				H(i, 17, () => m(h), D, (e, t) => {
					var i = ot(), a = n(i, !0);
					F(i), v(() => r(a, m(t).word)), y(e, i);
				}), y(e, t);
			};
			V(a, (e) => {
				m(h).length && e(o);
			}), F(t), y(e, t);
		};
		V(d, (e) => {
			ye.value ? e(f) : e(_, -1);
		}), F(i), v(() => a = M(i, 1, "lyrics-panel svelte-4o08vh", null, a, { large: xe.value })), I(s, () => ye.value, (e) => ye.value = e), I(u, () => xe.value, (e) => xe.value = e), y(e, i);
	}, E = (e) => {
		var t = ut();
		y(e, t);
	};
	V(C, (e) => {
		m(l) ? e(w) : e(E, -1);
	}), y(e, S), T();
}
//#endregion
//#region frontend/InstrumentPanel.svelte
var ft = i("<label class=\"instrument-toggle svelte-o1xgsa\"><input type=\"checkbox\" class=\"svelte-o1xgsa\"/> </label>"), pt = i("<p class=\"instrument-empty svelte-o1xgsa\">Choose an instrument to see it.</p>"), mt = i("<div class=\"layer stacked scale-layer svelte-o1xgsa\"></div>"), ht = i("<div class=\"layer stacked chord-layer svelte-o1xgsa\"></div>"), gt = i("<p class=\"instrument-empty svelte-o1xgsa\"> </p>"), _t = i("<div class=\"diagram-stack svelte-o1xgsa\"><div class=\"layer structure-layer svelte-o1xgsa\"></div> <!> <!> <!></div>"), vt = i("<p class=\"instrument-empty svelte-o1xgsa\">No picture for this instrument yet.</p>"), yt = i("<div class=\"instrument-card svelte-o1xgsa\"><h4 class=\"svelte-o1xgsa\"> </h4> <!></div>"), bt = i("<div class=\"instrument-grid svelte-o1xgsa\"></div>"), xt = i("<div class=\"instrument-toggles svelte-o1xgsa\"><!> <span class=\"layer-gap svelte-o1xgsa\"></span> <label class=\"instrument-toggle svelte-o1xgsa\"><input type=\"checkbox\" class=\"svelte-o1xgsa\"/> Scale</label> <label class=\"instrument-toggle svelte-o1xgsa\"><input type=\"checkbox\" class=\"svelte-o1xgsa\"/> Chord</label></div> <!>", 1);
function St(e, t) {
	_(t, !0);
	let i = u(() => t.timeline.find((e) => t.playhead >= e.start && t.playhead < e.end)), a = u(() => Object.keys(Q).filter((e) => Q[e]));
	var o = xt(), s = x(o), l = n(s);
	H(l, 17, () => Object.keys(Q), D, (e, t) => {
		var i = ft(), a = n(i);
		k(a);
		var o = c(a);
		F(i), v(() => r(o, ` ${m(t) ?? ""}`)), I(a, () => Q[m(t)], (e) => Q[m(t)] = e), y(e, i);
	});
	var d = c(l, 4), f = n(d);
	k(f), z(), F(d);
	var p = c(d, 2), h = n(p);
	k(h), z(), F(p), F(s);
	var g = c(s, 2), b = (e) => {
		var t = pt();
		y(e, t);
	}, S = (e) => {
		var o = bt();
		H(o, 21, () => m(a), D, (e, a) => {
			let o = u(() => t.diagrams.structure?.[m(a)]), s = u(() => t.diagrams.scale?.[m(a)]), l = u(() => m(i) ? t.diagrams.chords?.[m(a)]?.[m(i).name] : void 0);
			var d = yt(), f = n(d), p = n(f, !0);
			F(f);
			var h = c(f, 2), g = (e) => {
				var t = _t(), a = n(t);
				B(a, () => m(o), !0), F(a);
				var u = c(a, 2), d = (e) => {
					var t = mt();
					B(t, () => m(s), !0), F(t), y(e, t);
				};
				V(u, (e) => {
					$.scale && m(s) && e(d);
				});
				var f = c(u, 2), p = (e) => {
					var t = ht();
					B(t, () => m(l), !0), F(t), y(e, t);
				};
				V(f, (e) => {
					$.chord && m(l) && e(p);
				});
				var h = c(f, 2), g = (e) => {
					var t = gt(), a = n(t, !0);
					F(t), v(() => r(a, m(i) ? "No chord picture for this bar." : "Nothing playing yet.")), y(e, t);
				};
				V(h, (e) => {
					$.chord && !m(l) && e(g);
				}), F(t), y(e, t);
			}, _ = (e) => {
				var t = vt();
				y(e, t);
			};
			V(h, (e) => {
				m(o) ? e(g) : e(_, -1);
			}), F(d), v(() => r(p, m(a))), y(e, d);
		}), F(o), y(e, o);
	};
	V(g, (e) => {
		m(a).length ? e(S, -1) : e(b);
	}), I(f, () => $.scale, (e) => $.scale = e), I(h, () => $.chord, (e) => $.chord = e), y(e, o), T();
}
//#endregion
//#region frontend/Index.svelte
var Ct = /* @__PURE__ */ new Set([
	"$$slots",
	"$$events",
	"$$legacy"
]), wt = i("<!> <!>", 1), Tt = i("<div class=\"mixer-and-instruments-item svelte-r41nsf\"><!></div>"), Et = i("<div><!> <!></div>"), Dt = i("<div class=\"mixer svelte-r41nsf\"><!> <!> <!> <!> <!> <!></div>");
function Ot(e, t) {
	_(t, !0);
	let r = new me(se(t, Ct)), i = u(() => r.props.value?.layers ?? []), a = u(() => r.props.value?.timeline ?? []), o = u(() => r.props.value?.notes ?? []), s = u(() => r.props.value?.phrases ?? []), l = u(() => r.props.value?.diagrams ?? {
		structure: {},
		scale: {},
		chords: {}
	});
	q.noteLayers(m(i)), U(() => {
		for (let e of m(i)) e.name in q.levels || (q.levels[e.name] = e.level);
	}), r.props.value?.loop_start != null && q.loopFrom === null && (q.loopFrom = r.props.value.loop_start, q.loopTo = r.props.value.loop_end ?? null);
	let f = L(b(q.position())), p = null;
	function h() {
		d(f, q.position(), !0), p = requestAnimationFrame(h);
	}
	h(), le(() => {
		p !== null && cancelAnimationFrame(p);
	});
	let g = L(!0);
	function S() {
		r.props.value && (r.props.value.loop_start = q.loopFrom, r.props.value.loop_end = q.loopTo), r.dispatch("change");
	}
	function C(e, t) {
		let n = q.playing, r = q.select(e, t.shiftKey);
		d(f, q.position(), !0), r && S(), n && q.play(m(i));
	}
	function w(e) {
		let t = q.playing, n = q.selectRange(e.start, e.end);
		d(f, q.position(), !0), n && S(), t && q.play(m(i));
	}
	function E() {
		q.clearLoop(), d(f, 0), S();
	}
	function ee() {
		q.playing && q.play(m(i), q.position());
	}
	function D(e) {
		q.setLevel(e, q.levels[e]), r.dispatch("input");
	}
	ve(e, {
		get visible() {
			return r.shared.visible;
		},
		get elem_id() {
			return r.shared.elem_id;
		},
		get elem_classes() {
			return r.shared.elem_classes;
		},
		get scale() {
			return r.shared.scale;
		},
		get min_width() {
			return r.shared.min_width;
		},
		allow_overflow: !0,
		padding: !0,
		children: (e, t) => {
			var r = Dt(), p = n(r);
			{
				let e = u(() => m(a).length > 0);
				De(p, {
					get layers() {
						return m(i);
					},
					get playhead() {
						return m(f);
					},
					get hasTimeline() {
						return m(e);
					},
					onClearSelection: E,
					onToggleRepeat: ee,
					get follow() {
						return m(g);
					},
					set follow(e) {
						d(g, e, !0);
					}
				});
			}
			var h = c(p, 2);
			{
				let e = u(() => m(a).length > 0), t = u(() => m(o).length > 0), n = u(() => Object.keys(m(l).structure ?? {}).length > 0);
				Ne(h, {
					get hasTimeline() {
						return m(e);
					},
					get hasNotes() {
						return m(t);
					},
					get hasDiagrams() {
						return m(n);
					}
				});
			}
			var _ = c(h, 2), b = (e) => {
				Ie(e, {
					get timeline() {
						return m(a);
					},
					get playhead() {
						return m(f);
					},
					get follow() {
						return m(g);
					},
					onSelectBar: C
				});
			};
			V(_, (e) => {
				J.strip && e(b);
			});
			var S = c(_, 2), T = (e) => {
				var t = wt(), n = x(t);
				nt(n, {
					get phrases() {
						return m(s);
					},
					onSelectPhrase: w
				}), $e(c(n, 2), {
					get notes() {
						return m(o);
					},
					get timeline() {
						return m(a);
					},
					get phrases() {
						return m(s);
					},
					get playhead() {
						return m(f);
					}
				}), y(e, t);
			};
			V(S, (e) => {
				J.notes && e(T);
			});
			var O = c(S, 2), k = (e) => {
				dt(e, {
					get notes() {
						return m(o);
					},
					get phrases() {
						return m(s);
					},
					get playhead() {
						return m(f);
					}
				});
			};
			V(O, (e) => {
				J.lyrics && e(k);
			});
			var A = c(O, 2), j = (e) => {
				var t = Et();
				let r;
				var o = n(t), s = (e) => {
					var t = Tt();
					ze(n(t), {
						get layers() {
							return m(i);
						},
						onLevelChanged: D
					}), F(t), y(e, t);
				};
				V(o, (e) => {
					J.faders && e(s);
				});
				var u = c(o, 2), d = (e) => {
					var t = Tt();
					St(n(t), {
						get diagrams() {
							return m(l);
						},
						get timeline() {
							return m(a);
						},
						get playhead() {
							return m(f);
						}
					}), F(t), y(e, t);
				};
				V(u, (e) => {
					J.instruments && e(d);
				}), F(t), v(() => r = M(t, 1, "mixer-and-instruments svelte-r41nsf", null, r, {
					beside: Se.value && J.faders && J.instruments,
					shrink: Ce.value === "shrink"
				})), y(e, t);
			};
			V(A, (e) => {
				(J.faders || J.instruments) && e(j);
			}), F(r), y(e, r);
		},
		$$slots: { default: !0 }
	}), T();
}
//#endregion
export { Ot as default };

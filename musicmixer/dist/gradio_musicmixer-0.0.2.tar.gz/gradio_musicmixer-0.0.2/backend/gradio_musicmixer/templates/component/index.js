import { $ as e, A as t, B as n, C as r, D as i, F as a, G as o, H as s, I as c, J as l, K as u, L as d, M as f, N as p, O as m, P as h, Q as g, R as _, S as v, T as y, U as b, V as x, W as S, X as C, Y as w, Z as T, _ as E, a as D, at as O, b as k, c as A, d as j, et as M, f as N, g as P, h as F, i as I, it as L, j as R, k as z, l as B, m as V, n as H, nt as ee, o as te, p as U, q as ne, r as W, rt as G, s as re, t as ie, tt as ae, u as oe, v as se, x as K, y as ce, z as le } from "./index-client-DYEMpcfk.js";
//#region frontend/node_modules/@gradio/theme/dist/src/colors.js
var q = [
	{
		color: "red",
		primary: 600,
		secondary: 100
	},
	{
		color: "green",
		primary: 600,
		secondary: 100
	},
	{
		color: "blue",
		primary: 600,
		secondary: 100
	},
	{
		color: "yellow",
		primary: 500,
		secondary: 100
	},
	{
		color: "purple",
		primary: 600,
		secondary: 100
	},
	{
		color: "teal",
		primary: 600,
		secondary: 100
	},
	{
		color: "orange",
		primary: 600,
		secondary: 100
	},
	{
		color: "cyan",
		primary: 600,
		secondary: 100
	},
	{
		color: "lime",
		primary: 500,
		secondary: 100
	},
	{
		color: "pink",
		primary: 600,
		secondary: 100
	}
], J = {
	inherit: "inherit",
	current: "currentColor",
	transparent: "transparent",
	black: "#000",
	white: "#fff",
	slate: {
		50: "#f8fafc",
		100: "#f1f5f9",
		200: "#e2e8f0",
		300: "#cbd5e1",
		400: "#94a3b8",
		500: "#64748b",
		600: "#475569",
		700: "#334155",
		800: "#1e293b",
		900: "#0f172a",
		950: "#020617"
	},
	gray: {
		50: "#f9fafb",
		100: "#f3f4f6",
		200: "#e5e7eb",
		300: "#d1d5db",
		400: "#9ca3af",
		500: "#6b7280",
		600: "#4b5563",
		700: "#374151",
		800: "#1f2937",
		900: "#111827",
		950: "#030712"
	},
	zinc: {
		50: "#fafafa",
		100: "#f4f4f5",
		200: "#e4e4e7",
		300: "#d4d4d8",
		400: "#a1a1aa",
		500: "#71717a",
		600: "#52525b",
		700: "#3f3f46",
		800: "#27272a",
		900: "#18181b",
		950: "#09090b"
	},
	neutral: {
		50: "#fafafa",
		100: "#f5f5f5",
		200: "#e5e5e5",
		300: "#d4d4d4",
		400: "#a3a3a3",
		500: "#737373",
		600: "#525252",
		700: "#404040",
		800: "#262626",
		900: "#171717",
		950: "#0a0a0a"
	},
	stone: {
		50: "#fafaf9",
		100: "#f5f5f4",
		200: "#e7e5e4",
		300: "#d6d3d1",
		400: "#a8a29e",
		500: "#78716c",
		600: "#57534e",
		700: "#44403c",
		800: "#292524",
		900: "#1c1917",
		950: "#0c0a09"
	},
	red: {
		50: "#fef2f2",
		100: "#fee2e2",
		200: "#fecaca",
		300: "#fca5a5",
		400: "#f87171",
		500: "#ef4444",
		600: "#dc2626",
		700: "#b91c1c",
		800: "#991b1b",
		900: "#7f1d1d",
		950: "#450a0a"
	},
	orange: {
		50: "#fff7ed",
		100: "#ffedd5",
		200: "#fed7aa",
		300: "#fdba74",
		400: "#fb923c",
		500: "#f97316",
		600: "#ea580c",
		700: "#c2410c",
		800: "#9a3412",
		900: "#7c2d12",
		950: "#431407"
	},
	amber: {
		50: "#fffbeb",
		100: "#fef3c7",
		200: "#fde68a",
		300: "#fcd34d",
		400: "#fbbf24",
		500: "#f59e0b",
		600: "#d97706",
		700: "#b45309",
		800: "#92400e",
		900: "#78350f",
		950: "#451a03"
	},
	yellow: {
		50: "#fefce8",
		100: "#fef9c3",
		200: "#fef08a",
		300: "#fde047",
		400: "#facc15",
		500: "#eab308",
		600: "#ca8a04",
		700: "#a16207",
		800: "#854d0e",
		900: "#713f12",
		950: "#422006"
	},
	lime: {
		50: "#f7fee7",
		100: "#ecfccb",
		200: "#d9f99d",
		300: "#bef264",
		400: "#a3e635",
		500: "#84cc16",
		600: "#65a30d",
		700: "#4d7c0f",
		800: "#3f6212",
		900: "#365314",
		950: "#1a2e05"
	},
	green: {
		50: "#f0fdf4",
		100: "#dcfce7",
		200: "#bbf7d0",
		300: "#86efac",
		400: "#4ade80",
		500: "#22c55e",
		600: "#16a34a",
		700: "#15803d",
		800: "#166534",
		900: "#14532d",
		950: "#052e16"
	},
	emerald: {
		50: "#ecfdf5",
		100: "#d1fae5",
		200: "#a7f3d0",
		300: "#6ee7b7",
		400: "#34d399",
		500: "#10b981",
		600: "#059669",
		700: "#047857",
		800: "#065f46",
		900: "#064e3b",
		950: "#022c22"
	},
	teal: {
		50: "#f0fdfa",
		100: "#ccfbf1",
		200: "#99f6e4",
		300: "#5eead4",
		400: "#2dd4bf",
		500: "#14b8a6",
		600: "#0d9488",
		700: "#0f766e",
		800: "#115e59",
		900: "#134e4a",
		950: "#042f2e"
	},
	cyan: {
		50: "#ecfeff",
		100: "#cffafe",
		200: "#a5f3fc",
		300: "#67e8f9",
		400: "#22d3ee",
		500: "#06b6d4",
		600: "#0891b2",
		700: "#0e7490",
		800: "#155e75",
		900: "#164e63",
		950: "#083344"
	},
	sky: {
		50: "#f0f9ff",
		100: "#e0f2fe",
		200: "#bae6fd",
		300: "#7dd3fc",
		400: "#38bdf8",
		500: "#0ea5e9",
		600: "#0284c7",
		700: "#0369a1",
		800: "#075985",
		900: "#0c4a6e",
		950: "#082f49"
	},
	blue: {
		50: "#eff6ff",
		100: "#dbeafe",
		200: "#bfdbfe",
		300: "#93c5fd",
		400: "#60a5fa",
		500: "#3b82f6",
		600: "#2563eb",
		700: "#1d4ed8",
		800: "#1e40af",
		900: "#1e3a8a",
		950: "#172554"
	},
	indigo: {
		50: "#eef2ff",
		100: "#e0e7ff",
		200: "#c7d2fe",
		300: "#a5b4fc",
		400: "#818cf8",
		500: "#6366f1",
		600: "#4f46e5",
		700: "#4338ca",
		800: "#3730a3",
		900: "#312e81",
		950: "#1e1b4b"
	},
	violet: {
		50: "#f5f3ff",
		100: "#ede9fe",
		200: "#ddd6fe",
		300: "#c4b5fd",
		400: "#a78bfa",
		500: "#8b5cf6",
		600: "#7c3aed",
		700: "#6d28d9",
		800: "#5b21b6",
		900: "#4c1d95",
		950: "#2e1065"
	},
	purple: {
		50: "#faf5ff",
		100: "#f3e8ff",
		200: "#e9d5ff",
		300: "#d8b4fe",
		400: "#c084fc",
		500: "#a855f7",
		600: "#9333ea",
		700: "#7e22ce",
		800: "#6b21a8",
		900: "#581c87",
		950: "#3b0764"
	},
	fuchsia: {
		50: "#fdf4ff",
		100: "#fae8ff",
		200: "#f5d0fe",
		300: "#f0abfc",
		400: "#e879f9",
		500: "#d946ef",
		600: "#c026d3",
		700: "#a21caf",
		800: "#86198f",
		900: "#701a75",
		950: "#4a044e"
	},
	pink: {
		50: "#fdf2f8",
		100: "#fce7f3",
		200: "#fbcfe8",
		300: "#f9a8d4",
		400: "#f472b6",
		500: "#ec4899",
		600: "#db2777",
		700: "#be185d",
		800: "#9d174d",
		900: "#831843",
		950: "#500724"
	},
	rose: {
		50: "#fff1f2",
		100: "#ffe4e6",
		200: "#fecdd3",
		300: "#fda4af",
		400: "#fb7185",
		500: "#f43f5e",
		600: "#e11d48",
		700: "#be123c",
		800: "#9f1239",
		900: "#881337",
		950: "#4c0519"
	}
};
q.reduce((e, { color: t, primary: n, secondary: r }) => ({
	...e,
	[t]: {
		primary: J[t][n],
		secondary: J[t][r]
	}
}), {});
//#endregion
//#region frontend/node_modules/svelte/src/store/index-client.js
function ue(e) {
	let t, n = T((n) => {
		let r = !1, i = e.subscribe((e) => {
			t = e, r && n();
		});
		return r = !0, i;
	});
	function r() {
		return d() ? (n(), t) : g(e);
	}
	return "set" in e ? {
		get current() {
			return r();
		},
		set current(t) {
			e.set(t);
		}
	} : { get current() {
		return r();
	} };
}
var de = [
	"label",
	"info",
	"placeholder",
	"description",
	"title",
	"value"
], fe = /* @__PURE__ */ "elem_id.elem_classes.visible.interactive.server_fns.server.id.target.theme_mode.version.root.autoscroll.max_file_size.formatter.client.load_component.scale.min_width.theme.padding.loading_status.label.show_label.validation_error.show_progress.api_prefix.container.attached_events.register_component.unregister_component.dispatcher".split(".");
function pe(e) {
	return typeof e == "string" && e.includes("__i18n__");
}
var me = class {
	load_component;
	#e = w(o({}));
	get shared() {
		return a(this.#e);
	}
	set shared(e) {
		l(this.#e, e, !0);
	}
	#t = w(o({}));
	get props() {
		return a(this.#t);
	}
	set props(e) {
		l(this.#t, e, !0);
	}
	#n = w((e) => e);
	get i18n() {
		return a(this.#n);
	}
	set i18n(e) {
		l(this.#n, e, !0);
	}
	i18n_store;
	_i18n_from_store;
	translatable_props = {};
	dispatcher;
	last_update = null;
	shared_props = fe;
	mounted = !1;
	old_value;
	register_component;
	unregister_component;
	set_data_callback;
	get_data_callback;
	registered_id = null;
	last_shared_props;
	last_props;
	constructor(e, t) {
		for (let t in e.shared_props) this.shared[t] = e.shared_props[t];
		for (let t in e.props) t !== "i18n_store" && (this.props[t] = e.props[t]);
		if (t) for (let e in t) this.props[e] === void 0 && (this.props[e] = t[e]);
		this.i18n = this.props.i18n ?? ((e) => e), this.i18n_store = e.props.i18n_store, this._i18n_from_store = this.i18n_store ? ue(this.i18n_store) : void 0;
		for (let t of de) this.shared[t] = this._translate_and_store("shared", t, e.shared_props[t]), this.props[t] = this._translate_and_store("props", t, e.props[t]);
		this.load_component = this.shared.load_component, this.register_component = this.shared.register_component || (() => {}), this.unregister_component = this.shared.unregister_component || (() => {}), this.dispatcher = this.shared.dispatcher || (() => {}), this.set_data_callback = this.set_data.bind(this), this.get_data_callback = this.get_data.bind(this), this.register_component(this.shared.id, this.set_data_callback, this.get_data_callback), this.registered_id = this.shared.id, this.last_shared_props = e.shared_props, this.last_props = e.props, x(() => {
			let t = e.shared_props.id;
			if (this.last_shared_props !== e.shared_props) {
				for (let t in e.shared_props) {
					let n = e.shared_props[t];
					n !== void 0 && (this._is_i18n_managed(`shared.${t}`, n) || (this.shared[t] = n));
				}
				this.last_shared_props = e.shared_props;
			}
			if (this.last_props !== e.props) {
				for (let t in e.props) {
					if (t === "i18n_store") continue;
					let n = e.props[t];
					n !== void 0 && (this._is_i18n_managed(`props.${t}`, n) || (this.props[t] = n));
				}
				this.last_props = e.props;
			}
			this.registered_id !== null && this.registered_id !== t && this.unregister_component(this.registered_id, this.set_data_callback), this.register_component(t, this.set_data_callback, this.get_data_callback), this.registered_id = t, c(() => {
				this.shared.id = t;
			});
		}), x(() => () => {
			this.registered_id !== null && this.unregister_component(this.registered_id, this.set_data_callback);
		}), x(() => {
			if (this.i18n_store) return this.i18n_store.subscribe(() => {
				for (let [e, t] of Object.entries(this.translatable_props)) {
					let [n, r] = e.split("."), i = this.i18n(t);
					n === "shared" ? this.shared[r] = i : this.props[r] = i;
				}
			});
		});
	}
	_is_i18n_managed(e, t) {
		let n = this.translatable_props[e];
		return n ? t === n || (delete this.translatable_props[e], !1) : !1;
	}
	_translate_and_store(e, t, n) {
		if (typeof n != "string") return n;
		let r = this.i18n(n);
		return r !== n && (this.translatable_props[`${e}.${t}`] = n), r;
	}
	live_i18n = (e) => (this._i18n_from_store?.current, this.i18n(e));
	dispatch(e, t) {
		this.dispatcher(this.shared.id, e, t);
	}
	async get_data() {
		return ae(this.props);
	}
	update(e) {
		this.set_data(e);
	}
	set_data(e) {
		for (let t in e) {
			let n = e[t], r = pe(n) ? this._translate_and_store(this.shared_props.includes(t) ? "shared" : "props", t, n) : n;
			if (this.shared_props.includes(t)) {
				let e = t;
				this.shared[e] = r;
				continue;
			}
			this.props[t] = r;
		}
	}
	watch_for_change() {
		x(() => {
			this.mounted ||= (this.old_value = this.props.value, !0), this.old_value != this.props.value && (this.old_value = this.props.value, this.dispatch("change"));
		});
	}
};
//#endregion
//#region frontend/node_modules/svelte/src/internal/flags/legacy.js
ee();
//#endregion
//#region frontend/node_modules/@gradio/atoms/dist/src/Block.svelte
var he = t("<svg class=\"resize-handle svelte-1stq1b1\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 10 10\"><line x1=\"1\" y1=\"9\" x2=\"9\" y2=\"1\" stroke=\"gray\" stroke-width=\"0.5\" class=\"svelte-1stq1b1\"></line><line x1=\"5\" y1=\"9\" x2=\"9\" y2=\"5\" stroke=\"gray\" stroke-width=\"0.5\" class=\"svelte-1stq1b1\"></line></svg>"), ge = z("<!> <!>", 1), _e = z("<div class=\"placeholder svelte-1stq1b1\"></div>");
function ve(t, o) {
	M(o, !1);
	let s = W(o, "height", 8, void 0), d = W(o, "min_height", 8, void 0), f = W(o, "max_height", 8, void 0), g = W(o, "width", 8, void 0), v = W(o, "elem_id", 8, ""), y = W(o, "elem_classes", 24, () => []), x = W(o, "variant", 8, "solid"), C = W(o, "border_mode", 8, "base"), w = W(o, "padding", 8, !0), T = W(o, "type", 8, "normal"), E = W(o, "test_id", 8, void 0), O = W(o, "explicit_call", 8, !1), k = W(o, "container", 8, !0), A = W(o, "visible", 8, !0), F = W(o, "allow_overflow", 8, !0), I = W(o, "overflow_behavior", 8, "auto"), L = W(o, "scale", 8, null), R = W(o, "min_width", 8, 0), z = W(o, "flex", 12, !1), B = W(o, "resizable", 8, !1), V = W(o, "rtl", 8, !1), H = W(o, "fullscreen", 12, !1), ee = W(o, "label", 8, void 0), U = u(H()), G = u(), re = T() === "fieldset" ? "fieldset" : "div", ie = u(0), ae = u(0), K = u(null), q = null, J = null;
	function ue(e) {
		H() && e.key === "Escape" && H(!1);
	}
	function de() {
		let e = a(G).getRootNode();
		return a(G).closest(".gradio-container") ?? (e instanceof ShadowRoot ? e : document.body);
	}
	function fe(e) {
		let t = document.createElement("div");
		t.style.cssText = "position: fixed; top: 0; left: 0; width: 100%; height: 100%; visibility: hidden; pointer-events: none;", e.appendChild(t);
		let n = t.getBoundingClientRect();
		return t.remove(), n;
	}
	function pe(e) {
		let t = a(G).parentNode;
		if (!t || t === e) return !1;
		let n = fe(t), r = fe(e);
		return Math.abs(n.top - r.top) > 1 || Math.abs(n.left - r.left) > 1 || Math.abs(n.width - r.width) > 1 || Math.abs(n.height - r.height) > 1;
	}
	function me(e) {
		!a(G).parentNode || a(G).parentNode === e || (q = a(G).parentNode, J = document.createComment("fullscreen block"), q.insertBefore(J, a(G)), e.appendChild(a(G)));
	}
	function ve() {
		if (!q) return;
		let e = J && J.parentNode === q ? J : null;
		q.insertBefore(a(G), e), e?.remove(), q = null, J = null;
	}
	let Y = (e) => {
		if (e !== void 0) {
			if (typeof e == "number") return e + "px";
			if (typeof e == "string") return e;
		}
	}, X = (e) => {
		let t = e.clientY, n = (e) => {
			let n = e.clientY - t;
			t = e.clientY, ne(G, a(G).style.height = `${a(G).offsetHeight + n}px`);
		}, r = () => {
			window.removeEventListener("mousemove", n), window.removeEventListener("mouseup", r);
		};
		window.addEventListener("mousemove", n), window.addEventListener("mouseup", r);
	};
	_(() => (h(H()), a(U), a(G)), () => {
		if (H() !== a(U)) {
			if (l(U, H()), H()) {
				l(K, a(G).getBoundingClientRect()), l(ie, a(G).offsetHeight), l(ae, a(G).offsetWidth);
				let e = de();
				pe(e) && me(e), window.addEventListener("keydown", ue);
			} else ve(), l(K, null), window.removeEventListener("keydown", ue);
		}
	}), _(() => h(A()), () => {
		A() || z(!1);
	}), le(), D();
	var Z = m(), Q = b(Z), ye = (e) => {
		var t = ge(), u = b(t);
		se(u, () => re, !1, (e, t) => {
			te(e, (e) => l(G, e), () => a(G)), N(e, (e, t) => ({
				"data-testid": E(),
				id: v(),
				class: `block ${e ?? ""}`,
				dir: V() ? "rtl" : "ltr",
				"aria-label": ee(),
				style: "",
				[oe]: {
					hidden: A() === "hidden",
					padded: w(),
					flex: z(),
					border_focus: C() === "focus",
					border_contrast: C() === "contrast",
					"hide-container": !O() && !k(),
					fullscreen: H(),
					animating: H() && a(K) !== null,
					"auto-margin": L() === null
				},
				[j]: t
			}), [() => (h(y()), c(() => y()?.join(" ") || "")), () => ({
				height: (h(H()), h(s()), c(() => H() ? void 0 : Y(s()))),
				"min-height": (h(H()), h(d()), c(() => H() ? void 0 : Y(d()))),
				"max-height": (h(H()), h(f()), c(() => H() ? void 0 : Y(f()))),
				"--start-top": (a(K), c(() => a(K) ? `${a(K).top}px` : "0px")),
				"--start-left": (a(K), c(() => a(K) ? `${a(K).left}px` : "0px")),
				"--start-width": (a(K), c(() => a(K) ? `${a(K).width}px` : "0px")),
				"--start-height": (a(K), c(() => a(K) ? `${a(K).height}px` : "0px")),
				width: (h(H()), h(g()), c(() => H() ? void 0 : typeof g() == "number" ? `calc(min(${g()}px, 100%))` : Y(g()))),
				"border-style": x(),
				overflow: F() ? I() : "hidden",
				"flex-grow": L(),
				"min-width": `calc(min(${R()}px, 100%))`
			})], void 0, void 0, "svelte-1stq1b1");
			var n = ge(), u = b(n);
			ce(u, o, "default", {}, null);
			var m = S(u, 2), _ = (e) => {
				var t = he();
				p("mousedown", t, X), i(e, t);
			};
			r(m, (e) => {
				B() && e(_);
			}), i(t, n);
		});
		var m = S(u, 2), _ = (e) => {
			var t = _e();
			let r;
			n(() => r = P(t, "", r, {
				height: a(ie) + "px",
				width: a(ae) + "px"
			})), i(e, t);
		};
		r(m, (e) => {
			H() && e(_);
		}), i(e, t);
	};
	r(Q, (e) => {
		(A() === !0 || A() === "hidden") && e(ye);
	}), i(t, Z), e();
}
//#endregion
//#region frontend/node_modules/@gradio/atoms/dist/src/SelectSource.svelte
R(["click"]), R(["click"]);
var Y = new class {
	#e;
	get playing() {
		return a(this.#e);
	}
	set playing(e) {
		l(this.#e, e, !0);
	}
	#t;
	get offset() {
		return a(this.#t);
	}
	set offset(e) {
		l(this.#t, e, !0);
	}
	#n;
	get loopFrom() {
		return a(this.#n);
	}
	set loopFrom(e) {
		l(this.#n, e, !0);
	}
	#r;
	get loopTo() {
		return a(this.#r);
	}
	set loopTo(e) {
		l(this.#r, e, !0);
	}
	#i;
	get levels() {
		return a(this.#i);
	}
	set levels(e) {
		l(this.#i, e, !0);
	}
	#a;
	get repeat() {
		return a(this.#a);
	}
	set repeat(e) {
		l(this.#a, e, !0);
	}
	constructor() {
		this.context = null, this.master = null, this.buffers = {}, this.gains = {}, this.sources = [], this.startedAt = 0, this.fingerprint = "", this.selectionFingerprint = "", this.#e = w(!1), this.#t = w(0), this.#n = w(null), this.#r = w(null), this.#i = w(o({})), this.anchor = null, this.#a = w(!0);
	}
	position() {
		if (!this.context || !this.playing) return this.offset;
		let e = this.offset + (this.context.currentTime - this.startedAt);
		if (this.loopFrom !== null && this.loopTo !== null && e > this.loopTo) {
			let t = this.loopTo - this.loopFrom;
			e = this.loopFrom + (e - this.loopFrom) % t;
		}
		return e;
	}
	bytesFrom(e) {
		let t = atob(e), n = new Uint8Array(t.length);
		for (let e = 0; e < t.length; e++) n[e] = t.charCodeAt(e);
		return n.buffer;
	}
	computeFingerprint(e) {
		return e.map((e) => {
			let t = e.wav;
			return e.name + ":" + t.length + ":" + t.slice(0, 24) + ":" + t.slice(-24);
		}).join("|");
	}
	noteLayers(e) {
		let t = this.computeFingerprint(e);
		t !== this.selectionFingerprint && (this.clearLoop(), this.selectionFingerprint = t);
	}
	async ensureAudio(e) {
		if (!this.context) {
			this.context = new (window.AudioContext || window.webkitAudioContext)();
			let e = this.context.createGain();
			e.gain.value = .7;
			let t = this.context.createDynamicsCompressor();
			t.threshold.value = -6, t.knee.value = 0, t.ratio.value = 20, t.attack.value = .003, t.release.value = .15, e.connect(t), t.connect(this.context.destination), this.master = e;
		}
		let t = this.computeFingerprint(e);
		if (this.fingerprint !== t) {
			for (let e of Object.keys(this.gains)) this.gains[e].disconnect();
			this.buffers = {}, this.gains = {};
			for (let t of e) {
				let e = this.context.createGain();
				e.gain.value = this.levels[t.name] ?? t.level, e.connect(this.master), this.gains[t.name] = e, this.buffers[t.name] = await this.context.decodeAudioData(this.bytesFrom(t.wav));
			}
			this.fingerprint = t;
		}
	}
	stopSources() {
		for (let e of this.sources) {
			e.onended = null;
			try {
				e.stop();
			} catch {}
			e.disconnect();
		}
		this.sources = [];
	}
	async play(e, t) {
		let n = t ?? this.offset;
		if (this.stopSources(), this.playing = !1, await this.ensureAudio(e), this.context) {
			this.context.state === "suspended" && await this.context.resume(), this.offset = n, this.startedAt = this.context.currentTime, this.playing = !0;
			for (let t of e) {
				let e = this.context.createBufferSource();
				e.buffer = this.buffers[t.name], this.loopFrom !== null && this.loopTo !== null && this.repeat && (e.loop = !0, e.loopStart = this.loopFrom, e.loopEnd = this.loopTo), e.connect(this.gains[t.name]), e.start(this.startedAt, this.offset), this.loopFrom !== null && this.loopTo !== null && !this.repeat && e.stop(this.startedAt + (this.loopTo - this.offset)), this.sources.push(e);
			}
			this.sources.length && (this.sources[0].onended = () => {
				this.playing = !1;
			});
		}
	}
	stop() {
		this.offset = this.position(), this.stopSources(), this.playing = !1;
	}
	select(e, t) {
		let n = this.loopFrom !== null && this.loopTo !== null, r = this.loopFrom, i = this.loopTo, a = n && e.start >= this.loopFrom - .001 && e.end <= this.loopTo + .001;
		if (t && this.anchor !== null && !n) {
			let t = Math.min(this.anchor.start, e.start), n = Math.max(this.anchor.end, e.end);
			this.loopFrom = t, this.loopTo = Math.max(n, t + .05), this.offset = this.loopFrom;
		} else !t && a ? this.offset = e.start : (this.anchor = e, this.loopFrom = e.start, this.loopTo = null, this.offset = e.start);
		return this.stopSources(), this.playing = !1, this.loopFrom !== r || this.loopTo !== i;
	}
	clearLoop() {
		this.anchor = null, this.loopFrom = null, this.loopTo = null, this.offset = 0, this.stopSources(), this.playing = !1;
	}
	setLevel(e, t) {
		this.levels[e] = t, this.gains[e] && this.context && this.gains[e].gain.setTargetAtTime(t, this.context.currentTime, .01);
	}
}(), X = o({
	strip: !0,
	faders: !0,
	phrases: !0,
	notes: !1,
	lyrics: !0,
	instruments: !0
}), Z = o({
	Melody: !0,
	"Harmony above": !1,
	"Harmony below": !1,
	Bass: !1
}), Q = o({ value: !1 }), ye = o({ value: !1 }), be = o({ value: !0 }), xe = /* @__PURE__ */ new Set([
	"Piano",
	"Guitar",
	"Ukulele"
]), Se = o({});
o({});
function Ce(e) {
	e in Se || (Se[e] = xe.has(e));
}
var $ = o({
	scale: !1,
	chordNotes: !1,
	chordShape: !0
}), we = o({ value: !1 }), Te = o({ value: !1 }), Ee = o({ value: "wrap" }), De = z("<label class=\"repeat svelte-d89286\"><input type=\"checkbox\" class=\"svelte-d89286\"/> Repeat</label>"), Oe = z("<label class=\"repeat svelte-d89286\"><input type=\"checkbox\" class=\"svelte-d89286\"/> Follow</label>"), ke = z("<div class=\"transport svelte-d89286\"><button class=\"svelte-d89286\">Play</button> <button class=\"svelte-d89286\">Stop</button> <button class=\"svelte-d89286\">Clear selection</button> <!> <span class=\"time svelte-d89286\"> </span> <!></div>");
function Ae(t, a) {
	M(a, !0);
	let o = W(a, "follow", 15);
	var c = ke(), l = s(c), u = S(l, 2), d = S(u, 2), p = S(d, 2), m = (e) => {
		var t = De(), n = s(t);
		U(n), G(), L(t), f("change", n, function(...e) {
			a.onToggleRepeat?.apply(this, e);
		}), A(n, () => Y.repeat, (e) => Y.repeat = e), i(e, t);
	};
	r(p, (e) => {
		Y.loopFrom !== null && Y.loopTo !== null && e(m);
	});
	var h = S(p, 2), g = s(h);
	L(h);
	var _ = S(h, 2), v = (e) => {
		var t = Oe(), n = s(t);
		U(n), G(), L(t), A(n, o), i(e, t);
	};
	r(_, (e) => {
		a.hasTimeline && e(v);
	}), L(c), n((e) => y(g, `${e ?? ""}s`), [() => a.playhead.toFixed(1)]), f("click", l, () => Y.play(a.layers)), f("click", u, () => Y.stop()), f("click", d, function(...e) {
		a.onClearSelection?.apply(this, e);
	}), i(t, c), e();
}
R(["click", "change"]);
//#endregion
//#region frontend/PanelToggles.svelte
var je = z("<label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Chart</label>"), Me = z("<label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Phrases</label> <label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Visual notes</label> <label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Lyrics</label>", 1), Ne = z("<label><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Shrink to fit</label>"), Pe = z("<label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Instruments</label> <label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Beside mixer</label> <!>", 1), Fe = z("<div class=\"panel-toggles svelte-1mngm7u\"><!> <!> <label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Mixer</label> <!></div>");
function Ie(t, a) {
	M(a, !0);
	let o = W(a, "narrow", 3, !1);
	var c = Fe(), l = s(c), u = (e) => {
		var t = je(), n = s(t);
		U(n), G(), L(t), A(n, () => X.strip, (e) => X.strip = e), i(e, t);
	};
	r(l, (e) => {
		a.hasTimeline && e(u);
	});
	var d = S(l, 2), p = (e) => {
		var t = Me(), n = b(t), r = s(n);
		U(r), G(), L(n);
		var a = S(n, 2), o = s(a);
		U(o), G(), L(a);
		var c = S(a, 2), l = s(c);
		U(l), G(), L(c), A(r, () => X.phrases, (e) => X.phrases = e), A(o, () => X.notes, (e) => X.notes = e), A(l, () => X.lyrics, (e) => X.lyrics = e), i(e, t);
	};
	r(d, (e) => {
		a.hasNotes && e(p);
	});
	var m = S(d, 2), h = s(m);
	U(h), G(), L(m);
	var g = S(m, 2), _ = (e) => {
		var t = Pe(), a = b(t), c = s(a);
		U(c), G(), L(a);
		var l = S(a, 2), u = s(l);
		U(u), G(), L(l);
		var d = S(l, 2), p = (e) => {
			var t = Ne();
			let r;
			var a = s(t);
			U(a), G(), L(t), n(() => {
				r = E(t, 1, "panel-toggle svelte-1mngm7u", null, r, { disabled: o() }), F(a, Ee.value === "shrink"), a.disabled = o();
			}), f("change", a, (e) => Ee.value = e.currentTarget.checked ? "shrink" : "wrap"), i(e, t);
		};
		r(d, (e) => {
			Te.value && e(p);
		}), A(c, () => X.instruments, (e) => X.instruments = e), A(u, () => Te.value, (e) => Te.value = e), i(e, t);
	};
	r(g, (e) => {
		a.hasDiagrams && e(_);
	}), L(c), A(h, () => X.faders, (e) => X.faders = e), i(t, c), e();
}
R(["change"]);
//#endregion
//#region frontend/ChordStrip.svelte
var Le = z("<button type=\"button\"><div class=\"number svelte-65z4tz\"> </div> <div class=\"chord svelte-65z4tz\"> </div> <div class=\"words svelte-65z4tz\"> </div></button>"), Re = z("<div class=\"strip svelte-65z4tz\"></div> <p class=\"note svelte-65z4tz\"> </p>", 1);
function ze(t, o) {
	M(o, !0);
	let c = C(() => o.timeline.find((e) => o.playhead >= e.start && o.playhead < e.end)), l = C(() => Y.loopFrom === null ? o.timeline.length ? "Click a bar to select where Play starts. Shift-click a later bar to loop a stretch." : "" : Y.loopTo === null ? `Play starts at ${Y.loopFrom.toFixed(1)}s. Shift-click a later bar to select a stretch, or press Play.` : Y.repeat ? `Repeating ${Y.loopFrom.toFixed(1)}s to ${Y.loopTo.toFixed(1)}s. Untick Repeat to play it once, or Clear selection to release it.` : `Selected ${Y.loopFrom.toFixed(1)}s to ${Y.loopTo.toFixed(1)}s, playing once. Tick Repeat to loop it.`), u = {};
	x(() => {
		o.follow && a(c) && u[a(c).bar] && u[a(c).bar].scrollIntoView({
			behavior: "smooth",
			inline: "center",
			block: "nearest"
		});
	});
	var d = m(), p = b(d), h = (e) => {
		var t = Re(), r = b(t);
		K(r, 21, () => o.timeline, (e) => e.bar, (e, t) => {
			var r = Le();
			let l;
			var d = s(r), p = s(d, !0);
			L(d);
			var m = S(d, 2), h = s(m, !0);
			L(m);
			var g = S(m, 2), _ = s(g, !0);
			L(g), L(r), te(r, (e, t) => u[t.bar] = e, (e) => u?.[e.bar], () => [a(t)]), n(() => {
				l = E(r, 1, "bar svelte-65z4tz", null, l, {
					playing: a(c) === a(t),
					looped: Y.loopFrom !== null && Y.loopTo !== null && a(t).start >= Y.loopFrom - .001 && a(t).end <= Y.loopTo + .001
				}), V(r, "data-bar", a(t).bar), y(p, a(t).bar), y(h, a(t).name), y(_, a(t).words);
			}), f("click", r, (e) => o.onSelectBar(a(t), e)), f("keydown", r, (e) => {
				(e.key === "Enter" || e.key === " ") && (e.preventDefault(), o.onSelectBar(a(t), e));
			}), i(e, r);
		}), L(r);
		var d = S(r, 2), p = s(d, !0);
		L(d), n(() => y(p, a(l))), i(e, t);
	};
	r(p, (e) => {
		o.timeline.length && e(h);
	}), i(t, d), e();
}
R(["click", "keydown"]);
//#endregion
//#region frontend/FaderPanel.svelte
var Be = z("<div class=\"fader-row svelte-ma6git\"><span class=\"name svelte-ma6git\"> </span> <button class=\"mute svelte-ma6git\">M</button> <input type=\"range\" min=\"0\" max=\"1\" step=\"0.05\" class=\"svelte-ma6git\"/> <span class=\"value svelte-ma6git\"> </span></div>"), Ve = z("<div class=\"faders\"></div>");
function He(t, r) {
	M(r, !0);
	function o(e, t) {
		Y.levels[e] = Y.levels[e] > 0 ? 0 : t, r.onLevelChanged(e);
	}
	var c = Ve();
	K(c, 21, () => r.layers, (e) => e.name, (e, t) => {
		var c = Be(), l = s(c), u = s(l, !0);
		L(l);
		var d = S(l, 2), p = S(d, 2);
		U(p);
		var m = S(p, 2), h = s(m);
		L(m), L(c), n((e) => {
			P(l, `color:${a(t).colour ?? ""}`), y(u, a(t).name), y(h, `${e ?? ""}%`);
		}, [() => Math.round((Y.levels[a(t).name] ?? 0) * 100)]), f("click", d, () => o(a(t).name, a(t).level)), f("input", p, () => r.onLevelChanged(a(t).name)), B(p, () => Y.levels[a(t).name], (e) => Y.levels[a(t).name] = e), i(e, c);
	}), L(c), i(t, c), e();
}
R(["click", "input"]);
//#endregion
//#region frontend/NotesPanel.svelte
var Ue = t("<rect class=\"loop-region svelte-1nlxyec\" y=\"0\"></rect>"), We = t("<line class=\"bar-line svelte-1nlxyec\" y1=\"0\"></line>"), Ge = t("<text class=\"note-label svelte-1nlxyec\"> </text>"), Ke = t("<text class=\"note-word svelte-1nlxyec\"> </text>"), qe = t("<g><rect class=\"note-box svelte-1nlxyec\"></rect><!><!></g>"), Je = t("<line class=\"playhead svelte-1nlxyec\" y1=\"0\"></line>"), Ye = t("<svg><!><!><!><!></svg>"), Xe = z("<label class=\"layer-toggle svelte-1nlxyec\"><input type=\"checkbox\" class=\"svelte-1nlxyec\"/> </label>"), Ze = z("<label><input type=\"checkbox\" class=\"svelte-1nlxyec\"/> Side by side</label>"), Qe = z("<div class=\"notes-container next-page svelte-1nlxyec\"><!></div>"), $e = z("<div><div class=\"notes-container svelte-1nlxyec\"><!></div> <!></div>"), et = z("<p class=\"note-empty svelte-1nlxyec\">No layers selected to show.</p>"), tt = z("<div class=\"notes-toggles svelte-1nlxyec\"><!> <label class=\"layer-toggle preview-toggle svelte-1nlxyec\"><input type=\"checkbox\" class=\"svelte-1nlxyec\"/> Preview next phrase</label> <!> <label class=\"layer-toggle svelte-1nlxyec\"><input type=\"checkbox\" class=\"svelte-1nlxyec\"/> Word labels</label></div> <!>", 1);
function nt(t, o) {
	M(o, !0);
	let c = (e, t = O, c = O, l = O) => {
		var u = Ye();
		let f;
		var p = s(u), m = (e) => {
			var r = Ue();
			n((e, n) => {
				V(r, "x", e), V(r, "width", n), V(r, "height", t().height);
			}, [() => F(t(), Math.max(Y.loopFrom, t().phrase.start)), () => Math.max(0, F(t(), Math.min(Y.loopTo, t().phrase.end)) - F(t(), Math.max(Y.loopFrom, t().phrase.start)))]), i(e, r);
		};
		r(p, (e) => {
			c() && Y.loopFrom !== null && Y.loopTo !== null && e(m);
		});
		var h = S(p);
		K(h, 17, () => t().bars, v, (e, r) => {
			var o = We();
			n((e, n) => {
				V(o, "x1", e), V(o, "x2", n), V(o, "y2", t().height);
			}, [() => F(t(), a(r).start), () => F(t(), a(r).start)]), i(e, o);
		});
		var _ = S(h);
		K(_, 17, () => t().notes, v, (e, o) => {
			var c = qe(), l = s(c);
			V(l, "height", d - 2);
			var u = S(l), f = (e) => {
				var r = Ge(), c = s(r, !0);
				L(r), n((e, t, n) => {
					V(r, "x", e), V(r, "y", t), V(r, "fill", a(o).colour), y(c, n);
				}, [
					() => F(t(), a(o).start) + a(o).length * t().pxPerSecond / 2,
					() => P(t(), a(o).midi) + d / 2,
					() => g(a(o).midi)
				]), i(e, r);
			};
			r(u, (e) => {
				a(o).length * t().pxPerSecond > 20 && e(f);
			});
			var p = S(u), m = (e) => {
				var r = Ke(), c = s(r, !0);
				L(r), n((e, t) => {
					V(r, "x", e), V(r, "y", t), y(c, a(o).word);
				}, [() => F(t(), a(o).start) + a(o).length * t().pxPerSecond / 2, () => P(t(), a(o).midi) + d + 10]), i(e, r);
			};
			r(p, (e) => {
				a(o).word && be.value && e(m);
			}), L(c), n((e, t, n) => {
				V(l, "x", e), V(l, "y", t), V(l, "width", n), V(l, "fill", a(o).colour), V(l, "fill-opacity", a(o).layer === "Melody" ? .22 : .14), V(l, "stroke", a(o).colour);
			}, [
				() => F(t(), a(o).start),
				() => P(t(), a(o).midi) + 1,
				() => Math.max(a(o).length * t().pxPerSecond - 1, 2)
			]), i(e, c);
		});
		var b = S(_), x = (e) => {
			var r = Je();
			n((e, n) => {
				V(r, "x1", e), V(r, "x2", n), V(r, "y2", t().height);
			}, [() => F(t(), o.playhead), () => F(t(), o.playhead)]), i(e, r);
		};
		r(b, (e) => {
			c() && e(x);
		}), L(u), n(() => {
			V(u, "width", t().width), V(u, "height", t().height), V(u, "viewBox", `0 0 ${t().width ?? ""} ${t().height ?? ""}`), f = E(u, 0, "svelte-1nlxyec", null, f, { dimmed: l() });
		}), i(e, u);
	}, u = W(o, "narrow", 3, !1), d = 14, f = C(() => o.phrases.length ? o.phrases : o.notes.length ? [{
		start: 0,
		end: o.notes.reduce((e, t) => Math.max(e, t.start + t.length), 0),
		label: "1. Whole part"
	}] : []), p = C(() => {
		if (!a(f).length) return -1;
		let e = a(f).findIndex((e) => o.playhead < e.end);
		return e === -1 ? a(f).length - 1 : e;
	}), m = C(() => a(p) >= 0 ? a(f)[a(p)] : null), h = C(() => a(p) >= 0 && a(p) + 1 < a(f).length ? a(f)[a(p) + 1] : null);
	function g(e) {
		return [
			"C",
			"C#",
			"D",
			"D#",
			"E",
			"F",
			"F#",
			"G",
			"G#",
			"A",
			"A#",
			"B"
		][e % 12] + Math.floor(e / 12 - 1);
	}
	let _ = w(null), T = w(600);
	x(() => {
		a(_) && l(T, a(_).clientWidth || a(T), !0);
	});
	function D(e, t) {
		if (!e) return null;
		let n = o.timeline.filter((t) => t.start < e.end && t.end > e.start), r = o.notes.filter((t) => Z[t.layer] && t.start >= e.start && t.start < e.end), i = 60, a = 72;
		if (r.length) {
			i = r[0].midi, a = r[0].midi;
			for (let e of r) e.midi < i && (i = e.midi), e.midi > a && (a = e.midi);
			--i, a += 1;
		}
		let s = (a - i + 1) * 14, c = e.end - e.start, l = c > 0 ? t / c : 60;
		return {
			phrase: e,
			bars: n,
			notes: r,
			pitchRange: {
				lowest: i,
				highest: a
			},
			width: t,
			height: s,
			pxPerSecond: l
		};
	}
	let k = C(() => Q.value && ye.value && !u()), j = C(() => {
		let e = a(k) ? (a(T) - 8) / 2 : a(T);
		return D(a(m), e);
	}), N = C(() => {
		if (!Q.value) return null;
		let e = a(k) ? (a(T) - 8) / 2 : a(T);
		return D(a(h), e);
	});
	function P(e, t) {
		return (e.pitchRange.highest - t) * 14;
	}
	function F(e, t) {
		return (t - e.phrase.start) * e.pxPerSecond;
	}
	var I = tt(), R = b(I), z = s(R);
	K(z, 17, () => Object.keys(Z), v, (e, t) => {
		var r = Xe(), o = s(r);
		U(o);
		var c = S(o);
		L(r), n(() => y(c, ` ${a(t) ?? ""}`)), A(o, () => Z[a(t)], (e) => Z[a(t)] = e), i(e, r);
	});
	var B = S(z, 2), H = s(B);
	U(H), G(), L(B);
	var ee = S(B, 2), ne = (e) => {
		var t = Ze();
		let r;
		var a = s(t);
		U(a), G(), L(t), n(() => {
			r = E(t, 1, "layer-toggle svelte-1nlxyec", null, r, { disabled: u() }), a.disabled = u();
		}), A(a, () => ye.value, (e) => ye.value = e), i(e, t);
	};
	r(ee, (e) => {
		Q.value && e(ne);
	});
	var re = S(ee, 2), ie = s(re);
	U(ie), G(), L(re), L(R);
	var ae = S(R, 2), oe = (e) => {
		var t = $e();
		let o;
		var u = s(t), d = s(u);
		c(d, () => a(j), () => !0, () => !1), L(u);
		var f = S(u, 2), p = (e) => {
			var t = Qe(), n = s(t);
			c(n, () => a(N), () => !1, () => !0), L(t), i(e, t);
		};
		r(f, (e) => {
			a(N) && e(p);
		}), L(t), te(t, (e) => l(_, e), () => a(_)), n(() => o = E(t, 1, "pages svelte-1nlxyec", null, o, { row: a(k) })), i(e, t);
	}, se = (e) => {
		var t = et();
		i(e, t);
	};
	r(ae, (e) => {
		a(j) ? e(oe) : e(se, -1);
	}), A(H, () => Q.value, (e) => Q.value = e), A(ie, () => be.value, (e) => be.value = e), i(t, I), e();
}
//#endregion
//#region frontend/PhraseList.svelte
var rt = z("<option> </option>"), it = z("<select class=\"phrase-select svelte-8xxexk\"><option disabled=\"\" selected=\"\">Jump to phrase…</option><!></select>"), at = z("<button type=\"button\"> </button>"), ot = z("<div class=\"phrase-list svelte-8xxexk\"></div>");
function st(t, o) {
	M(o, !0);
	let c = W(o, "narrow", 3, !1), l = C(() => o.phrases.find((e) => o.playhead >= e.start && o.playhead < e.end));
	function u(e) {
		let t = Number(e.currentTarget.value);
		!Number.isNaN(t) && o.phrases[t] && o.onSelectPhrase(o.phrases[t], e);
	}
	var d = m(), p = b(d), h = (e) => {
		var t = m(), d = b(t), p = (e) => {
			var t = it(), r = s(t);
			r.value = r.__value = "";
			var c = S(r);
			K(c, 17, () => o.phrases, v, (e, t, r) => {
				var o = rt(), c = s(o, !0);
				L(o), o.value = o.__value = r, n(() => y(c, a(t).label)), i(e, o);
			}), L(t), f("change", t, u), i(e, t);
		}, h = (e) => {
			var t = ot();
			K(t, 21, () => o.phrases, v, (e, t) => {
				var r = at();
				let c;
				var u = s(r, !0);
				L(r), n(() => {
					c = E(r, 1, "phrase svelte-8xxexk", null, c, {
						playing: a(l) === a(t),
						looped: Y.loopFrom !== null && Y.loopTo !== null && a(t).start >= Y.loopFrom - .001 && a(t).end <= Y.loopTo + .001
					}), y(u, a(t).label);
				}), f("click", r, (e) => o.onSelectPhrase(a(t), e)), f("keydown", r, (e) => {
					(e.key === "Enter" || e.key === " ") && (e.preventDefault(), o.onSelectPhrase(a(t), e));
				}), i(e, r);
			}), L(t), i(e, t);
		};
		r(d, (e) => {
			c() ? e(p) : e(h, -1);
		}), i(e, t);
	};
	r(p, (e) => {
		o.phrases.length && e(h);
	}), i(t, d), e();
}
R([
	"change",
	"click",
	"keydown"
]);
//#endregion
//#region frontend/LyricsPanel.svelte
var ct = z("<span> </span>"), lt = z("<p class=\"sentence next svelte-4o08vh\"></p>"), ut = z("<div class=\"lyrics-panel svelte-4o08vh\"><p class=\"sentence current svelte-4o08vh\"></p> <!></div>"), dt = z("<p class=\"lyrics-empty svelte-4o08vh\">No lyrics to show yet.</p>");
function ft(t, o) {
	M(o, !0);
	let c = C(() => o.notes.filter((e) => e.layer === "Melody" && e.word)), l = C(() => o.phrases.length ? o.phrases : a(c).length ? [{
		start: 0,
		end: a(c).reduce((e, t) => Math.max(e, t.start + t.length), 0),
		label: "Whole part"
	}] : []), u = C(() => {
		if (!a(l).length) return -1;
		let e = a(l).findIndex((e) => o.playhead < e.end);
		return e === -1 ? a(l).length - 1 : e;
	}), d = C(() => a(u) >= 0 ? a(l)[a(u)] : null), f = C(() => a(u) >= 0 && a(u) + 1 < a(l).length ? a(l)[a(u) + 1] : null);
	function p(e) {
		return e ? a(c).filter((t) => t.start >= e.start && t.start < e.end) : [];
	}
	let h = C(() => p(a(d))), g = C(() => p(a(f)));
	function _(e) {
		return e?.endsWith("-") ? "" : " ";
	}
	var x = m(), w = b(x), T = (e) => {
		var t = ut(), c = s(t);
		K(c, 21, () => a(h), v, (e, t) => {
			var r = ct();
			let c;
			var l = s(r);
			L(r), n((e) => {
				c = E(r, 1, "sentence-word svelte-4o08vh", null, c, { sung: a(t).start <= o.playhead }), y(l, `${a(t).word ?? ""}${e ?? ""}`);
			}, [() => _(a(t).word)]), i(e, r);
		}), L(c);
		var l = S(c, 2), u = (e) => {
			var t = lt();
			K(t, 21, () => a(g), v, (e, t) => {
				var r = ct(), o = s(r);
				L(r), n((e) => y(o, `${a(t).word ?? ""}${e ?? ""}`), [() => _(a(t).word)]), i(e, r);
			}), L(t), i(e, t);
		};
		r(l, (e) => {
			a(g).length && e(u);
		}), L(t), i(e, t);
	}, D = (e) => {
		var t = dt();
		i(e, t);
	};
	r(w, (e) => {
		a(d) ? e(T) : e(D, -1);
	}), i(t, x), e();
}
//#endregion
//#region frontend/InstrumentPanel.svelte
var pt = z("<label class=\"instrument-toggle svelte-o1xgsa\"><input type=\"checkbox\" class=\"svelte-o1xgsa\"/> </label>"), mt = z("<p class=\"instrument-empty svelte-o1xgsa\">Choose an instrument to see it.</p>"), ht = z("<div class=\"layer stacked scale-layer svelte-o1xgsa\"></div>"), gt = z("<div class=\"layer stacked chord-notes-layer svelte-o1xgsa\"></div>"), _t = z("<div class=\"layer stacked chord-shape-layer svelte-o1xgsa\"></div>"), vt = z("<p class=\"instrument-note svelte-o1xgsa\"> </p>"), yt = z("<p class=\"next-chord-label svelte-o1xgsa\"> </p> <div class=\"diagram-stack next-chord-preview svelte-o1xgsa\"><div class=\"layer structure-layer svelte-o1xgsa\"></div> <!> <!> <!></div>", 1), bt = z("<p class=\"instrument-note svelte-o1xgsa\">Next: nothing after this.</p>"), xt = z("<div class=\"diagram-stack svelte-o1xgsa\"><div class=\"layer structure-layer svelte-o1xgsa\"></div> <!> <!> <!></div> <!> <!> <!>", 1), St = z("<p class=\"instrument-empty svelte-o1xgsa\">No picture for this instrument yet.</p>"), Ct = z("<div class=\"instrument-card svelte-o1xgsa\"><h4 class=\"svelte-o1xgsa\"> </h4> <!></div>"), wt = z("<div class=\"instrument-grid svelte-o1xgsa\"></div>"), Tt = z("<div class=\"instrument-toggles svelte-o1xgsa\"><!> <span class=\"layer-gap svelte-o1xgsa\"></span> <label class=\"instrument-toggle svelte-o1xgsa\"><input type=\"checkbox\" class=\"svelte-o1xgsa\"/> Scale</label> <label class=\"instrument-toggle svelte-o1xgsa\"><input type=\"checkbox\" class=\"svelte-o1xgsa\"/> Chord notes</label> <label class=\"instrument-toggle svelte-o1xgsa\"><input type=\"checkbox\" class=\"svelte-o1xgsa\"/> Chord shape</label> <span class=\"layer-gap svelte-o1xgsa\"></span> <label class=\"instrument-toggle svelte-o1xgsa\"><input type=\"checkbox\" class=\"svelte-o1xgsa\"/> Preview next chord</label></div> <!>", 1);
function Et(t, o) {
	M(o, !0);
	let c = C(() => Object.keys(o.diagrams.structure ?? {}));
	x(() => {
		for (let e of a(c)) Ce(e);
	});
	let l = C(() => o.timeline.findIndex((e) => o.playhead >= e.start && o.playhead < e.end)), u = C(() => a(l) >= 0 ? o.timeline[a(l)] : void 0), d = C(() => a(l) >= 0 && a(l) + 1 < o.timeline.length ? o.timeline[a(l) + 1] : void 0), f = C(() => a(c).filter((e) => Se[e]));
	var p = Tt(), h = b(p), g = s(h);
	K(g, 17, () => a(c), v, (e, t) => {
		var r = pt(), o = s(r);
		U(o);
		var c = S(o);
		L(r), n(() => y(c, ` ${a(t) ?? ""}`)), A(o, () => Se[a(t)], (e) => Se[a(t)] = e), i(e, r);
	});
	var _ = S(g, 4), w = s(_);
	U(w), G(), L(_);
	var T = S(_, 2), E = s(T);
	U(E), G(), L(T);
	var D = S(T, 2), O = s(D);
	U(O), G(), L(D);
	var j = S(D, 4), N = s(j);
	U(N), G(), L(j), L(h);
	var P = S(h, 2), F = (e) => {
		var t = mt();
		i(e, t);
	}, I = (e) => {
		var t = wt();
		K(t, 21, () => a(f), v, (e, t) => {
			let c = C(() => o.diagrams.structure?.[a(t)]), l = C(() => o.diagrams.scale?.[a(t)]), f = C(() => a(u) ? o.diagrams.chords?.[a(t)]?.[a(u).name] : void 0), p = C(() => a(u) ? o.diagrams.shapes?.[a(t)]?.[a(u).name] : void 0), h = C(() => a(d) ? o.diagrams.chords?.[a(t)]?.[a(d).name] : void 0), g = C(() => a(d) ? o.diagrams.shapes?.[a(t)]?.[a(d).name] : void 0);
			var _ = Ct(), v = s(_), x = s(v, !0);
			L(v);
			var w = S(v, 2), T = (e) => {
				var o = xt(), _ = b(o), v = s(_);
				k(v, () => a(c), !0), L(v);
				var x = S(v, 2), C = (e) => {
					var t = ht();
					k(t, () => a(l), !0), L(t), i(e, t);
				};
				r(x, (e) => {
					$.scale && a(l) && e(C);
				});
				var w = S(x, 2), T = (e) => {
					var t = gt();
					k(t, () => a(f), !0), L(t), i(e, t);
				};
				r(w, (e) => {
					$.chordNotes && a(f) && e(T);
				});
				var E = S(w, 2), D = (e) => {
					var t = _t();
					k(t, () => a(p), !0), L(t), i(e, t);
				};
				r(E, (e) => {
					$.chordShape && a(p) && e(D);
				}), L(_);
				var O = S(_, 2), A = (e) => {
					var t = vt(), r = s(t);
					L(t), n(() => y(r, `Chord notes: ${a(u) ? "no picture for this bar." : "nothing playing yet."}`)), i(e, t);
				};
				r(O, (e) => {
					$.chordNotes && !a(f) && e(A);
				});
				var j = S(O, 2), M = (e) => {
					var r = vt(), o = s(r);
					L(r), n(() => y(o, `Chord shape: ${a(u) ? `no standard shape for ${a(u).name} on ${a(t)}.` : "nothing playing yet."}`)), i(e, r);
				};
				r(j, (e) => {
					$.chordShape && !a(p) && e(M);
				});
				var N = S(j, 2), P = (e) => {
					var t = m(), o = b(t), u = (e) => {
						var t = yt(), o = b(t), u = s(o);
						L(o);
						var f = S(o, 2), p = s(f);
						k(p, () => a(c), !0), L(p);
						var m = S(p, 2), _ = (e) => {
							var t = ht();
							k(t, () => a(l), !0), L(t), i(e, t);
						};
						r(m, (e) => {
							$.scale && a(l) && e(_);
						});
						var v = S(m, 2), x = (e) => {
							var t = gt();
							k(t, () => a(h), !0), L(t), i(e, t);
						};
						r(v, (e) => {
							$.chordNotes && a(h) && e(x);
						});
						var C = S(v, 2), w = (e) => {
							var t = _t();
							k(t, () => a(g), !0), L(t), i(e, t);
						};
						r(C, (e) => {
							$.chordShape && a(g) && e(w);
						}), L(f), n(() => y(u, `Next: ${a(d).name ?? ""}`)), i(e, t);
					}, f = (e) => {
						var t = bt();
						i(e, t);
					};
					r(o, (e) => {
						a(d) ? e(u) : e(f, -1);
					}), i(e, t);
				};
				r(N, (e) => {
					we.value && e(P);
				}), i(e, o);
			}, E = (e) => {
				var t = St();
				i(e, t);
			};
			r(w, (e) => {
				a(c) ? e(T) : e(E, -1);
			}), L(_), n(() => y(x, a(t))), i(e, _);
		}), L(t), i(e, t);
	};
	r(P, (e) => {
		a(f).length ? e(I, -1) : e(F);
	}), A(w, () => $.scale, (e) => $.scale = e), A(E, () => $.chordNotes, (e) => $.chordNotes = e), A(O, () => $.chordShape, (e) => $.chordShape = e), A(N, () => we.value, (e) => we.value = e), i(t, p), e();
}
//#endregion
//#region frontend/Index.svelte
var Dt = /* @__PURE__ */ new Set([
	"$$slots",
	"$$events",
	"$$legacy"
]), Ot = z("<div class=\"mixer-and-instruments-item svelte-r41nsf\"><!></div>"), kt = z("<div><!> <!></div>"), At = z("<div class=\"mixer svelte-r41nsf\"><button type=\"button\" class=\"fullscreen-toggle svelte-r41nsf\"> </button> <!> <!> <!> <!> <!> <!> <!></div>");
function jt(t, c) {
	M(c, !0);
	let u = new me(I(c, Dt)), d = C(() => u.props.value?.layers ?? []), p = C(() => u.props.value?.timeline ?? []), m = C(() => u.props.value?.notes ?? []), h = C(() => u.props.value?.phrases ?? []), g = C(() => u.props.value?.diagrams ?? {
		structure: {},
		scale: {},
		chords: {},
		shapes: {}
	}), _ = w(0), v = C(() => a(_) > 0 && a(_) < 600);
	Y.noteLayers(a(d)), x(() => {
		for (let e of a(d)) e.name in Y.levels || (Y.levels[e.name] = e.level);
	}), u.props.value?.loop_start != null && Y.loopFrom === null && (Y.loopFrom = u.props.value.loop_start, Y.loopTo = u.props.value.loop_end ?? null);
	let b = w(o(Y.position())), T = null;
	function D() {
		l(b, Y.position(), !0), T = requestAnimationFrame(D);
	}
	D(), ie(() => {
		T !== null && cancelAnimationFrame(T);
	});
	let O = w(!0);
	function k() {
		u.props.value && (u.props.value.loop_start = Y.loopFrom, u.props.value.loop_end = Y.loopTo), u.dispatch("change");
	}
	function A(e, t) {
		let n = Y.playing, r = Y.select(e, t.shiftKey);
		l(b, Y.position(), !0), r && k(), n && Y.play(a(d));
	}
	function j(e, t) {
		let n = Y.select(e, t.shiftKey);
		l(b, Y.position(), !0), n && k(), Y.play(a(d));
	}
	function N() {
		Y.clearLoop(), l(b, 0), k();
	}
	function P() {
		Y.playing && Y.play(a(d), Y.position());
	}
	function F(e) {
		Y.setLevel(e, Y.levels[e]), u.dispatch("input");
	}
	let R = w(!1);
	function z() {
		let e = u.shared.elem_id;
		return e ? document.getElementById(e) : null;
	}
	function B() {
		var e;
		(e = document.getElementById("playback")) == null || e.scrollIntoView({ behavior: "smooth" });
	}
	function ee() {
		let e = z();
		e && (l(R, e.classList.toggle("fullscreen-mode"), !0), document.body.style.overflow = a(R) ? "hidden" : "", a(R) || B());
	}
	H(() => {
		function e(e) {
			var t;
			e.key !== "Escape" || !a(R) || ((t = z()) == null || t.classList.remove("fullscreen-mode"), document.body.style.overflow = "", l(R, !1), B());
		}
		return window.addEventListener("keydown", e), () => window.removeEventListener("keydown", e);
	}), ve(t, {
		get visible() {
			return u.shared.visible;
		},
		get elem_id() {
			return u.shared.elem_id;
		},
		get elem_classes() {
			return u.shared.elem_classes;
		},
		get scale() {
			return u.shared.scale;
		},
		get min_width() {
			return u.shared.min_width;
		},
		allow_overflow: !0,
		padding: !0,
		children: (e, t) => {
			var o = At(), c = s(o), u = s(c, !0);
			L(c);
			var x = S(c, 2);
			{
				let e = C(() => a(p).length > 0);
				Ae(x, {
					get layers() {
						return a(d);
					},
					get playhead() {
						return a(b);
					},
					get hasTimeline() {
						return a(e);
					},
					onClearSelection: N,
					onToggleRepeat: P,
					get follow() {
						return a(O);
					},
					set follow(e) {
						l(O, e, !0);
					}
				});
			}
			var w = S(x, 2);
			{
				let e = C(() => a(p).length > 0), t = C(() => a(m).length > 0), n = C(() => Object.keys(a(g).structure ?? {}).length > 0);
				Ie(w, {
					get hasTimeline() {
						return a(e);
					},
					get hasNotes() {
						return a(t);
					},
					get hasDiagrams() {
						return a(n);
					},
					get narrow() {
						return a(v);
					}
				});
			}
			var T = S(w, 2), D = (e) => {
				ze(e, {
					get timeline() {
						return a(p);
					},
					get playhead() {
						return a(b);
					},
					get follow() {
						return a(O);
					},
					onSelectBar: A
				});
			};
			r(T, (e) => {
				X.strip && e(D);
			});
			var k = S(T, 2), M = (e) => {
				st(e, {
					get phrases() {
						return a(h);
					},
					get playhead() {
						return a(b);
					},
					onSelectPhrase: j,
					get narrow() {
						return a(v);
					}
				});
			};
			r(k, (e) => {
				X.phrases && e(M);
			});
			var I = S(k, 2), z = (e) => {
				nt(e, {
					get notes() {
						return a(m);
					},
					get timeline() {
						return a(p);
					},
					get phrases() {
						return a(h);
					},
					get playhead() {
						return a(b);
					},
					get narrow() {
						return a(v);
					}
				});
			};
			r(I, (e) => {
				X.notes && e(z);
			});
			var B = S(I, 2), H = (e) => {
				ft(e, {
					get notes() {
						return a(m);
					},
					get phrases() {
						return a(h);
					},
					get playhead() {
						return a(b);
					}
				});
			};
			r(B, (e) => {
				X.lyrics && e(H);
			});
			var te = S(B, 2), U = (e) => {
				var t = kt();
				let o;
				var c = s(t), l = (e) => {
					var t = Ot();
					He(s(t), {
						get layers() {
							return a(d);
						},
						onLevelChanged: F
					}), L(t), i(e, t);
				};
				r(c, (e) => {
					X.faders && e(l);
				});
				var u = S(c, 2), f = (e) => {
					var t = Ot();
					Et(s(t), {
						get diagrams() {
							return a(g);
						},
						get timeline() {
							return a(p);
						},
						get playhead() {
							return a(b);
						}
					}), L(t), i(e, t);
				};
				r(u, (e) => {
					X.instruments && e(f);
				}), L(t), n(() => o = E(t, 1, "mixer-and-instruments svelte-r41nsf", null, o, {
					beside: Te.value && X.faders && X.instruments,
					shrink: Ee.value === "shrink" && !a(v)
				})), i(e, t);
			};
			r(te, (e) => {
				(X.faders || X.instruments) && e(U);
			}), L(o), n(() => {
				V(c, "aria-pressed", a(R)), V(c, "title", a(R) ? "Exit full screen" : "Full screen"), y(u, a(R) ? "✕ Exit full screen" : "⛶ Full screen");
			}), f("click", c, ee), re(o, "clientWidth", (e) => l(_, e)), i(e, o);
		},
		$$slots: { default: !0 }
	}), e();
}
R(["click"]);
//#endregion
export { jt as default };

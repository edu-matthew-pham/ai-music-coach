import { E as e, O as t, pt as n } from "./index-client-BRpZvA76.js";
//#region frontend/node_modules/svelte/src/internal/disclose-version.js
var r = /* @__PURE__ */ n({});
typeof window < "u" && ((window.__svelte ??= {}).v ??= /* @__PURE__ */ new Set()).add("5");
//#endregion
export { r as SVELTE_VERSION, e as mount, t as unmount };

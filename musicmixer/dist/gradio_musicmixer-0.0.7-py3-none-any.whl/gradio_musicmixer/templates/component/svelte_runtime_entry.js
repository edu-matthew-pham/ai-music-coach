import { D as e, T as t, lt as n } from "./index-client-BTU3tcib.js";
//#region frontend/node_modules/svelte/src/internal/disclose-version.js
var r = /* @__PURE__ */ n({});
typeof window < "u" && ((window.__svelte ??= {}).v ??= /* @__PURE__ */ new Set()).add("5");
//#endregion
export { r as SVELTE_VERSION, t as mount, e as unmount };

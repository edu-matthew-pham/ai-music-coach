import { E as e, st as t, w as n } from "./index-client-DUx16LAy.js";
//#region frontend/node_modules/svelte/src/internal/disclose-version.js
var r = /* @__PURE__ */ t({});
typeof window < "u" && ((window.__svelte ??= {}).v ??= /* @__PURE__ */ new Set()).add("5");
//#endregion
export { r as SVELTE_VERSION, n as mount, e as unmount };

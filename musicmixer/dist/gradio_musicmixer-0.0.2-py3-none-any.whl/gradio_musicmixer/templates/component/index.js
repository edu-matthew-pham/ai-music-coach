import { $ as e, A as t, B as n, D as r, E as i, F as a, G as o, H as s, I as c, J as l, K as u, L as d, M as f, N as p, O as m, P as h, Q as g, R as _, S as v, U as y, V as b, W as x, X as S, Y as C, Z as w, _ as T, a as E, b as D, c as ee, d as te, et as O, f as k, g as A, h as j, i as ne, it as M, j as N, k as P, l as re, m as F, n as I, nt as L, o as ie, p as R, q as z, r as ae, rt as B, s as V, t as H, tt as U, u as oe, v as se, w as W, x as G, y as ce, z as K } from "./index-client-CwisJ_DC.js";
//#region frontend/node_modules/@gradio/theme/dist/src/colors.js
var q = [
	{
		color: "red",
		primary: 600,
		secondary: 100
	},
	{
		color: "green",
		primary: 600,
		secondary: 100
	},
	{
		color: "blue",
		primary: 600,
		secondary: 100
	},
	{
		color: "yellow",
		primary: 500,
		secondary: 100
	},
	{
		color: "purple",
		primary: 600,
		secondary: 100
	},
	{
		color: "teal",
		primary: 600,
		secondary: 100
	},
	{
		color: "orange",
		primary: 600,
		secondary: 100
	},
	{
		color: "cyan",
		primary: 600,
		secondary: 100
	},
	{
		color: "lime",
		primary: 500,
		secondary: 100
	},
	{
		color: "pink",
		primary: 600,
		secondary: 100
	}
], J = {
	inherit: "inherit",
	current: "currentColor",
	transparent: "transparent",
	black: "#000",
	white: "#fff",
	slate: {
		50: "#f8fafc",
		100: "#f1f5f9",
		200: "#e2e8f0",
		300: "#cbd5e1",
		400: "#94a3b8",
		500: "#64748b",
		600: "#475569",
		700: "#334155",
		800: "#1e293b",
		900: "#0f172a",
		950: "#020617"
	},
	gray: {
		50: "#f9fafb",
		100: "#f3f4f6",
		200: "#e5e7eb",
		300: "#d1d5db",
		400: "#9ca3af",
		500: "#6b7280",
		600: "#4b5563",
		700: "#374151",
		800: "#1f2937",
		900: "#111827",
		950: "#030712"
	},
	zinc: {
		50: "#fafafa",
		100: "#f4f4f5",
		200: "#e4e4e7",
		300: "#d4d4d8",
		400: "#a1a1aa",
		500: "#71717a",
		600: "#52525b",
		700: "#3f3f46",
		800: "#27272a",
		900: "#18181b",
		950: "#09090b"
	},
	neutral: {
		50: "#fafafa",
		100: "#f5f5f5",
		200: "#e5e5e5",
		300: "#d4d4d4",
		400: "#a3a3a3",
		500: "#737373",
		600: "#525252",
		700: "#404040",
		800: "#262626",
		900: "#171717",
		950: "#0a0a0a"
	},
	stone: {
		50: "#fafaf9",
		100: "#f5f5f4",
		200: "#e7e5e4",
		300: "#d6d3d1",
		400: "#a8a29e",
		500: "#78716c",
		600: "#57534e",
		700: "#44403c",
		800: "#292524",
		900: "#1c1917",
		950: "#0c0a09"
	},
	red: {
		50: "#fef2f2",
		100: "#fee2e2",
		200: "#fecaca",
		300: "#fca5a5",
		400: "#f87171",
		500: "#ef4444",
		600: "#dc2626",
		700: "#b91c1c",
		800: "#991b1b",
		900: "#7f1d1d",
		950: "#450a0a"
	},
	orange: {
		50: "#fff7ed",
		100: "#ffedd5",
		200: "#fed7aa",
		300: "#fdba74",
		400: "#fb923c",
		500: "#f97316",
		600: "#ea580c",
		700: "#c2410c",
		800: "#9a3412",
		900: "#7c2d12",
		950: "#431407"
	},
	amber: {
		50: "#fffbeb",
		100: "#fef3c7",
		200: "#fde68a",
		300: "#fcd34d",
		400: "#fbbf24",
		500: "#f59e0b",
		600: "#d97706",
		700: "#b45309",
		800: "#92400e",
		900: "#78350f",
		950: "#451a03"
	},
	yellow: {
		50: "#fefce8",
		100: "#fef9c3",
		200: "#fef08a",
		300: "#fde047",
		400: "#facc15",
		500: "#eab308",
		600: "#ca8a04",
		700: "#a16207",
		800: "#854d0e",
		900: "#713f12",
		950: "#422006"
	},
	lime: {
		50: "#f7fee7",
		100: "#ecfccb",
		200: "#d9f99d",
		300: "#bef264",
		400: "#a3e635",
		500: "#84cc16",
		600: "#65a30d",
		700: "#4d7c0f",
		800: "#3f6212",
		900: "#365314",
		950: "#1a2e05"
	},
	green: {
		50: "#f0fdf4",
		100: "#dcfce7",
		200: "#bbf7d0",
		300: "#86efac",
		400: "#4ade80",
		500: "#22c55e",
		600: "#16a34a",
		700: "#15803d",
		800: "#166534",
		900: "#14532d",
		950: "#052e16"
	},
	emerald: {
		50: "#ecfdf5",
		100: "#d1fae5",
		200: "#a7f3d0",
		300: "#6ee7b7",
		400: "#34d399",
		500: "#10b981",
		600: "#059669",
		700: "#047857",
		800: "#065f46",
		900: "#064e3b",
		950: "#022c22"
	},
	teal: {
		50: "#f0fdfa",
		100: "#ccfbf1",
		200: "#99f6e4",
		300: "#5eead4",
		400: "#2dd4bf",
		500: "#14b8a6",
		600: "#0d9488",
		700: "#0f766e",
		800: "#115e59",
		900: "#134e4a",
		950: "#042f2e"
	},
	cyan: {
		50: "#ecfeff",
		100: "#cffafe",
		200: "#a5f3fc",
		300: "#67e8f9",
		400: "#22d3ee",
		500: "#06b6d4",
		600: "#0891b2",
		700: "#0e7490",
		800: "#155e75",
		900: "#164e63",
		950: "#083344"
	},
	sky: {
		50: "#f0f9ff",
		100: "#e0f2fe",
		200: "#bae6fd",
		300: "#7dd3fc",
		400: "#38bdf8",
		500: "#0ea5e9",
		600: "#0284c7",
		700: "#0369a1",
		800: "#075985",
		900: "#0c4a6e",
		950: "#082f49"
	},
	blue: {
		50: "#eff6ff",
		100: "#dbeafe",
		200: "#bfdbfe",
		300: "#93c5fd",
		400: "#60a5fa",
		500: "#3b82f6",
		600: "#2563eb",
		700: "#1d4ed8",
		800: "#1e40af",
		900: "#1e3a8a",
		950: "#172554"
	},
	indigo: {
		50: "#eef2ff",
		100: "#e0e7ff",
		200: "#c7d2fe",
		300: "#a5b4fc",
		400: "#818cf8",
		500: "#6366f1",
		600: "#4f46e5",
		700: "#4338ca",
		800: "#3730a3",
		900: "#312e81",
		950: "#1e1b4b"
	},
	violet: {
		50: "#f5f3ff",
		100: "#ede9fe",
		200: "#ddd6fe",
		300: "#c4b5fd",
		400: "#a78bfa",
		500: "#8b5cf6",
		600: "#7c3aed",
		700: "#6d28d9",
		800: "#5b21b6",
		900: "#4c1d95",
		950: "#2e1065"
	},
	purple: {
		50: "#faf5ff",
		100: "#f3e8ff",
		200: "#e9d5ff",
		300: "#d8b4fe",
		400: "#c084fc",
		500: "#a855f7",
		600: "#9333ea",
		700: "#7e22ce",
		800: "#6b21a8",
		900: "#581c87",
		950: "#3b0764"
	},
	fuchsia: {
		50: "#fdf4ff",
		100: "#fae8ff",
		200: "#f5d0fe",
		300: "#f0abfc",
		400: "#e879f9",
		500: "#d946ef",
		600: "#c026d3",
		700: "#a21caf",
		800: "#86198f",
		900: "#701a75",
		950: "#4a044e"
	},
	pink: {
		50: "#fdf2f8",
		100: "#fce7f3",
		200: "#fbcfe8",
		300: "#f9a8d4",
		400: "#f472b6",
		500: "#ec4899",
		600: "#db2777",
		700: "#be185d",
		800: "#9d174d",
		900: "#831843",
		950: "#500724"
	},
	rose: {
		50: "#fff1f2",
		100: "#ffe4e6",
		200: "#fecdd3",
		300: "#fda4af",
		400: "#fb7185",
		500: "#f43f5e",
		600: "#e11d48",
		700: "#be123c",
		800: "#9f1239",
		900: "#881337",
		950: "#4c0519"
	}
};
q.reduce((e, { color: t, primary: n, secondary: r }) => ({
	...e,
	[t]: {
		primary: J[t][n],
		secondary: J[t][r]
	}
}), {});
//#endregion
//#region frontend/node_modules/svelte/src/store/index-client.js
function Y(e) {
	let t, n = S((n) => {
		let r = !1, i = e.subscribe((e) => {
			t = e, r && n();
		});
		return r = !0, i;
	});
	function r() {
		return c() ? (n(), t) : w(e);
	}
	return "set" in e ? {
		get current() {
			return r();
		},
		set current(t) {
			e.set(t);
		}
	} : { get current() {
		return r();
	} };
}
var le = [
	"label",
	"info",
	"placeholder",
	"description",
	"title",
	"value"
], ue = /* @__PURE__ */ "elem_id.elem_classes.visible.interactive.server_fns.server.id.target.theme_mode.version.root.autoscroll.max_file_size.formatter.client.load_component.scale.min_width.theme.padding.loading_status.label.show_label.validation_error.show_progress.api_prefix.container.attached_events.register_component.unregister_component.dispatcher".split(".");
function de(e) {
	return typeof e == "string" && e.includes("__i18n__");
}
var fe = class {
	load_component;
	#e = l(x({}));
	get shared() {
		return h(this.#e);
	}
	set shared(e) {
		z(this.#e, e, !0);
	}
	#t = l(x({}));
	get props() {
		return h(this.#t);
	}
	set props(e) {
		z(this.#t, e, !0);
	}
	#n = l((e) => e);
	get i18n() {
		return h(this.#n);
	}
	set i18n(e) {
		z(this.#n, e, !0);
	}
	i18n_store;
	_i18n_from_store;
	translatable_props = {};
	dispatcher;
	last_update = null;
	shared_props = ue;
	mounted = !1;
	old_value;
	register_component;
	unregister_component;
	set_data_callback;
	get_data_callback;
	registered_id = null;
	last_shared_props;
	last_props;
	constructor(e, t) {
		for (let t in e.shared_props) this.shared[t] = e.shared_props[t];
		for (let t in e.props) t !== "i18n_store" && (this.props[t] = e.props[t]);
		if (t) for (let e in t) this.props[e] === void 0 && (this.props[e] = t[e]);
		this.i18n = this.props.i18n ?? ((e) => e), this.i18n_store = e.props.i18n_store, this._i18n_from_store = this.i18n_store ? Y(this.i18n_store) : void 0;
		for (let t of le) this.shared[t] = this._translate_and_store("shared", t, e.shared_props[t]), this.props[t] = this._translate_and_store("props", t, e.props[t]);
		this.load_component = this.shared.load_component, this.register_component = this.shared.register_component || (() => {}), this.unregister_component = this.shared.unregister_component || (() => {}), this.dispatcher = this.shared.dispatcher || (() => {}), this.set_data_callback = this.set_data.bind(this), this.get_data_callback = this.get_data.bind(this), this.register_component(this.shared.id, this.set_data_callback, this.get_data_callback), this.registered_id = this.shared.id, this.last_shared_props = e.shared_props, this.last_props = e.props, n(() => {
			let t = e.shared_props.id;
			if (this.last_shared_props !== e.shared_props) {
				for (let t in e.shared_props) {
					let n = e.shared_props[t];
					n !== void 0 && (this._is_i18n_managed(`shared.${t}`, n) || (this.shared[t] = n));
				}
				this.last_shared_props = e.shared_props;
			}
			if (this.last_props !== e.props) {
				for (let t in e.props) {
					if (t === "i18n_store") continue;
					let n = e.props[t];
					n !== void 0 && (this._is_i18n_managed(`props.${t}`, n) || (this.props[t] = n));
				}
				this.last_props = e.props;
			}
			this.registered_id !== null && this.registered_id !== t && this.unregister_component(this.registered_id, this.set_data_callback), this.register_component(t, this.set_data_callback, this.get_data_callback), this.registered_id = t, a(() => {
				this.shared.id = t;
			});
		}), n(() => () => {
			this.registered_id !== null && this.unregister_component(this.registered_id, this.set_data_callback);
		}), n(() => {
			if (this.i18n_store) return this.i18n_store.subscribe(() => {
				for (let [e, t] of Object.entries(this.translatable_props)) {
					let [n, r] = e.split("."), i = this.i18n(t);
					n === "shared" ? this.shared[r] = i : this.props[r] = i;
				}
			});
		});
	}
	_is_i18n_managed(e, t) {
		let n = this.translatable_props[e];
		return n ? t === n || (delete this.translatable_props[e], !1) : !1;
	}
	_translate_and_store(e, t, n) {
		if (typeof n != "string") return n;
		let r = this.i18n(n);
		return r !== n && (this.translatable_props[`${e}.${t}`] = n), r;
	}
	live_i18n = (e) => (this._i18n_from_store?.current, this.i18n(e));
	dispatch(e, t) {
		this.dispatcher(this.shared.id, e, t);
	}
	async get_data() {
		return O(this.props);
	}
	update(e) {
		this.set_data(e);
	}
	set_data(e) {
		for (let t in e) {
			let n = e[t], r = de(n) ? this._translate_and_store(this.shared_props.includes(t) ? "shared" : "props", t, n) : n;
			if (this.shared_props.includes(t)) {
				let e = t;
				this.shared[e] = r;
				continue;
			}
			this.props[t] = r;
		}
	}
	watch_for_change() {
		n(() => {
			this.mounted ||= (this.old_value = this.props.value, !0), this.old_value != this.props.value && (this.old_value = this.props.value, this.dispatch("change"));
		});
	}
};
//#endregion
//#region frontend/node_modules/svelte/src/internal/flags/legacy.js
U();
//#endregion
//#region frontend/node_modules/@gradio/atoms/dist/src/Block.svelte
var pe = P("<svg class=\"resize-handle svelte-1stq1b1\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 10 10\"><line x1=\"1\" y1=\"9\" x2=\"9\" y2=\"1\" stroke=\"gray\" stroke-width=\"0.5\" class=\"svelte-1stq1b1\"></line><line x1=\"5\" y1=\"9\" x2=\"9\" y2=\"5\" stroke=\"gray\" stroke-width=\"0.5\" class=\"svelte-1stq1b1\"></line></svg>"), me = m("<!> <!>", 1), he = m("<div class=\"placeholder svelte-1stq1b1\"></div>");
function ge(t, n) {
	e(n, !1);
	let c = I(n, "height", 8, void 0), l = I(n, "min_height", 8, void 0), m = I(n, "max_height", 8, void 0), b = I(n, "width", 8, void 0), x = I(n, "elem_id", 8, ""), S = I(n, "elem_classes", 24, () => []), C = I(n, "variant", 8, "solid"), w = I(n, "border_mode", 8, "base"), D = I(n, "padding", 8, !0), ee = I(n, "type", 8, "normal"), O = I(n, "test_id", 8, void 0), k = I(n, "explicit_call", 8, !1), A = I(n, "container", 8, !0), M = I(n, "visible", 8, !0), N = I(n, "allow_overflow", 8, !0), P = I(n, "overflow_behavior", 8, "auto"), F = I(n, "scale", 8, null), L = I(n, "min_width", 8, 0), ie = I(n, "flex", 12, !1), R = I(n, "resizable", 8, !1), ae = I(n, "rtl", 8, !1), B = I(n, "fullscreen", 12, !1), V = I(n, "label", 8, void 0), H = o(B()), U = o(), W = ee() === "fieldset" ? "fieldset" : "div", G = o(0), ce = o(0), q = o(null), J = null, Y = null;
	function le(e) {
		B() && e.key === "Escape" && B(!1);
	}
	function ue() {
		let e = h(U).getRootNode();
		return h(U).closest(".gradio-container") ?? (e instanceof ShadowRoot ? e : document.body);
	}
	function de(e) {
		let t = document.createElement("div");
		t.style.cssText = "position: fixed; top: 0; left: 0; width: 100%; height: 100%; visibility: hidden; pointer-events: none;", e.appendChild(t);
		let n = t.getBoundingClientRect();
		return t.remove(), n;
	}
	function fe(e) {
		let t = h(U).parentNode;
		if (!t || t === e) return !1;
		let n = de(t), r = de(e);
		return Math.abs(n.top - r.top) > 1 || Math.abs(n.left - r.left) > 1 || Math.abs(n.width - r.width) > 1 || Math.abs(n.height - r.height) > 1;
	}
	function ge(e) {
		!h(U).parentNode || h(U).parentNode === e || (J = h(U).parentNode, Y = document.createComment("fullscreen block"), J.insertBefore(Y, h(U)), e.appendChild(h(U)));
	}
	function X() {
		if (!J) return;
		let e = Y && Y.parentNode === J ? Y : null;
		J.insertBefore(h(U), e), e?.remove(), J = null, Y = null;
	}
	let Z = (e) => {
		if (e !== void 0) {
			if (typeof e == "number") return e + "px";
			if (typeof e == "string") return e;
		}
	}, _e = (e) => {
		let t = e.clientY, n = (e) => {
			let n = e.clientY - t;
			t = e.clientY, u(U, h(U).style.height = `${h(U).offsetHeight + n}px`);
		}, r = () => {
			window.removeEventListener("mousemove", n), window.removeEventListener("mouseup", r);
		};
		window.addEventListener("mousemove", n), window.addEventListener("mouseup", r);
	};
	d(() => (p(B()), h(H), h(U)), () => {
		if (B() !== h(H)) {
			if (z(H, B()), B()) {
				z(q, h(U).getBoundingClientRect()), z(G, h(U).offsetHeight), z(ce, h(U).offsetWidth);
				let e = ue();
				fe(e) && ge(e), window.addEventListener("keydown", le);
			} else X(), z(q, null), window.removeEventListener("keydown", le);
		}
	}), d(() => p(M()), () => {
		M() || ie(!1);
	}), _(), ne();
	var Q = r(), ve = s(Q), ye = (e) => {
		var t = me(), r = s(t);
		T(r, () => W, !1, (e, t) => {
			E(e, (e) => z(U, e), () => h(U)), te(e, (e, t) => ({
				"data-testid": O(),
				id: x(),
				class: `block ${e ?? ""}`,
				dir: ae() ? "rtl" : "ltr",
				"aria-label": V(),
				style: "",
				[re]: {
					hidden: M() === "hidden",
					padded: D(),
					flex: ie(),
					border_focus: w() === "focus",
					border_contrast: w() === "contrast",
					"hide-container": !k() && !A(),
					fullscreen: B(),
					animating: B() && h(q) !== null,
					"auto-margin": F() === null
				},
				[oe]: t
			}), [() => (p(S()), a(() => S()?.join(" ") || "")), () => ({
				height: (p(B()), p(c()), a(() => B() ? void 0 : Z(c()))),
				"min-height": (p(B()), p(l()), a(() => B() ? void 0 : Z(l()))),
				"max-height": (p(B()), p(m()), a(() => B() ? void 0 : Z(m()))),
				"--start-top": (h(q), a(() => h(q) ? `${h(q).top}px` : "0px")),
				"--start-left": (h(q), a(() => h(q) ? `${h(q).left}px` : "0px")),
				"--start-width": (h(q), a(() => h(q) ? `${h(q).width}px` : "0px")),
				"--start-height": (h(q), a(() => h(q) ? `${h(q).height}px` : "0px")),
				width: (p(B()), p(b()), a(() => B() ? void 0 : typeof b() == "number" ? `calc(min(${b()}px, 100%))` : Z(b()))),
				"border-style": C(),
				overflow: N() ? P() : "hidden",
				"flex-grow": F(),
				"min-width": `calc(min(${L()}px, 100%))`
			})], void 0, void 0, "svelte-1stq1b1");
			var r = me(), o = s(r);
			se(o, n, "default", {}, null);
			var u = y(o, 2), d = (e) => {
				var t = pe();
				f("mousedown", t, _e), i(e, t);
			};
			v(u, (e) => {
				R() && e(d);
			}), i(t, r);
		});
		var o = y(r, 2), u = (e) => {
			var t = he();
			let n;
			K(() => n = j(t, "", n, {
				height: h(G) + "px",
				width: h(ce) + "px"
			})), i(e, t);
		};
		v(o, (e) => {
			B() && e(u);
		}), i(e, t);
	};
	v(ve, (e) => {
		(M() === !0 || M() === "hidden") && e(ye);
	}), i(t, Q), g();
}
//#endregion
//#region frontend/node_modules/@gradio/atoms/dist/src/SelectSource.svelte
t(["click"]), t(["click"]);
var X = new class {
	#e;
	get playing() {
		return h(this.#e);
	}
	set playing(e) {
		z(this.#e, e, !0);
	}
	#t;
	get offset() {
		return h(this.#t);
	}
	set offset(e) {
		z(this.#t, e, !0);
	}
	#n;
	get loopFrom() {
		return h(this.#n);
	}
	set loopFrom(e) {
		z(this.#n, e, !0);
	}
	#r;
	get loopTo() {
		return h(this.#r);
	}
	set loopTo(e) {
		z(this.#r, e, !0);
	}
	#i;
	get levels() {
		return h(this.#i);
	}
	set levels(e) {
		z(this.#i, e, !0);
	}
	#a;
	get repeat() {
		return h(this.#a);
	}
	set repeat(e) {
		z(this.#a, e, !0);
	}
	constructor() {
		this.context = null, this.master = null, this.buffers = {}, this.gains = {}, this.sources = [], this.startedAt = 0, this.fingerprint = "", this.selectionFingerprint = "", this.#e = l(!1), this.#t = l(0), this.#n = l(null), this.#r = l(null), this.#i = l(x({})), this.anchor = null, this.#a = l(!0);
	}
	position() {
		if (!this.context || !this.playing) return this.offset;
		let e = this.offset + (this.context.currentTime - this.startedAt);
		if (this.loopFrom !== null && this.loopTo !== null && e > this.loopTo) {
			let t = this.loopTo - this.loopFrom;
			e = this.loopFrom + (e - this.loopFrom) % t;
		}
		return e;
	}
	bytesFrom(e) {
		let t = atob(e), n = new Uint8Array(t.length);
		for (let e = 0; e < t.length; e++) n[e] = t.charCodeAt(e);
		return n.buffer;
	}
	computeFingerprint(e) {
		return e.map((e) => {
			let t = e.wav;
			return e.name + ":" + t.length + ":" + t.slice(0, 24) + ":" + t.slice(-24);
		}).join("|");
	}
	noteLayers(e) {
		let t = this.computeFingerprint(e);
		t !== this.selectionFingerprint && (this.clearLoop(), this.selectionFingerprint = t);
	}
	async ensureAudio(e) {
		if (!this.context) {
			this.context = new (window.AudioContext || window.webkitAudioContext)();
			let e = this.context.createGain();
			e.gain.value = .7;
			let t = this.context.createDynamicsCompressor();
			t.threshold.value = -6, t.knee.value = 0, t.ratio.value = 20, t.attack.value = .003, t.release.value = .15, e.connect(t), t.connect(this.context.destination), this.master = e;
		}
		let t = this.computeFingerprint(e);
		if (this.fingerprint !== t) {
			for (let e of Object.keys(this.gains)) this.gains[e].disconnect();
			this.buffers = {}, this.gains = {};
			for (let t of e) {
				let e = this.context.createGain();
				e.gain.value = this.levels[t.name] ?? t.level, e.connect(this.master), this.gains[t.name] = e, this.buffers[t.name] = await this.context.decodeAudioData(this.bytesFrom(t.wav));
			}
			this.fingerprint = t;
		}
	}
	stopSources() {
		for (let e of this.sources) {
			e.onended = null;
			try {
				e.stop();
			} catch {}
			e.disconnect();
		}
		this.sources = [];
	}
	async play(e, t) {
		let n = t ?? this.offset;
		if (this.stopSources(), this.playing = !1, await this.ensureAudio(e), this.context) {
			this.context.state === "suspended" && await this.context.resume(), this.offset = n, this.startedAt = this.context.currentTime, this.playing = !0;
			for (let t of e) {
				let e = this.context.createBufferSource();
				e.buffer = this.buffers[t.name], this.loopFrom !== null && this.loopTo !== null && this.repeat && (e.loop = !0, e.loopStart = this.loopFrom, e.loopEnd = this.loopTo), e.connect(this.gains[t.name]), e.start(this.startedAt, this.offset), this.loopFrom !== null && this.loopTo !== null && !this.repeat && e.stop(this.startedAt + (this.loopTo - this.offset)), this.sources.push(e);
			}
			this.sources.length && (this.sources[0].onended = () => {
				this.playing = !1;
			});
		}
	}
	stop() {
		this.offset = this.position(), this.stopSources(), this.playing = !1;
	}
	select(e, t) {
		let n = this.loopFrom !== null && this.loopTo !== null, r = this.loopFrom, i = this.loopTo, a = n && e.start >= this.loopFrom - .001 && e.end <= this.loopTo + .001;
		if (t && this.anchor !== null && !n) {
			let t = Math.min(this.anchor.start, e.start), n = Math.max(this.anchor.end, e.end);
			this.loopFrom = t, this.loopTo = Math.max(n, t + .05), this.offset = this.loopFrom;
		} else !t && a ? this.offset = e.start : (this.anchor = e, this.loopFrom = e.start, this.loopTo = null, this.offset = e.start);
		return this.stopSources(), this.playing = !1, this.loopFrom !== r || this.loopTo !== i;
	}
	selectRange(e, t) {
		let n = this.loopFrom, r = this.loopTo;
		return this.anchor = null, this.loopFrom = e, this.loopTo = Math.max(t, e + .05), this.offset = e, this.stopSources(), this.playing = !1, this.loopFrom !== n || this.loopTo !== r;
	}
	clearLoop() {
		this.anchor = null, this.loopFrom = null, this.loopTo = null, this.offset = 0, this.stopSources(), this.playing = !1;
	}
	setLevel(e, t) {
		this.levels[e] = t, this.gains[e] && this.context && this.gains[e].gain.setTargetAtTime(t, this.context.currentTime, .01);
	}
}(), Z = x({
	strip: !0,
	faders: !0,
	phrases: !0,
	notes: !1,
	lyrics: !0,
	instruments: !0
}), _e = x({
	Melody: !0,
	"Harmony above": !1,
	"Harmony below": !1,
	Bass: !1
}), Q = x({ value: !1 }), ve = x({ value: !1 }), ye = x({ value: !0 }), be = x({
	Piano: !0,
	Guitar: !0,
	"Violin, first position": !1,
	"Violin, third position": !1
}), $ = x({
	scale: !1,
	chordMode: "notes"
}), xe = x({ value: !1 }), Se = x({ value: "wrap" }), Ce = m("<label class=\"repeat svelte-d89286\"><input type=\"checkbox\" class=\"svelte-d89286\"/> Repeat</label>"), we = m("<label class=\"repeat svelte-d89286\"><input type=\"checkbox\" class=\"svelte-d89286\"/> Follow</label>"), Te = m("<div class=\"transport svelte-d89286\"><button class=\"svelte-d89286\">Play</button> <button class=\"svelte-d89286\">Stop</button> <button class=\"svelte-d89286\">Clear selection</button> <!> <span class=\"time svelte-d89286\"> </span> <!></div>");
function Ee(t, n) {
	e(n, !0);
	let r = I(n, "follow", 15);
	var a = Te(), o = b(a), s = y(o, 2), c = y(s, 2), l = y(c, 2), u = (e) => {
		var t = Ce(), r = b(t);
		k(r), L(), B(t), N("change", r, function(...e) {
			n.onToggleRepeat?.apply(this, e);
		}), V(r, () => X.repeat, (e) => X.repeat = e), i(e, t);
	};
	v(l, (e) => {
		X.loopFrom !== null && X.loopTo !== null && e(u);
	});
	var d = y(l, 2), f = b(d);
	B(d);
	var p = y(d, 2), m = (e) => {
		var t = we(), n = b(t);
		k(n), L(), B(t), V(n, r), i(e, t);
	};
	v(p, (e) => {
		n.hasTimeline && e(m);
	}), B(a), K((e) => W(f, `${e ?? ""}s`), [() => n.playhead.toFixed(1)]), N("click", o, () => X.play(n.layers)), N("click", s, () => X.stop()), N("click", c, function(...e) {
		n.onClearSelection?.apply(this, e);
	}), i(t, a), g();
}
t(["click", "change"]);
//#endregion
//#region frontend/PanelToggles.svelte
var De = m("<label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Chart</label>"), Oe = m("<label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Phrases</label> <label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Visual notes</label> <label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Lyrics</label>", 1), ke = m("<label><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Shrink to fit</label>"), Ae = m("<label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Instruments</label> <label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Beside mixer</label> <!>", 1), je = m("<div class=\"panel-toggles svelte-1mngm7u\"><!> <!> <label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Mixer</label> <!></div>");
function Me(t, n) {
	e(n, !0);
	let r = I(n, "narrow", 3, !1);
	var a = je(), o = b(a), c = (e) => {
		var t = De(), n = b(t);
		k(n), L(), B(t), V(n, () => Z.strip, (e) => Z.strip = e), i(e, t);
	};
	v(o, (e) => {
		n.hasTimeline && e(c);
	});
	var l = y(o, 2), u = (e) => {
		var t = Oe(), n = s(t), r = b(n);
		k(r), L(), B(n);
		var a = y(n, 2), o = b(a);
		k(o), L(), B(a);
		var c = y(a, 2), l = b(c);
		k(l), L(), B(c), V(r, () => Z.phrases, (e) => Z.phrases = e), V(o, () => Z.notes, (e) => Z.notes = e), V(l, () => Z.lyrics, (e) => Z.lyrics = e), i(e, t);
	};
	v(l, (e) => {
		n.hasNotes && e(u);
	});
	var d = y(l, 2), f = b(d);
	k(f), L(), B(d);
	var p = y(d, 2), m = (e) => {
		var t = Ae(), n = s(t), a = b(n);
		k(a), L(), B(n);
		var o = y(n, 2), c = b(o);
		k(c), L(), B(o);
		var l = y(o, 2), u = (e) => {
			var t = ke();
			let n;
			var a = b(t);
			k(a), L(), B(t), K(() => {
				n = A(t, 1, "panel-toggle svelte-1mngm7u", null, n, { disabled: r() }), F(a, Se.value === "shrink"), a.disabled = r();
			}), N("change", a, (e) => Se.value = e.currentTarget.checked ? "shrink" : "wrap"), i(e, t);
		};
		v(l, (e) => {
			xe.value && e(u);
		}), V(a, () => Z.instruments, (e) => Z.instruments = e), V(c, () => xe.value, (e) => xe.value = e), i(e, t);
	};
	v(p, (e) => {
		n.hasDiagrams && e(m);
	}), B(a), V(f, () => Z.faders, (e) => Z.faders = e), i(t, a), g();
}
t(["change"]);
//#endregion
//#region frontend/ChordStrip.svelte
var Ne = m("<button type=\"button\"><div class=\"number svelte-65z4tz\"> </div> <div class=\"chord svelte-65z4tz\"> </div> <div class=\"words svelte-65z4tz\"> </div></button>"), Pe = m("<div class=\"strip svelte-65z4tz\"></div> <p class=\"note svelte-65z4tz\"> </p>", 1);
function Fe(t, a) {
	e(a, !0);
	let o = C(() => a.timeline.find((e) => a.playhead >= e.start && a.playhead < e.end)), c = C(() => X.loopFrom === null ? a.timeline.length ? "Click a bar to select where Play starts. Shift-click a later bar to loop a stretch." : "" : X.loopTo === null ? `Play starts at ${X.loopFrom.toFixed(1)}s. Shift-click a later bar to select a stretch, or press Play.` : X.repeat ? `Repeating ${X.loopFrom.toFixed(1)}s to ${X.loopTo.toFixed(1)}s. Untick Repeat to play it once, or Clear selection to release it.` : `Selected ${X.loopFrom.toFixed(1)}s to ${X.loopTo.toFixed(1)}s, playing once. Tick Repeat to loop it.`), l = {};
	n(() => {
		a.follow && h(o) && l[h(o).bar] && l[h(o).bar].scrollIntoView({
			behavior: "smooth",
			inline: "center",
			block: "nearest"
		});
	});
	var u = r(), d = s(u), f = (e) => {
		var t = Pe(), n = s(t);
		D(n, 21, () => a.timeline, (e) => e.bar, (e, t) => {
			var n = Ne();
			let r;
			var s = b(n), c = b(s, !0);
			B(s);
			var u = y(s, 2), d = b(u, !0);
			B(u);
			var f = y(u, 2), p = b(f, !0);
			B(f), B(n), E(n, (e, t) => l[t.bar] = e, (e) => l?.[e.bar], () => [h(t)]), K(() => {
				r = A(n, 1, "bar svelte-65z4tz", null, r, {
					playing: h(o) === h(t),
					looped: X.loopFrom !== null && X.loopTo !== null && h(t).start >= X.loopFrom - .001 && h(t).end <= X.loopTo + .001
				}), R(n, "data-bar", h(t).bar), W(c, h(t).bar), W(d, h(t).name), W(p, h(t).words);
			}), N("click", n, (e) => a.onSelectBar(h(t), e)), N("keydown", n, (e) => {
				(e.key === "Enter" || e.key === " ") && (e.preventDefault(), a.onSelectBar(h(t), e));
			}), i(e, n);
		}), B(n);
		var r = y(n, 2), u = b(r, !0);
		B(r), K(() => W(u, h(c))), i(e, t);
	};
	v(d, (e) => {
		a.timeline.length && e(f);
	}), i(t, u), g();
}
t(["click", "keydown"]);
//#endregion
//#region frontend/FaderPanel.svelte
var Ie = m("<div class=\"fader-row svelte-ma6git\"><span class=\"name svelte-ma6git\"> </span> <button class=\"mute svelte-ma6git\">M</button> <input type=\"range\" min=\"0\" max=\"1\" step=\"0.05\" class=\"svelte-ma6git\"/> <span class=\"value svelte-ma6git\"> </span></div>"), Le = m("<div class=\"faders\"></div>");
function Re(t, n) {
	e(n, !0);
	function r(e, t) {
		X.levels[e] = X.levels[e] > 0 ? 0 : t, n.onLevelChanged(e);
	}
	var a = Le();
	D(a, 21, () => n.layers, (e) => e.name, (e, t) => {
		var a = Ie(), o = b(a), s = b(o, !0);
		B(o);
		var c = y(o, 2), l = y(c, 2);
		k(l);
		var u = y(l, 2), d = b(u);
		B(u), B(a), K((e) => {
			j(o, `color:${h(t).colour ?? ""}`), W(s, h(t).name), W(d, `${e ?? ""}%`);
		}, [() => Math.round((X.levels[h(t).name] ?? 0) * 100)]), N("click", c, () => r(h(t).name, h(t).level)), N("input", l, () => n.onLevelChanged(h(t).name)), ee(l, () => X.levels[h(t).name], (e) => X.levels[h(t).name] = e), i(e, a);
	}), B(a), i(t, a), g();
}
t(["click", "input"]);
//#endregion
//#region frontend/NotesPanel.svelte
var ze = P("<rect class=\"loop-region svelte-1nlxyec\" y=\"0\"></rect>"), Be = P("<line class=\"bar-line svelte-1nlxyec\" y1=\"0\"></line>"), Ve = P("<text class=\"note-label svelte-1nlxyec\"> </text>"), He = P("<text class=\"note-word svelte-1nlxyec\"> </text>"), Ue = P("<g><rect class=\"note-box svelte-1nlxyec\"></rect><!><!></g>"), We = P("<line class=\"playhead svelte-1nlxyec\" y1=\"0\"></line>"), Ge = P("<svg><!><!><!><!></svg>"), Ke = m("<label class=\"layer-toggle svelte-1nlxyec\"><input type=\"checkbox\" class=\"svelte-1nlxyec\"/> </label>"), qe = m("<label><input type=\"checkbox\" class=\"svelte-1nlxyec\"/> Side by side</label>"), Je = m("<div class=\"notes-container next-page svelte-1nlxyec\"><!></div>"), Ye = m("<div><div class=\"notes-container svelte-1nlxyec\"><!></div> <!></div>"), Xe = m("<p class=\"note-empty svelte-1nlxyec\">No layers selected to show.</p>"), Ze = m("<div class=\"notes-toggles svelte-1nlxyec\"><!> <label class=\"layer-toggle preview-toggle svelte-1nlxyec\"><input type=\"checkbox\" class=\"svelte-1nlxyec\"/> Preview next phrase</label> <!> <label class=\"layer-toggle svelte-1nlxyec\"><input type=\"checkbox\" class=\"svelte-1nlxyec\"/> Word labels</label></div> <!>", 1);
function Qe(t, r) {
	e(r, !0);
	let a = (e, t = M, n = M, a = M) => {
		var o = Ge();
		let s;
		var l = b(o), u = (e) => {
			var n = ze();
			K((e, r) => {
				R(n, "x", e), R(n, "width", r), R(n, "height", t().height);
			}, [() => O(t(), Math.max(X.loopFrom, t().phrase.start)), () => Math.max(0, O(t(), Math.min(X.loopTo, t().phrase.end)) - O(t(), Math.max(X.loopFrom, t().phrase.start)))]), i(e, n);
		};
		v(l, (e) => {
			n() && X.loopFrom !== null && X.loopTo !== null && e(u);
		});
		var d = y(l);
		D(d, 17, () => t().bars, G, (e, n) => {
			var r = Be();
			K((e, n) => {
				R(r, "x1", e), R(r, "x2", n), R(r, "y2", t().height);
			}, [() => O(t(), h(n).start), () => O(t(), h(n).start)]), i(e, r);
		});
		var f = y(d);
		D(f, 17, () => t().notes, G, (e, n) => {
			var r = Ue(), a = b(r);
			R(a, "height", c - 2);
			var o = y(a), s = (e) => {
				var r = Ve(), a = b(r, !0);
				B(r), K((e, t, i) => {
					R(r, "x", e), R(r, "y", t), R(r, "fill", h(n).colour), W(a, i);
				}, [
					() => O(t(), h(n).start) + h(n).length * t().pxPerSecond / 2,
					() => te(t(), h(n).midi) + c / 2,
					() => m(h(n).midi)
				]), i(e, r);
			};
			v(o, (e) => {
				h(n).length * t().pxPerSecond > 20 && e(s);
			});
			var l = y(o), u = (e) => {
				var r = He(), a = b(r, !0);
				B(r), K((e, t) => {
					R(r, "x", e), R(r, "y", t), W(a, h(n).word);
				}, [() => O(t(), h(n).start) + h(n).length * t().pxPerSecond / 2, () => te(t(), h(n).midi) + c + 10]), i(e, r);
			};
			v(l, (e) => {
				h(n).word && ye.value && e(u);
			}), B(r), K((e, t, r) => {
				R(a, "x", e), R(a, "y", t), R(a, "width", r), R(a, "fill", h(n).colour), R(a, "fill-opacity", h(n).layer === "Melody" ? .22 : .14), R(a, "stroke", h(n).colour);
			}, [
				() => O(t(), h(n).start),
				() => te(t(), h(n).midi) + 1,
				() => Math.max(h(n).length * t().pxPerSecond - 1, 2)
			]), i(e, r);
		});
		var p = y(f), g = (e) => {
			var n = We();
			K((e, r) => {
				R(n, "x1", e), R(n, "x2", r), R(n, "y2", t().height);
			}, [() => O(t(), r.playhead), () => O(t(), r.playhead)]), i(e, n);
		};
		v(p, (e) => {
			n() && e(g);
		}), B(o), K(() => {
			R(o, "width", t().width), R(o, "height", t().height), R(o, "viewBox", `0 0 ${t().width ?? ""} ${t().height ?? ""}`), s = A(o, 0, "svelte-1nlxyec", null, s, { dimmed: a() });
		}), i(e, o);
	}, o = I(r, "narrow", 3, !1), c = 14, u = C(() => r.phrases.length ? r.phrases : r.notes.length ? [{
		start: 0,
		end: r.notes.reduce((e, t) => Math.max(e, t.start + t.length), 0),
		label: "1. Whole part"
	}] : []), d = C(() => {
		if (!h(u).length) return -1;
		let e = h(u).findIndex((e) => r.playhead < e.end);
		return e === -1 ? h(u).length - 1 : e;
	}), f = C(() => h(d) >= 0 ? h(u)[h(d)] : null), p = C(() => h(d) >= 0 && h(d) + 1 < h(u).length ? h(u)[h(d) + 1] : null);
	function m(e) {
		return [
			"C",
			"C#",
			"D",
			"D#",
			"E",
			"F",
			"F#",
			"G",
			"G#",
			"A",
			"A#",
			"B"
		][e % 12] + Math.floor(e / 12 - 1);
	}
	let _ = l(null), x = l(600);
	n(() => {
		h(_) && z(x, h(_).clientWidth || h(x), !0);
	});
	function S(e, t) {
		if (!e) return null;
		let n = r.timeline.filter((t) => t.start < e.end && t.end > e.start), i = r.notes.filter((t) => _e[t.layer] && t.start >= e.start && t.start < e.end), a = 60, o = 72;
		if (i.length) {
			a = i[0].midi, o = i[0].midi;
			for (let e of i) e.midi < a && (a = e.midi), e.midi > o && (o = e.midi);
			--a, o += 1;
		}
		let s = (o - a + 1) * 14, c = e.end - e.start, l = c > 0 ? t / c : 60;
		return {
			phrase: e,
			bars: n,
			notes: i,
			pitchRange: {
				lowest: a,
				highest: o
			},
			width: t,
			height: s,
			pxPerSecond: l
		};
	}
	let w = C(() => Q.value && ve.value && !o()), T = C(() => {
		let e = h(w) ? (h(x) - 8) / 2 : h(x);
		return S(h(f), e);
	}), ee = C(() => {
		if (!Q.value) return null;
		let e = h(w) ? (h(x) - 8) / 2 : h(x);
		return S(h(p), e);
	});
	function te(e, t) {
		return (e.pitchRange.highest - t) * 14;
	}
	function O(e, t) {
		return (t - e.phrase.start) * e.pxPerSecond;
	}
	var j = Ze(), ne = s(j), N = b(ne);
	D(N, 17, () => Object.keys(_e), G, (e, t) => {
		var n = Ke(), r = b(n);
		k(r);
		var a = y(r);
		B(n), K(() => W(a, ` ${h(t) ?? ""}`)), V(r, () => _e[h(t)], (e) => _e[h(t)] = e), i(e, n);
	});
	var P = y(N, 2), re = b(P);
	k(re), L(), B(P);
	var F = y(P, 2), ie = (e) => {
		var t = qe();
		let n;
		var r = b(t);
		k(r), L(), B(t), K(() => {
			n = A(t, 1, "layer-toggle svelte-1nlxyec", null, n, { disabled: o() }), r.disabled = o();
		}), V(r, () => ve.value, (e) => ve.value = e), i(e, t);
	};
	v(F, (e) => {
		Q.value && e(ie);
	});
	var ae = y(F, 2), H = b(ae);
	k(H), L(), B(ae), B(ne);
	var U = y(ne, 2), oe = (e) => {
		var t = Ye();
		let n;
		var r = b(t), o = b(r);
		a(o, () => h(T), () => !0, () => !1), B(r);
		var s = y(r, 2), c = (e) => {
			var t = Je(), n = b(t);
			a(n, () => h(ee), () => !1, () => !0), B(t), i(e, t);
		};
		v(s, (e) => {
			h(ee) && e(c);
		}), B(t), E(t, (e) => z(_, e), () => h(_)), K(() => n = A(t, 1, "pages svelte-1nlxyec", null, n, { row: h(w) })), i(e, t);
	}, se = (e) => {
		var t = Xe();
		i(e, t);
	};
	v(U, (e) => {
		h(T) ? e(oe) : e(se, -1);
	}), V(re, () => Q.value, (e) => Q.value = e), V(H, () => ye.value, (e) => ye.value = e), i(t, j), g();
}
//#endregion
//#region frontend/PhraseList.svelte
var $e = m("<option> </option>"), et = m("<select class=\"phrase-select svelte-8xxexk\"><option disabled=\"\" selected=\"\">Jump to phrase…</option><!></select>"), tt = m("<button type=\"button\" class=\"phrase svelte-8xxexk\"> </button>"), nt = m("<div class=\"phrase-list svelte-8xxexk\"></div>");
function rt(t, n) {
	e(n, !0);
	let a = I(n, "narrow", 3, !1);
	function o(e) {
		let t = Number(e.currentTarget.value);
		!Number.isNaN(t) && n.phrases[t] && n.onSelectPhrase(n.phrases[t]);
	}
	var c = r(), l = s(c), u = (e) => {
		var t = r(), c = s(t), l = (e) => {
			var t = et(), r = b(t);
			r.value = r.__value = "";
			var a = y(r);
			D(a, 17, () => n.phrases, G, (e, t, n) => {
				var r = $e(), a = b(r, !0);
				B(r), r.value = r.__value = n, K(() => W(a, h(t).label)), i(e, r);
			}), B(t), N("change", t, o), i(e, t);
		}, u = (e) => {
			var t = nt();
			D(t, 21, () => n.phrases, G, (e, t) => {
				var r = tt(), a = b(r, !0);
				B(r), K(() => W(a, h(t).label)), N("click", r, () => n.onSelectPhrase(h(t))), N("keydown", r, (e) => {
					(e.key === "Enter" || e.key === " ") && (e.preventDefault(), n.onSelectPhrase(h(t)));
				}), i(e, r);
			}), B(t), i(e, t);
		};
		v(c, (e) => {
			a() ? e(l) : e(u, -1);
		}), i(e, t);
	};
	v(l, (e) => {
		n.phrases.length && e(u);
	}), i(t, c), g();
}
t([
	"change",
	"click",
	"keydown"
]);
//#endregion
//#region frontend/LyricsPanel.svelte
var it = m("<span> </span>"), at = m("<p class=\"sentence next svelte-4o08vh\"></p>"), ot = m("<div class=\"lyrics-panel svelte-4o08vh\"><p class=\"sentence current svelte-4o08vh\"></p> <!></div>"), st = m("<p class=\"lyrics-empty svelte-4o08vh\">No lyrics to show yet.</p>");
function ct(t, n) {
	e(n, !0);
	let a = C(() => n.notes.filter((e) => e.layer === "Melody" && e.word)), o = C(() => n.phrases.length ? n.phrases : h(a).length ? [{
		start: 0,
		end: h(a).reduce((e, t) => Math.max(e, t.start + t.length), 0),
		label: "Whole part"
	}] : []), c = C(() => {
		if (!h(o).length) return -1;
		let e = h(o).findIndex((e) => n.playhead < e.end);
		return e === -1 ? h(o).length - 1 : e;
	}), l = C(() => h(c) >= 0 ? h(o)[h(c)] : null), u = C(() => h(c) >= 0 && h(c) + 1 < h(o).length ? h(o)[h(c) + 1] : null);
	function d(e) {
		return e ? h(a).filter((t) => t.start >= e.start && t.start < e.end) : [];
	}
	let f = C(() => d(h(l))), p = C(() => d(h(u)));
	function m(e) {
		return e?.endsWith("-") ? "" : " ";
	}
	var _ = r(), x = s(_), S = (e) => {
		var t = ot(), r = b(t);
		D(r, 21, () => h(f), G, (e, t) => {
			var r = it();
			let a;
			var o = b(r);
			B(r), K((e) => {
				a = A(r, 1, "sentence-word svelte-4o08vh", null, a, { sung: h(t).start <= n.playhead }), W(o, `${h(t).word ?? ""}${e ?? ""}`);
			}, [() => m(h(t).word)]), i(e, r);
		}), B(r);
		var a = y(r, 2), o = (e) => {
			var t = at();
			D(t, 21, () => h(p), G, (e, t) => {
				var n = it(), r = b(n);
				B(n), K((e) => W(r, `${h(t).word ?? ""}${e ?? ""}`), [() => m(h(t).word)]), i(e, n);
			}), B(t), i(e, t);
		};
		v(a, (e) => {
			h(p).length && e(o);
		}), B(t), i(e, t);
	}, w = (e) => {
		var t = st();
		i(e, t);
	};
	v(x, (e) => {
		h(l) ? e(S) : e(w, -1);
	}), i(t, _), g();
}
//#endregion
//#region frontend/InstrumentPanel.svelte
var lt = m("<label class=\"instrument-toggle svelte-o1xgsa\"><input type=\"checkbox\" class=\"svelte-o1xgsa\"/> </label>"), ut = m("<p class=\"instrument-empty svelte-o1xgsa\">Choose an instrument to see it.</p>"), dt = m("<div class=\"layer stacked scale-layer svelte-o1xgsa\"></div>"), ft = m("<div class=\"layer stacked chord-layer svelte-o1xgsa\"></div>"), pt = m("<p class=\"instrument-empty svelte-o1xgsa\"> </p>"), mt = m("<p class=\"instrument-note svelte-o1xgsa\"> </p>"), ht = m("<div class=\"diagram-stack svelte-o1xgsa\"><div class=\"layer structure-layer svelte-o1xgsa\"></div> <!> <!> <!></div> <!>", 1), gt = m("<p class=\"instrument-empty svelte-o1xgsa\">No picture for this instrument yet.</p>"), _t = m("<div class=\"instrument-card svelte-o1xgsa\"><h4 class=\"svelte-o1xgsa\"> </h4> <!></div>"), vt = m("<div class=\"instrument-grid svelte-o1xgsa\"></div>"), yt = m("<div class=\"instrument-toggles svelte-o1xgsa\"><!> <span class=\"layer-gap svelte-o1xgsa\"></span> <label class=\"instrument-toggle svelte-o1xgsa\"><input type=\"checkbox\" class=\"svelte-o1xgsa\"/> Scale</label> <span class=\"layer-gap svelte-o1xgsa\"></span> <label class=\"instrument-toggle svelte-o1xgsa\"><input type=\"radio\" name=\"chordMode\" class=\"svelte-o1xgsa\"/> Off</label> <label class=\"instrument-toggle svelte-o1xgsa\"><input type=\"radio\" name=\"chordMode\" class=\"svelte-o1xgsa\"/> Chord notes</label> <label class=\"instrument-toggle svelte-o1xgsa\"><input type=\"radio\" name=\"chordMode\" class=\"svelte-o1xgsa\"/> Chord shape</label></div> <!>", 1);
function bt(t, n) {
	e(n, !0);
	let r = C(() => n.timeline.find((e) => n.playhead >= e.start && n.playhead < e.end)), a = C(() => Object.keys(be).filter((e) => be[e]));
	var o = yt(), c = s(o), l = b(c);
	D(l, 17, () => Object.keys(be), G, (e, t) => {
		var n = lt(), r = b(n);
		k(r);
		var a = y(r);
		B(n), K(() => W(a, ` ${h(t) ?? ""}`)), V(r, () => be[h(t)], (e) => be[h(t)] = e), i(e, n);
	});
	var u = y(l, 4), d = b(u);
	k(d), L(), B(u);
	var f = y(u, 4), p = b(f);
	k(p), L(), B(f);
	var m = y(f, 2), _ = b(m);
	k(_), L(), B(m);
	var x = y(m, 2), S = b(x);
	k(S), L(), B(x), B(c);
	var w = y(c, 2), T = (e) => {
		var t = ut();
		i(e, t);
	}, E = (e) => {
		var t = vt();
		D(t, 21, () => h(a), G, (e, t) => {
			let a = C(() => n.diagrams.structure?.[h(t)]), o = C(() => n.diagrams.scale?.[h(t)]), c = C(() => h(r) ? n.diagrams.chords?.[h(t)]?.[h(r).name] : void 0), l = C(() => h(r) ? n.diagrams.shapes?.[h(t)]?.[h(r).name] : void 0), u = C(() => $.chordMode === "shape" && !!h(r) && !h(l) && !!h(c)), d = C(() => $.chordMode === "shape" ? h(l) ?? h(c) : h(c));
			var f = _t(), p = b(f), m = b(p, !0);
			B(p);
			var g = y(p, 2), _ = (e) => {
				var n = ht(), c = s(n), l = b(c);
				ce(l, () => h(a), !0), B(l);
				var f = y(l, 2), p = (e) => {
					var t = dt();
					ce(t, () => h(o), !0), B(t), i(e, t);
				};
				v(f, (e) => {
					$.scale && h(o) && e(p);
				});
				var m = y(f, 2), g = (e) => {
					var t = ft();
					ce(t, () => h(d), !0), B(t), i(e, t);
				};
				v(m, (e) => {
					$.chordMode !== "off" && h(d) && e(g);
				});
				var _ = y(m, 2), x = (e) => {
					var t = pt(), n = b(t, !0);
					B(t), K(() => W(n, h(r) ? "No chord picture for this bar." : "Nothing playing yet.")), i(e, t);
				};
				v(_, (e) => {
					$.chordMode !== "off" && !h(d) && e(x);
				}), B(c);
				var S = y(c, 2), C = (e) => {
					var n = mt(), a = b(n);
					B(n), K(() => W(a, `No standard shape for ${h(r)?.name ?? ""} on ${h(t) ?? ""} - showing every position instead.`)), i(e, n);
				};
				v(S, (e) => {
					h(u) && e(C);
				}), i(e, n);
			}, x = (e) => {
				var t = gt();
				i(e, t);
			};
			v(g, (e) => {
				h(a) ? e(_) : e(x, -1);
			}), B(f), K(() => W(m, h(t))), i(e, f);
		}), B(t), i(e, t);
	};
	v(w, (e) => {
		h(a).length ? e(E, -1) : e(T);
	}), K(() => {
		F(p, $.chordMode === "off"), F(_, $.chordMode === "notes"), F(S, $.chordMode === "shape");
	}), V(d, () => $.scale, (e) => $.scale = e), N("change", p, () => $.chordMode = "off"), N("change", _, () => $.chordMode = "notes"), N("change", S, () => $.chordMode = "shape"), i(t, o), g();
}
t(["change"]);
//#endregion
//#region frontend/Index.svelte
var xt = /* @__PURE__ */ new Set([
	"$$slots",
	"$$events",
	"$$legacy"
]), St = m("<div class=\"mixer-and-instruments-item svelte-r41nsf\"><!></div>"), Ct = m("<div><!> <!></div>"), wt = m("<div class=\"mixer svelte-r41nsf\"><!> <!> <!> <!> <!> <!> <!></div>");
function Tt(t, r) {
	e(r, !0);
	let a = new fe(ae(r, xt)), o = C(() => a.props.value?.layers ?? []), s = C(() => a.props.value?.timeline ?? []), c = C(() => a.props.value?.notes ?? []), u = C(() => a.props.value?.phrases ?? []), d = C(() => a.props.value?.diagrams ?? {
		structure: {},
		scale: {},
		chords: {},
		shapes: {}
	}), f = l(0), p = C(() => h(f) > 0 && h(f) < 600);
	X.noteLayers(h(o)), n(() => {
		for (let e of h(o)) e.name in X.levels || (X.levels[e.name] = e.level);
	}), a.props.value?.loop_start != null && X.loopFrom === null && (X.loopFrom = a.props.value.loop_start, X.loopTo = a.props.value.loop_end ?? null);
	let m = l(x(X.position())), _ = null;
	function S() {
		z(m, X.position(), !0), _ = requestAnimationFrame(S);
	}
	S(), H(() => {
		_ !== null && cancelAnimationFrame(_);
	});
	let w = l(!0);
	function T() {
		a.props.value && (a.props.value.loop_start = X.loopFrom, a.props.value.loop_end = X.loopTo), a.dispatch("change");
	}
	function E(e, t) {
		let n = X.playing, r = X.select(e, t.shiftKey);
		z(m, X.position(), !0), r && T(), n && X.play(h(o));
	}
	function D(e) {
		let t = X.playing, n = X.selectRange(e.start, e.end);
		z(m, X.position(), !0), n && T(), t && X.play(h(o));
	}
	function ee() {
		X.clearLoop(), z(m, 0), T();
	}
	function te() {
		X.playing && X.play(h(o), X.position());
	}
	function O(e) {
		X.setLevel(e, X.levels[e]), a.dispatch("input");
	}
	ge(t, {
		get visible() {
			return a.shared.visible;
		},
		get elem_id() {
			return a.shared.elem_id;
		},
		get elem_classes() {
			return a.shared.elem_classes;
		},
		get scale() {
			return a.shared.scale;
		},
		get min_width() {
			return a.shared.min_width;
		},
		allow_overflow: !0,
		padding: !0,
		children: (e, t) => {
			var n = wt(), r = b(n);
			{
				let e = C(() => h(s).length > 0);
				Ee(r, {
					get layers() {
						return h(o);
					},
					get playhead() {
						return h(m);
					},
					get hasTimeline() {
						return h(e);
					},
					onClearSelection: ee,
					onToggleRepeat: te,
					get follow() {
						return h(w);
					},
					set follow(e) {
						z(w, e, !0);
					}
				});
			}
			var a = y(r, 2);
			{
				let e = C(() => h(s).length > 0), t = C(() => h(c).length > 0), n = C(() => Object.keys(h(d).structure ?? {}).length > 0);
				Me(a, {
					get hasTimeline() {
						return h(e);
					},
					get hasNotes() {
						return h(t);
					},
					get hasDiagrams() {
						return h(n);
					},
					get narrow() {
						return h(p);
					}
				});
			}
			var l = y(a, 2), g = (e) => {
				Fe(e, {
					get timeline() {
						return h(s);
					},
					get playhead() {
						return h(m);
					},
					get follow() {
						return h(w);
					},
					onSelectBar: E
				});
			};
			v(l, (e) => {
				Z.strip && e(g);
			});
			var _ = y(l, 2), x = (e) => {
				rt(e, {
					get phrases() {
						return h(u);
					},
					onSelectPhrase: D,
					get narrow() {
						return h(p);
					}
				});
			};
			v(_, (e) => {
				Z.phrases && e(x);
			});
			var S = y(_, 2), T = (e) => {
				Qe(e, {
					get notes() {
						return h(c);
					},
					get timeline() {
						return h(s);
					},
					get phrases() {
						return h(u);
					},
					get playhead() {
						return h(m);
					},
					get narrow() {
						return h(p);
					}
				});
			};
			v(S, (e) => {
				Z.notes && e(T);
			});
			var k = y(S, 2), j = (e) => {
				ct(e, {
					get notes() {
						return h(c);
					},
					get phrases() {
						return h(u);
					},
					get playhead() {
						return h(m);
					}
				});
			};
			v(k, (e) => {
				Z.lyrics && e(j);
			});
			var ne = y(k, 2), M = (e) => {
				var t = Ct();
				let n;
				var r = b(t), a = (e) => {
					var t = St();
					Re(b(t), {
						get layers() {
							return h(o);
						},
						onLevelChanged: O
					}), B(t), i(e, t);
				};
				v(r, (e) => {
					Z.faders && e(a);
				});
				var c = y(r, 2), l = (e) => {
					var t = St();
					bt(b(t), {
						get diagrams() {
							return h(d);
						},
						get timeline() {
							return h(s);
						},
						get playhead() {
							return h(m);
						}
					}), B(t), i(e, t);
				};
				v(c, (e) => {
					Z.instruments && e(l);
				}), B(t), K(() => n = A(t, 1, "mixer-and-instruments svelte-r41nsf", null, n, {
					beside: xe.value && Z.faders && Z.instruments,
					shrink: Se.value === "shrink" && !h(p)
				})), i(e, t);
			};
			v(ne, (e) => {
				(Z.faders || Z.instruments) && e(M);
			}), B(n), ie(n, "clientWidth", (e) => z(f, e)), i(e, n);
		},
		$$slots: { default: !0 }
	}), g();
}
//#endregion
export { Tt as default };

import { $ as e, A as t, B as n, D as r, E as i, F as a, G as o, H as s, I as c, J as l, K as u, L as d, M as f, N as p, O as m, P as h, Q as g, R as _, S as v, T as y, U as b, V as x, W as S, X as C, Y as w, Z as T, _ as E, a as D, b as O, c as ee, d as k, et as A, f as j, g as te, h as ne, i as re, j as M, k as N, l as ie, m as P, n as F, nt as I, o as L, p as ae, q as R, r as oe, s as se, t as z, tt as B, u as ce, v as V, w as H, y as U, z as W } from "./index-client-BaSavsPV.js";
//#region frontend/node_modules/@gradio/theme/dist/src/colors.js
var le = [
	{
		color: "red",
		primary: 600,
		secondary: 100
	},
	{
		color: "green",
		primary: 600,
		secondary: 100
	},
	{
		color: "blue",
		primary: 600,
		secondary: 100
	},
	{
		color: "yellow",
		primary: 500,
		secondary: 100
	},
	{
		color: "purple",
		primary: 600,
		secondary: 100
	},
	{
		color: "teal",
		primary: 600,
		secondary: 100
	},
	{
		color: "orange",
		primary: 600,
		secondary: 100
	},
	{
		color: "cyan",
		primary: 600,
		secondary: 100
	},
	{
		color: "lime",
		primary: 500,
		secondary: 100
	},
	{
		color: "pink",
		primary: 600,
		secondary: 100
	}
], ue = {
	inherit: "inherit",
	current: "currentColor",
	transparent: "transparent",
	black: "#000",
	white: "#fff",
	slate: {
		50: "#f8fafc",
		100: "#f1f5f9",
		200: "#e2e8f0",
		300: "#cbd5e1",
		400: "#94a3b8",
		500: "#64748b",
		600: "#475569",
		700: "#334155",
		800: "#1e293b",
		900: "#0f172a",
		950: "#020617"
	},
	gray: {
		50: "#f9fafb",
		100: "#f3f4f6",
		200: "#e5e7eb",
		300: "#d1d5db",
		400: "#9ca3af",
		500: "#6b7280",
		600: "#4b5563",
		700: "#374151",
		800: "#1f2937",
		900: "#111827",
		950: "#030712"
	},
	zinc: {
		50: "#fafafa",
		100: "#f4f4f5",
		200: "#e4e4e7",
		300: "#d4d4d8",
		400: "#a1a1aa",
		500: "#71717a",
		600: "#52525b",
		700: "#3f3f46",
		800: "#27272a",
		900: "#18181b",
		950: "#09090b"
	},
	neutral: {
		50: "#fafafa",
		100: "#f5f5f5",
		200: "#e5e5e5",
		300: "#d4d4d4",
		400: "#a3a3a3",
		500: "#737373",
		600: "#525252",
		700: "#404040",
		800: "#262626",
		900: "#171717",
		950: "#0a0a0a"
	},
	stone: {
		50: "#fafaf9",
		100: "#f5f5f4",
		200: "#e7e5e4",
		300: "#d6d3d1",
		400: "#a8a29e",
		500: "#78716c",
		600: "#57534e",
		700: "#44403c",
		800: "#292524",
		900: "#1c1917",
		950: "#0c0a09"
	},
	red: {
		50: "#fef2f2",
		100: "#fee2e2",
		200: "#fecaca",
		300: "#fca5a5",
		400: "#f87171",
		500: "#ef4444",
		600: "#dc2626",
		700: "#b91c1c",
		800: "#991b1b",
		900: "#7f1d1d",
		950: "#450a0a"
	},
	orange: {
		50: "#fff7ed",
		100: "#ffedd5",
		200: "#fed7aa",
		300: "#fdba74",
		400: "#fb923c",
		500: "#f97316",
		600: "#ea580c",
		700: "#c2410c",
		800: "#9a3412",
		900: "#7c2d12",
		950: "#431407"
	},
	amber: {
		50: "#fffbeb",
		100: "#fef3c7",
		200: "#fde68a",
		300: "#fcd34d",
		400: "#fbbf24",
		500: "#f59e0b",
		600: "#d97706",
		700: "#b45309",
		800: "#92400e",
		900: "#78350f",
		950: "#451a03"
	},
	yellow: {
		50: "#fefce8",
		100: "#fef9c3",
		200: "#fef08a",
		300: "#fde047",
		400: "#facc15",
		500: "#eab308",
		600: "#ca8a04",
		700: "#a16207",
		800: "#854d0e",
		900: "#713f12",
		950: "#422006"
	},
	lime: {
		50: "#f7fee7",
		100: "#ecfccb",
		200: "#d9f99d",
		300: "#bef264",
		400: "#a3e635",
		500: "#84cc16",
		600: "#65a30d",
		700: "#4d7c0f",
		800: "#3f6212",
		900: "#365314",
		950: "#1a2e05"
	},
	green: {
		50: "#f0fdf4",
		100: "#dcfce7",
		200: "#bbf7d0",
		300: "#86efac",
		400: "#4ade80",
		500: "#22c55e",
		600: "#16a34a",
		700: "#15803d",
		800: "#166534",
		900: "#14532d",
		950: "#052e16"
	},
	emerald: {
		50: "#ecfdf5",
		100: "#d1fae5",
		200: "#a7f3d0",
		300: "#6ee7b7",
		400: "#34d399",
		500: "#10b981",
		600: "#059669",
		700: "#047857",
		800: "#065f46",
		900: "#064e3b",
		950: "#022c22"
	},
	teal: {
		50: "#f0fdfa",
		100: "#ccfbf1",
		200: "#99f6e4",
		300: "#5eead4",
		400: "#2dd4bf",
		500: "#14b8a6",
		600: "#0d9488",
		700: "#0f766e",
		800: "#115e59",
		900: "#134e4a",
		950: "#042f2e"
	},
	cyan: {
		50: "#ecfeff",
		100: "#cffafe",
		200: "#a5f3fc",
		300: "#67e8f9",
		400: "#22d3ee",
		500: "#06b6d4",
		600: "#0891b2",
		700: "#0e7490",
		800: "#155e75",
		900: "#164e63",
		950: "#083344"
	},
	sky: {
		50: "#f0f9ff",
		100: "#e0f2fe",
		200: "#bae6fd",
		300: "#7dd3fc",
		400: "#38bdf8",
		500: "#0ea5e9",
		600: "#0284c7",
		700: "#0369a1",
		800: "#075985",
		900: "#0c4a6e",
		950: "#082f49"
	},
	blue: {
		50: "#eff6ff",
		100: "#dbeafe",
		200: "#bfdbfe",
		300: "#93c5fd",
		400: "#60a5fa",
		500: "#3b82f6",
		600: "#2563eb",
		700: "#1d4ed8",
		800: "#1e40af",
		900: "#1e3a8a",
		950: "#172554"
	},
	indigo: {
		50: "#eef2ff",
		100: "#e0e7ff",
		200: "#c7d2fe",
		300: "#a5b4fc",
		400: "#818cf8",
		500: "#6366f1",
		600: "#4f46e5",
		700: "#4338ca",
		800: "#3730a3",
		900: "#312e81",
		950: "#1e1b4b"
	},
	violet: {
		50: "#f5f3ff",
		100: "#ede9fe",
		200: "#ddd6fe",
		300: "#c4b5fd",
		400: "#a78bfa",
		500: "#8b5cf6",
		600: "#7c3aed",
		700: "#6d28d9",
		800: "#5b21b6",
		900: "#4c1d95",
		950: "#2e1065"
	},
	purple: {
		50: "#faf5ff",
		100: "#f3e8ff",
		200: "#e9d5ff",
		300: "#d8b4fe",
		400: "#c084fc",
		500: "#a855f7",
		600: "#9333ea",
		700: "#7e22ce",
		800: "#6b21a8",
		900: "#581c87",
		950: "#3b0764"
	},
	fuchsia: {
		50: "#fdf4ff",
		100: "#fae8ff",
		200: "#f5d0fe",
		300: "#f0abfc",
		400: "#e879f9",
		500: "#d946ef",
		600: "#c026d3",
		700: "#a21caf",
		800: "#86198f",
		900: "#701a75",
		950: "#4a044e"
	},
	pink: {
		50: "#fdf2f8",
		100: "#fce7f3",
		200: "#fbcfe8",
		300: "#f9a8d4",
		400: "#f472b6",
		500: "#ec4899",
		600: "#db2777",
		700: "#be185d",
		800: "#9d174d",
		900: "#831843",
		950: "#500724"
	},
	rose: {
		50: "#fff1f2",
		100: "#ffe4e6",
		200: "#fecdd3",
		300: "#fda4af",
		400: "#fb7185",
		500: "#f43f5e",
		600: "#e11d48",
		700: "#be123c",
		800: "#9f1239",
		900: "#881337",
		950: "#4c0519"
	}
};
le.reduce((e, { color: t, primary: n, secondary: r }) => ({
	...e,
	[t]: {
		primary: ue[t][n],
		secondary: ue[t][r]
	}
}), {});
//#endregion
//#region frontend/node_modules/svelte/src/store/index-client.js
function G(e) {
	let t, n = l((n) => {
		let r = !1, i = e.subscribe((e) => {
			t = e, r && n();
		});
		return r = !0, i;
	});
	function r() {
		return h() ? (n(), t) : w(e);
	}
	return "set" in e ? {
		get current() {
			return r();
		},
		set current(t) {
			e.set(t);
		}
	} : { get current() {
		return r();
	} };
}
var K = [
	"label",
	"info",
	"placeholder",
	"description",
	"title",
	"value"
], q = /* @__PURE__ */ "elem_id.elem_classes.visible.interactive.server_fns.server.id.target.theme_mode.version.root.autoscroll.max_file_size.formatter.client.load_component.scale.min_width.theme.padding.loading_status.label.show_label.validation_error.show_progress.api_prefix.container.attached_events.register_component.unregister_component.dispatcher".split(".");
function de(e) {
	return typeof e == "string" && e.includes("__i18n__");
}
var fe = class {
	load_component;
	#e = u(s({}));
	get shared() {
		return f(this.#e);
	}
	set shared(e) {
		o(this.#e, e, !0);
	}
	#t = u(s({}));
	get props() {
		return f(this.#t);
	}
	set props(e) {
		o(this.#t, e, !0);
	}
	#n = u((e) => e);
	get i18n() {
		return f(this.#n);
	}
	set i18n(e) {
		o(this.#n, e, !0);
	}
	i18n_store;
	_i18n_from_store;
	translatable_props = {};
	dispatcher;
	last_update = null;
	shared_props = q;
	mounted = !1;
	old_value;
	register_component;
	unregister_component;
	set_data_callback;
	get_data_callback;
	registered_id = null;
	last_shared_props;
	last_props;
	constructor(e, t) {
		for (let t in e.shared_props) this.shared[t] = e.shared_props[t];
		for (let t in e.props) t !== "i18n_store" && (this.props[t] = e.props[t]);
		if (t) for (let e in t) this.props[e] === void 0 && (this.props[e] = t[e]);
		this.i18n = this.props.i18n ?? ((e) => e), this.i18n_store = e.props.i18n_store, this._i18n_from_store = this.i18n_store ? G(this.i18n_store) : void 0;
		for (let t of K) this.shared[t] = this._translate_and_store("shared", t, e.shared_props[t]), this.props[t] = this._translate_and_store("props", t, e.props[t]);
		this.load_component = this.shared.load_component, this.register_component = this.shared.register_component || (() => {}), this.unregister_component = this.shared.unregister_component || (() => {}), this.dispatcher = this.shared.dispatcher || (() => {}), this.set_data_callback = this.set_data.bind(this), this.get_data_callback = this.get_data.bind(this), this.register_component(this.shared.id, this.set_data_callback, this.get_data_callback), this.registered_id = this.shared.id, this.last_shared_props = e.shared_props, this.last_props = e.props, _(() => {
			let t = e.shared_props.id;
			if (this.last_shared_props !== e.shared_props) {
				for (let t in e.shared_props) {
					let n = e.shared_props[t];
					n !== void 0 && (this._is_i18n_managed(`shared.${t}`, n) || (this.shared[t] = n));
				}
				this.last_shared_props = e.shared_props;
			}
			if (this.last_props !== e.props) {
				for (let t in e.props) {
					if (t === "i18n_store") continue;
					let n = e.props[t];
					n !== void 0 && (this._is_i18n_managed(`props.${t}`, n) || (this.props[t] = n));
				}
				this.last_props = e.props;
			}
			this.registered_id !== null && this.registered_id !== t && this.unregister_component(this.registered_id, this.set_data_callback), this.register_component(t, this.set_data_callback, this.get_data_callback), this.registered_id = t, p(() => {
				this.shared.id = t;
			});
		}), _(() => () => {
			this.registered_id !== null && this.unregister_component(this.registered_id, this.set_data_callback);
		}), _(() => {
			if (this.i18n_store) return this.i18n_store.subscribe(() => {
				for (let [e, t] of Object.entries(this.translatable_props)) {
					let [n, r] = e.split("."), i = this.i18n(t);
					n === "shared" ? this.shared[r] = i : this.props[r] = i;
				}
			});
		});
	}
	_is_i18n_managed(e, t) {
		let n = this.translatable_props[e];
		return n ? t === n || (delete this.translatable_props[e], !1) : !1;
	}
	_translate_and_store(e, t, n) {
		if (typeof n != "string") return n;
		let r = this.i18n(n);
		return r !== n && (this.translatable_props[`${e}.${t}`] = n), r;
	}
	live_i18n = (e) => (this._i18n_from_store?.current, this.i18n(e));
	dispatch(e, t) {
		this.dispatcher(this.shared.id, e, t);
	}
	async get_data() {
		return g(this.props);
	}
	update(e) {
		this.set_data(e);
	}
	set_data(e) {
		for (let t in e) {
			let n = e[t], r = de(n) ? this._translate_and_store(this.shared_props.includes(t) ? "shared" : "props", t, n) : n;
			if (this.shared_props.includes(t)) {
				let e = t;
				this.shared[e] = r;
				continue;
			}
			this.props[t] = r;
		}
	}
	watch_for_change() {
		_(() => {
			this.mounted ||= (this.old_value = this.props.value, !0), this.old_value != this.props.value && (this.old_value = this.props.value, this.dispatch("change"));
		});
	}
};
//#endregion
//#region frontend/node_modules/svelte/src/internal/flags/legacy.js
e();
//#endregion
//#region frontend/node_modules/@gradio/atoms/dist/src/Block.svelte
var pe = r("<svg class=\"resize-handle svelte-1stq1b1\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 10 10\"><line x1=\"1\" y1=\"9\" x2=\"9\" y2=\"1\" stroke=\"gray\" stroke-width=\"0.5\" class=\"svelte-1stq1b1\"></line><line x1=\"5\" y1=\"9\" x2=\"9\" y2=\"5\" stroke=\"gray\" stroke-width=\"0.5\" class=\"svelte-1stq1b1\"></line></svg>"), me = i("<!> <!>", 1), he = i("<div class=\"placeholder svelte-1stq1b1\"></div>");
function ge(e, r) {
	T(r, !1);
	let i = F(r, "height", 8, void 0), s = F(r, "min_height", 8, void 0), l = F(r, "max_height", 8, void 0), u = F(r, "width", 8, void 0), m = F(r, "elem_id", 8, ""), h = F(r, "elem_classes", 24, () => []), g = F(r, "variant", 8, "solid"), _ = F(r, "border_mode", 8, "base"), v = F(r, "padding", 8, !0), w = F(r, "type", 8, "normal"), E = F(r, "test_id", 8, void 0), k = F(r, "explicit_call", 8, !1), A = F(r, "container", 8, !0), j = F(r, "visible", 8, !0), N = F(r, "allow_overflow", 8, !0), P = F(r, "overflow_behavior", 8, "auto"), I = F(r, "scale", 8, null), L = F(r, "min_width", 8, 0), R = F(r, "flex", 12, !1), oe = F(r, "resizable", 8, !1), se = F(r, "rtl", 8, !1), z = F(r, "fullscreen", 12, !1), B = F(r, "label", 8, void 0), V = b(z()), U = b(), W = w() === "fieldset" ? "fieldset" : "div", le = b(0), ue = b(0), G = b(null), K = null, q = null;
	function de(e) {
		z() && e.key === "Escape" && z(!1);
	}
	function fe() {
		let e = f(U).getRootNode();
		return f(U).closest(".gradio-container") ?? (e instanceof ShadowRoot ? e : document.body);
	}
	function ge(e) {
		let t = document.createElement("div");
		t.style.cssText = "position: fixed; top: 0; left: 0; width: 100%; height: 100%; visibility: hidden; pointer-events: none;", e.appendChild(t);
		let n = t.getBoundingClientRect();
		return t.remove(), n;
	}
	function J(e) {
		let t = f(U).parentNode;
		if (!t || t === e) return !1;
		let n = ge(t), r = ge(e);
		return Math.abs(n.top - r.top) > 1 || Math.abs(n.left - r.left) > 1 || Math.abs(n.width - r.width) > 1 || Math.abs(n.height - r.height) > 1;
	}
	function Y(e) {
		!f(U).parentNode || f(U).parentNode === e || (K = f(U).parentNode, q = document.createComment("fullscreen block"), K.insertBefore(q, f(U)), e.appendChild(f(U)));
	}
	function X() {
		if (!K) return;
		let e = q && q.parentNode === K ? q : null;
		K.insertBefore(f(U), e), e?.remove(), K = null, q = null;
	}
	let Z = (e) => {
		if (e !== void 0) {
			if (typeof e == "number") return e + "px";
			if (typeof e == "string") return e;
		}
	}, Q = (e) => {
		let t = e.clientY, n = (e) => {
			let n = e.clientY - t;
			t = e.clientY, S(U, f(U).style.height = `${f(U).offsetHeight + n}px`);
		}, r = () => {
			window.removeEventListener("mousemove", n), window.removeEventListener("mouseup", r);
		};
		window.addEventListener("mousemove", n), window.addEventListener("mouseup", r);
	};
	a(() => (M(z()), f(V), f(U)), () => {
		if (z() !== f(V)) {
			if (o(V, z()), z()) {
				o(G, f(U).getBoundingClientRect()), o(le, f(U).offsetHeight), o(ue, f(U).offsetWidth);
				let e = fe();
				J(e) && Y(e), window.addEventListener("keydown", de);
			} else X(), o(G, null), window.removeEventListener("keydown", de);
		}
	}), a(() => M(j()), () => {
		j() || R(!1);
	}), c(), re();
	var _e = y(), ve = n(_e), ye = (e) => {
		var a = me(), c = n(a);
		ne(c, () => W, !1, (e, a) => {
			D(e, (e) => o(U, e), () => f(U)), ce(e, (e, t) => ({
				"data-testid": E(),
				id: m(),
				class: `block ${e ?? ""}`,
				dir: se() ? "rtl" : "ltr",
				"aria-label": B(),
				style: "",
				[ee]: {
					hidden: j() === "hidden",
					padded: v(),
					flex: R(),
					border_focus: _() === "focus",
					border_contrast: _() === "contrast",
					"hide-container": !k() && !A(),
					fullscreen: z(),
					animating: z() && f(G) !== null,
					"auto-margin": I() === null
				},
				[ie]: t
			}), [() => (M(h()), p(() => h()?.join(" ") || "")), () => ({
				height: (M(z()), M(i()), p(() => z() ? void 0 : Z(i()))),
				"min-height": (M(z()), M(s()), p(() => z() ? void 0 : Z(s()))),
				"max-height": (M(z()), M(l()), p(() => z() ? void 0 : Z(l()))),
				"--start-top": (f(G), p(() => f(G) ? `${f(G).top}px` : "0px")),
				"--start-left": (f(G), p(() => f(G) ? `${f(G).left}px` : "0px")),
				"--start-width": (f(G), p(() => f(G) ? `${f(G).width}px` : "0px")),
				"--start-height": (f(G), p(() => f(G) ? `${f(G).height}px` : "0px")),
				width: (M(z()), M(u()), p(() => z() ? void 0 : typeof u() == "number" ? `calc(min(${u()}px, 100%))` : Z(u()))),
				"border-style": g(),
				overflow: N() ? P() : "hidden",
				"flex-grow": I(),
				"min-width": `calc(min(${L()}px, 100%))`
			})], void 0, void 0, "svelte-1stq1b1");
			var c = me(), d = n(c);
			te(d, r, "default", {}, null);
			var y = x(d, 2), b = (e) => {
				var n = pe();
				t("mousedown", n, Q), H(e, n);
			};
			O(y, (e) => {
				oe() && e(b);
			}), H(a, c);
		});
		var y = x(c, 2), b = (e) => {
			var t = he();
			let n;
			d(() => n = ae(t, "", n, {
				height: f(le) + "px",
				width: f(ue) + "px"
			})), H(e, t);
		};
		O(y, (e) => {
			z() && e(b);
		}), H(e, a);
	};
	O(ve, (e) => {
		(j() === !0 || j() === "hidden") && e(ye);
	}), H(e, _e), C();
}
//#endregion
//#region frontend/node_modules/@gradio/atoms/dist/src/SelectSource.svelte
m(["click"]), m(["click"]);
var J = new class {
	#e;
	get playing() {
		return f(this.#e);
	}
	set playing(e) {
		o(this.#e, e, !0);
	}
	#t;
	get offset() {
		return f(this.#t);
	}
	set offset(e) {
		o(this.#t, e, !0);
	}
	#n;
	get loopFrom() {
		return f(this.#n);
	}
	set loopFrom(e) {
		o(this.#n, e, !0);
	}
	#r;
	get loopTo() {
		return f(this.#r);
	}
	set loopTo(e) {
		o(this.#r, e, !0);
	}
	#i;
	get levels() {
		return f(this.#i);
	}
	set levels(e) {
		o(this.#i, e, !0);
	}
	#a;
	get repeat() {
		return f(this.#a);
	}
	set repeat(e) {
		o(this.#a, e, !0);
	}
	constructor() {
		this.context = null, this.master = null, this.buffers = {}, this.gains = {}, this.sources = [], this.startedAt = 0, this.fingerprint = "", this.selectionFingerprint = "", this.#e = u(!1), this.#t = u(0), this.#n = u(null), this.#r = u(null), this.#i = u(s({})), this.anchor = null, this.#a = u(!0);
	}
	position() {
		if (!this.context || !this.playing) return this.offset;
		let e = this.offset + (this.context.currentTime - this.startedAt);
		if (this.loopFrom !== null && this.loopTo !== null && e > this.loopTo) {
			let t = this.loopTo - this.loopFrom;
			e = this.loopFrom + (e - this.loopFrom) % t;
		}
		return e;
	}
	bytesFrom(e) {
		let t = atob(e), n = new Uint8Array(t.length);
		for (let e = 0; e < t.length; e++) n[e] = t.charCodeAt(e);
		return n.buffer;
	}
	computeFingerprint(e) {
		return e.map((e) => {
			let t = e.wav;
			return e.name + ":" + t.length + ":" + t.slice(0, 24) + ":" + t.slice(-24);
		}).join("|");
	}
	noteLayers(e) {
		let t = this.computeFingerprint(e);
		t !== this.selectionFingerprint && (this.clearLoop(), this.selectionFingerprint = t);
	}
	async ensureAudio(e) {
		if (!this.context) {
			this.context = new (window.AudioContext || window.webkitAudioContext)();
			let e = this.context.createGain();
			e.gain.value = .7;
			let t = this.context.createDynamicsCompressor();
			t.threshold.value = -6, t.knee.value = 0, t.ratio.value = 20, t.attack.value = .003, t.release.value = .15, e.connect(t), t.connect(this.context.destination), this.master = e;
		}
		let t = this.computeFingerprint(e);
		if (this.fingerprint !== t) {
			for (let e of Object.keys(this.gains)) this.gains[e].disconnect();
			this.buffers = {}, this.gains = {};
			for (let t of e) {
				let e = this.context.createGain();
				e.gain.value = this.levels[t.name] ?? t.level, e.connect(this.master), this.gains[t.name] = e, this.buffers[t.name] = await this.context.decodeAudioData(this.bytesFrom(t.wav));
			}
			this.fingerprint = t;
		}
	}
	stopSources() {
		for (let e of this.sources) {
			e.onended = null;
			try {
				e.stop();
			} catch {}
			e.disconnect();
		}
		this.sources = [];
	}
	async play(e, t) {
		let n = t ?? this.offset;
		if (this.stopSources(), this.playing = !1, await this.ensureAudio(e), this.context) {
			this.context.state === "suspended" && await this.context.resume(), this.offset = n, this.startedAt = this.context.currentTime, this.playing = !0;
			for (let t of e) {
				let e = this.context.createBufferSource();
				e.buffer = this.buffers[t.name], this.loopFrom !== null && this.loopTo !== null && this.repeat && (e.loop = !0, e.loopStart = this.loopFrom, e.loopEnd = this.loopTo), e.connect(this.gains[t.name]), e.start(this.startedAt, this.offset), this.loopFrom !== null && this.loopTo !== null && !this.repeat && e.stop(this.startedAt + (this.loopTo - this.offset)), this.sources.push(e);
			}
			this.sources.length && (this.sources[0].onended = () => {
				this.playing = !1;
			});
		}
	}
	stop() {
		this.offset = this.position(), this.stopSources(), this.playing = !1;
	}
	select(e, t) {
		let n = this.loopFrom !== null && this.loopTo !== null, r = this.loopFrom, i = this.loopTo, a = n && e.start >= this.loopFrom - .001 && e.end <= this.loopTo + .001;
		if (t && this.anchor !== null && !n) {
			let t = Math.min(this.anchor.start, e.start), n = Math.max(this.anchor.end, e.end);
			this.loopFrom = t, this.loopTo = Math.max(n, t + .05), this.offset = this.loopFrom;
		} else !t && a ? this.offset = e.start : (this.anchor = e, this.loopFrom = e.start, this.loopTo = null, this.offset = e.start);
		return this.stopSources(), this.playing = !1, this.loopFrom !== r || this.loopTo !== i;
	}
	selectRange(e, t) {
		let n = this.loopFrom, r = this.loopTo;
		return this.anchor = null, this.loopFrom = e, this.loopTo = Math.max(t, e + .05), this.offset = e, this.stopSources(), this.playing = !1, this.loopFrom !== n || this.loopTo !== r;
	}
	clearLoop() {
		this.anchor = null, this.loopFrom = null, this.loopTo = null, this.offset = 0, this.stopSources(), this.playing = !1;
	}
	setLevel(e, t) {
		this.levels[e] = t, this.gains[e] && this.context && this.gains[e].gain.setTargetAtTime(t, this.context.currentTime, .01);
	}
}(), Y = s({
	strip: !0,
	faders: !0,
	notes: !1,
	lyrics: !1,
	instruments: !1
}), X = s({
	Melody: !0,
	"Harmony above": !1,
	"Harmony below": !1,
	Bass: !1
}), Z = s({ value: !1 }), Q = s({ value: !1 }), _e = s({ value: !1 }), ve = s({ value: !0 }), ye = s({ value: !1 }), be = s({
	Piano: !1,
	Guitar: !1,
	"Violin, first position": !1,
	"Violin, third position": !1
}), $ = s({
	scale: !1,
	chord: !0
}), xe = i("<label class=\"repeat svelte-d89286\"><input type=\"checkbox\" class=\"svelte-d89286\"/> Repeat</label>"), Se = i("<label class=\"repeat svelte-d89286\"><input type=\"checkbox\" class=\"svelte-d89286\"/> Follow</label>"), Ce = i("<div class=\"transport svelte-d89286\"><button class=\"svelte-d89286\">Play</button> <button class=\"svelte-d89286\">Stop</button> <button class=\"svelte-d89286\">Clear selection</button> <!> <span class=\"time svelte-d89286\"> </span> <!></div>");
function we(e, t) {
	T(t, !0);
	let n = F(t, "follow", 15);
	var r = Ce(), i = W(r), a = x(i, 2), o = x(a, 2), s = x(o, 2), c = (e) => {
		var n = xe(), r = W(n);
		k(r), A(), B(n), N("change", r, function(...e) {
			t.onToggleRepeat?.apply(this, e);
		}), L(r, () => J.repeat, (e) => J.repeat = e), H(e, n);
	};
	O(s, (e) => {
		J.loopFrom !== null && J.loopTo !== null && e(c);
	});
	var l = x(s, 2), u = W(l);
	B(l);
	var f = x(l, 2), p = (e) => {
		var t = Se(), r = W(t);
		k(r), A(), B(t), L(r, n), H(e, t);
	};
	O(f, (e) => {
		t.hasTimeline && e(p);
	}), B(r), d((e) => v(u, `${e ?? ""}s`), [() => t.playhead.toFixed(1)]), N("click", i, () => J.play(t.layers)), N("click", a, () => J.stop()), N("click", o, function(...e) {
		t.onClearSelection?.apply(this, e);
	}), H(e, r), C();
}
m(["click", "change"]);
//#endregion
//#region frontend/PanelToggles.svelte
var Te = i("<label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Chart</label>"), Ee = i("<label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Notes</label> <label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Lyrics</label>", 1), De = i("<label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Instruments</label>"), Oe = i("<div class=\"panel-toggles svelte-1mngm7u\"><!> <!> <label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Mixer</label> <!></div>");
function ke(e, t) {
	T(t, !0);
	var r = Oe(), i = W(r), a = (e) => {
		var t = Te(), n = W(t);
		k(n), A(), B(t), L(n, () => Y.strip, (e) => Y.strip = e), H(e, t);
	};
	O(i, (e) => {
		t.hasTimeline && e(a);
	});
	var o = x(i, 2), s = (e) => {
		var t = Ee(), r = n(t), i = W(r);
		k(i), A(), B(r);
		var a = x(r, 2), o = W(a);
		k(o), A(), B(a), L(i, () => Y.notes, (e) => Y.notes = e), L(o, () => Y.lyrics, (e) => Y.lyrics = e), H(e, t);
	};
	O(o, (e) => {
		t.hasNotes && e(s);
	});
	var c = x(o, 2), l = W(c);
	k(l), A(), B(c);
	var u = x(c, 2), d = (e) => {
		var t = De(), n = W(t);
		k(n), A(), B(t), L(n, () => Y.instruments, (e) => Y.instruments = e), H(e, t);
	};
	O(u, (e) => {
		t.hasDiagrams && e(d);
	}), B(r), L(l, () => Y.faders, (e) => Y.faders = e), H(e, r), C();
}
//#endregion
//#region frontend/ChordStrip.svelte
var Ae = i("<button type=\"button\"><div class=\"number svelte-65z4tz\"> </div> <div class=\"chord svelte-65z4tz\"> </div> <div class=\"words svelte-65z4tz\"> </div></button>"), je = i("<div class=\"strip svelte-65z4tz\"></div> <p class=\"note svelte-65z4tz\"> </p>", 1);
function Me(e, t) {
	T(t, !0);
	let r = R(() => t.timeline.find((e) => t.playhead >= e.start && t.playhead < e.end)), i = R(() => J.loopFrom === null ? t.timeline.length ? "Click a bar to select where Play starts. Shift-click a later bar to loop a stretch." : "" : J.loopTo === null ? `Play starts at ${J.loopFrom.toFixed(1)}s. Shift-click a later bar to select a stretch, or press Play.` : J.repeat ? `Repeating ${J.loopFrom.toFixed(1)}s to ${J.loopTo.toFixed(1)}s. Untick Repeat to play it once, or Clear selection to release it.` : `Selected ${J.loopFrom.toFixed(1)}s to ${J.loopTo.toFixed(1)}s, playing once. Tick Repeat to loop it.`), a = {};
	_(() => {
		t.follow && f(r) && a[f(r).bar] && a[f(r).bar].scrollIntoView({
			behavior: "smooth",
			inline: "center",
			block: "nearest"
		});
	});
	var o = y(), s = n(o), c = (e) => {
		var o = je(), s = n(o);
		V(s, 21, () => t.timeline, (e) => e.bar, (e, n) => {
			var i = Ae();
			let o;
			var s = W(i), c = W(s, !0);
			B(s);
			var l = x(s, 2), u = W(l, !0);
			B(l);
			var p = x(l, 2), m = W(p, !0);
			B(p), B(i), D(i, (e, t) => a[t.bar] = e, (e) => a?.[e.bar], () => [f(n)]), d(() => {
				o = P(i, 1, "bar svelte-65z4tz", null, o, {
					playing: f(r) === f(n),
					looped: J.loopFrom !== null && J.loopTo !== null && f(n).start >= J.loopFrom - .001 && f(n).end <= J.loopTo + .001
				}), j(i, "data-bar", f(n).bar), v(c, f(n).bar), v(u, f(n).name), v(m, f(n).words);
			}), N("click", i, (e) => t.onSelectBar(f(n), e)), N("keydown", i, (e) => {
				(e.key === "Enter" || e.key === " ") && (e.preventDefault(), t.onSelectBar(f(n), e));
			}), H(e, i);
		}), B(s);
		var c = x(s, 2), l = W(c, !0);
		B(c), d(() => v(l, f(i))), H(e, o);
	};
	O(s, (e) => {
		t.timeline.length && e(c);
	}), H(e, o), C();
}
m(["click", "keydown"]);
//#endregion
//#region frontend/FaderPanel.svelte
var Ne = i("<div class=\"fader-row svelte-ma6git\"><span class=\"name svelte-ma6git\"> </span> <button class=\"mute svelte-ma6git\">M</button> <input type=\"range\" min=\"0\" max=\"1\" step=\"0.05\" class=\"svelte-ma6git\"/> <span class=\"value svelte-ma6git\"> </span></div>"), Pe = i("<div class=\"faders\"></div>");
function Fe(e, t) {
	T(t, !0);
	function n(e, n) {
		J.levels[e] = J.levels[e] > 0 ? 0 : n, t.onLevelChanged(e);
	}
	var r = Pe();
	V(r, 21, () => t.layers, (e) => e.name, (e, r) => {
		var i = Ne(), a = W(i), o = W(a, !0);
		B(a);
		var s = x(a, 2), c = x(s, 2);
		k(c);
		var l = x(c, 2), u = W(l);
		B(l), B(i), d((e) => {
			ae(a, `color:${f(r).colour ?? ""}`), v(o, f(r).name), v(u, `${e ?? ""}%`);
		}, [() => Math.round((J.levels[f(r).name] ?? 0) * 100)]), N("click", s, () => n(f(r).name, f(r).level)), N("input", c, () => t.onLevelChanged(f(r).name)), se(c, () => J.levels[f(r).name], (e) => J.levels[f(r).name] = e), H(e, i);
	}), B(r), H(e, r), C();
}
m(["click", "input"]);
//#endregion
//#region frontend/NotesPanel.svelte
var Ie = r("<rect class=\"loop-region svelte-1nlxyec\" y=\"0\"></rect>"), Le = r("<line class=\"bar-line svelte-1nlxyec\" y1=\"0\"></line>"), Re = r("<text class=\"note-label svelte-1nlxyec\"> </text>"), ze = r("<text class=\"note-word svelte-1nlxyec\"> </text>"), Be = r("<g><rect class=\"note-box svelte-1nlxyec\"></rect><!><!></g>"), Ve = r("<line class=\"playhead svelte-1nlxyec\" y1=\"0\"></line>"), He = r("<svg><!><!><!><!></svg>"), Ue = i("<label class=\"layer-toggle svelte-1nlxyec\"><input type=\"checkbox\" class=\"svelte-1nlxyec\"/> </label>"), We = i("<label class=\"layer-toggle svelte-1nlxyec\"><input type=\"checkbox\" class=\"svelte-1nlxyec\"/> Side by side</label>"), Ge = i("<div class=\"notes-container next-page svelte-1nlxyec\"><!></div>"), Ke = i("<div><div class=\"notes-container svelte-1nlxyec\"><!></div> <!></div>"), qe = i("<p class=\"note-empty svelte-1nlxyec\">No layers selected to show.</p>"), Je = i("<div class=\"notes-toggles svelte-1nlxyec\"><!> <label class=\"layer-toggle preview-toggle svelte-1nlxyec\"><input type=\"checkbox\" class=\"svelte-1nlxyec\"/> Preview next phrase</label> <!> <label class=\"layer-toggle svelte-1nlxyec\"><input type=\"checkbox\" class=\"svelte-1nlxyec\"/> Word labels</label></div> <!>", 1);
function Ye(e, t) {
	T(t, !0);
	let r = (e, n = I, r = I, a = I) => {
		var o = He();
		let s;
		var c = W(o), l = (e) => {
			var t = Ie();
			d((e, r) => {
				j(t, "x", e), j(t, "width", r), j(t, "height", n().height);
			}, [() => w(n(), Math.max(J.loopFrom, n().phrase.start)), () => Math.max(0, w(n(), Math.min(J.loopTo, n().phrase.end)) - w(n(), Math.max(J.loopFrom, n().phrase.start)))]), H(e, t);
		};
		O(c, (e) => {
			r() && J.loopFrom !== null && J.loopTo !== null && e(l);
		});
		var u = x(c);
		V(u, 17, () => n().bars, U, (e, t) => {
			var r = Le();
			d((e, t) => {
				j(r, "x1", e), j(r, "x2", t), j(r, "y2", n().height);
			}, [() => w(n(), f(t).start), () => w(n(), f(t).start)]), H(e, r);
		});
		var m = x(u);
		V(m, 17, () => n().notes, U, (e, t) => {
			var r = Be(), a = W(r);
			j(a, "height", i - 2);
			var o = x(a), s = (e) => {
				var r = Re(), a = W(r, !0);
				B(r), d((e, n, i) => {
					j(r, "x", e), j(r, "y", n), j(r, "fill", f(t).colour), v(a, i);
				}, [
					() => w(n(), f(t).start) + f(t).length * n().pxPerSecond / 2,
					() => S(n(), f(t).midi) + i / 2,
					() => p(f(t).midi)
				]), H(e, r);
			};
			O(o, (e) => {
				f(t).length * n().pxPerSecond > 20 && e(s);
			});
			var c = x(o), l = (e) => {
				var r = ze(), a = W(r, !0);
				B(r), d((e, n) => {
					j(r, "x", e), j(r, "y", n), v(a, f(t).word);
				}, [() => w(n(), f(t).start) + f(t).length * n().pxPerSecond / 2, () => S(n(), f(t).midi) + i + 10]), H(e, r);
			};
			O(c, (e) => {
				f(t).word && ve.value && e(l);
			}), B(r), d((e, n, r) => {
				j(a, "x", e), j(a, "y", n), j(a, "width", r), j(a, "fill", f(t).colour), j(a, "fill-opacity", f(t).layer === "Melody" ? .22 : .14), j(a, "stroke", f(t).colour);
			}, [
				() => w(n(), f(t).start),
				() => S(n(), f(t).midi) + 1,
				() => Math.max(f(t).length * n().pxPerSecond - 1, 2)
			]), H(e, r);
		});
		var h = x(m), g = (e) => {
			var r = Ve();
			d((e, t) => {
				j(r, "x1", e), j(r, "x2", t), j(r, "y2", n().height);
			}, [() => w(n(), t.playhead), () => w(n(), t.playhead)]), H(e, r);
		};
		O(h, (e) => {
			r() && e(g);
		}), B(o), d(() => {
			j(o, "width", n().width), j(o, "height", n().height), j(o, "viewBox", `0 0 ${n().width ?? ""} ${n().height ?? ""}`), s = P(o, 0, "svelte-1nlxyec", null, s, { dimmed: a() });
		}), H(e, o);
	}, i = 14, a = R(() => t.phrases.length ? t.phrases : t.notes.length ? [{
		start: 0,
		end: t.notes.reduce((e, t) => Math.max(e, t.start + t.length), 0),
		label: "1. Whole part"
	}] : []), s = R(() => {
		if (!f(a).length) return -1;
		let e = f(a).findIndex((e) => t.playhead < e.end);
		return e === -1 ? f(a).length - 1 : e;
	}), c = R(() => f(s) >= 0 ? f(a)[f(s)] : null), l = R(() => f(s) >= 0 && f(s) + 1 < f(a).length ? f(a)[f(s) + 1] : null);
	function p(e) {
		return [
			"C",
			"C#",
			"D",
			"D#",
			"E",
			"F",
			"F#",
			"G",
			"G#",
			"A",
			"A#",
			"B"
		][e % 12] + Math.floor(e / 12 - 1);
	}
	let m = u(null), h = u(600);
	_(() => {
		f(m) && o(h, f(m).clientWidth || f(h), !0);
	});
	function g(e, n) {
		if (!e) return null;
		let r = t.timeline.filter((t) => t.start < e.end && t.end > e.start), i = t.notes.filter((t) => X[t.layer] && t.start >= e.start && t.start < e.end), a = 60, o = 72;
		if (i.length) {
			a = i[0].midi, o = i[0].midi;
			for (let e of i) e.midi < a && (a = e.midi), e.midi > o && (o = e.midi);
			--a, o += 1;
		}
		let s = (o - a + 1) * 14, c = e.end - e.start, l = c > 0 ? n / c : 60;
		return {
			phrase: e,
			bars: r,
			notes: i,
			pitchRange: {
				lowest: a,
				highest: o
			},
			width: n,
			height: s,
			pxPerSecond: l
		};
	}
	let y = R(() => {
		let e = Z.value && Q.value ? (f(h) - 8) / 2 : f(h);
		return g(f(c), e);
	}), b = R(() => {
		if (!Z.value) return null;
		let e = Q.value ? (f(h) - 8) / 2 : f(h);
		return g(f(l), e);
	});
	function S(e, t) {
		return (e.pitchRange.highest - t) * 14;
	}
	function w(e, t) {
		return (t - e.phrase.start) * e.pxPerSecond;
	}
	var E = Je(), ee = n(E), te = W(ee);
	V(te, 17, () => Object.keys(X), U, (e, t) => {
		var n = Ue(), r = W(n);
		k(r);
		var i = x(r);
		B(n), d(() => v(i, ` ${f(t) ?? ""}`)), L(r, () => X[f(t)], (e) => X[f(t)] = e), H(e, n);
	});
	var ne = x(te, 2), re = W(ne);
	k(re), A(), B(ne);
	var M = x(ne, 2), N = (e) => {
		var t = We(), n = W(t);
		k(n), A(), B(t), L(n, () => Q.value, (e) => Q.value = e), H(e, t);
	};
	O(M, (e) => {
		Z.value && e(N);
	});
	var ie = x(M, 2), F = W(ie);
	k(F), A(), B(ie), B(ee);
	var ae = x(ee, 2), oe = (e) => {
		var t = Ke();
		let n;
		var i = W(t), a = W(i);
		r(a, () => f(y), () => !0, () => !1), B(i);
		var s = x(i, 2), c = (e) => {
			var t = Ge(), n = W(t);
			r(n, () => f(b), () => !1, () => !0), B(t), H(e, t);
		};
		O(s, (e) => {
			f(b) && e(c);
		}), B(t), D(t, (e) => o(m, e), () => f(m)), d(() => n = P(t, 1, "pages svelte-1nlxyec", null, n, { row: Z.value && Q.value })), H(e, t);
	}, se = (e) => {
		var t = qe();
		H(e, t);
	};
	O(ae, (e) => {
		f(y) ? e(oe) : e(se, -1);
	}), L(re, () => Z.value, (e) => Z.value = e), L(F, () => ve.value, (e) => ve.value = e), H(e, E), C();
}
//#endregion
//#region frontend/PhraseList.svelte
var Xe = i("<button type=\"button\" class=\"phrase svelte-8xxexk\"> </button>"), Ze = i("<div class=\"phrase-list svelte-8xxexk\"></div>");
function Qe(e, t) {
	T(t, !0);
	var r = y(), i = n(r), a = (e) => {
		var n = Ze();
		V(n, 21, () => t.phrases, U, (e, n) => {
			var r = Xe(), i = W(r, !0);
			B(r), d(() => v(i, f(n).label)), N("click", r, () => t.onSelectPhrase(f(n))), N("keydown", r, (e) => {
				(e.key === "Enter" || e.key === " ") && (e.preventDefault(), t.onSelectPhrase(f(n)));
			}), H(e, r);
		}), B(n), H(e, n);
	};
	O(i, (e) => {
		t.phrases.length && e(a);
	}), H(e, r), C();
}
m(["click", "keydown"]);
//#endregion
//#region frontend/LyricsPanel.svelte
var $e = i("<span> </span>"), et = i("<p class=\"sentence next svelte-4o08vh\"></p>"), tt = i("<p class=\"sentence current svelte-4o08vh\"></p> <!>", 1), nt = i("<span class=\"word next svelte-4o08vh\"> </span>"), rt = i("<span class=\"row-gap svelte-4o08vh\"></span> <!>", 1), it = i("<div class=\"word-row svelte-4o08vh\"><!> <!></div>"), at = i("<div><label class=\"style-toggle svelte-4o08vh\"><input type=\"checkbox\" class=\"svelte-4o08vh\"/> Sentence style</label> <label class=\"style-toggle svelte-4o08vh\"><input type=\"checkbox\" class=\"svelte-4o08vh\"/> Larger</label> <!></div>"), ot = i("<p class=\"lyrics-empty svelte-4o08vh\">No lyrics to show yet.</p>");
function st(e, t) {
	T(t, !0);
	let r = R(() => t.notes.filter((e) => e.layer === "Melody" && e.word)), i = R(() => t.phrases.length ? t.phrases : f(r).length ? [{
		start: 0,
		end: f(r).reduce((e, t) => Math.max(e, t.start + t.length), 0),
		label: "Whole part"
	}] : []), a = R(() => {
		if (!f(i).length) return -1;
		let e = f(i).findIndex((e) => t.playhead < e.end);
		return e === -1 ? f(i).length - 1 : e;
	}), o = R(() => f(a) >= 0 ? f(i)[f(a)] : null), s = R(() => f(a) >= 0 && f(a) + 1 < f(i).length ? f(i)[f(a) + 1] : null);
	function c(e) {
		return e ? f(r).filter((t) => t.start >= e.start && t.start < e.end) : [];
	}
	let l = R(() => c(f(o))), u = R(() => c(f(s))), p = R(() => {
		let e = null;
		for (let n of f(l)) if (n.start <= t.playhead) e = n;
		else break;
		return e;
	});
	function m(e) {
		return e?.endsWith("-") ? "" : " ";
	}
	var h = y(), g = n(h), _ = (e) => {
		var r = at();
		let i;
		var a = W(r), o = W(a);
		k(o), A(), B(a);
		var s = x(a, 2), c = W(s);
		k(c), A(), B(s);
		var h = x(s, 2), g = (e) => {
			var r = tt(), i = n(r);
			V(i, 21, () => f(l), U, (e, n) => {
				var r = $e();
				let i;
				var a = W(r);
				B(r), d((e) => {
					i = P(r, 1, "sentence-word svelte-4o08vh", null, i, { sung: f(n).start <= t.playhead }), v(a, `${f(n).word ?? ""}${e ?? ""}`);
				}, [() => m(f(n).word)]), H(e, r);
			}), B(i);
			var a = x(i, 2), o = (e) => {
				var t = et();
				V(t, 21, () => f(u), U, (e, t) => {
					var n = $e(), r = W(n);
					B(n), d((e) => v(r, `${f(t).word ?? ""}${e ?? ""}`), [() => m(f(t).word)]), H(e, n);
				}), B(t), H(e, t);
			};
			O(a, (e) => {
				f(u).length && e(o);
			}), H(e, r);
		}, _ = (e) => {
			var t = it(), r = W(t);
			V(r, 17, () => f(l), U, (e, t) => {
				var n = $e();
				let r;
				var i = W(n, !0);
				B(n), d(() => {
					r = P(n, 1, "word svelte-4o08vh", null, r, { active: f(t) === f(p) }), v(i, f(t).word);
				}), H(e, n);
			});
			var i = x(r, 2), a = (e) => {
				var t = rt(), r = x(n(t), 2);
				V(r, 17, () => f(u), U, (e, t) => {
					var n = nt(), r = W(n, !0);
					B(n), d(() => v(r, f(t).word)), H(e, n);
				}), H(e, t);
			};
			O(i, (e) => {
				f(u).length && e(a);
			}), B(t), H(e, t);
		};
		O(h, (e) => {
			_e.value ? e(g) : e(_, -1);
		}), B(r), d(() => i = P(r, 1, "lyrics-panel svelte-4o08vh", null, i, { large: ye.value })), L(o, () => _e.value, (e) => _e.value = e), L(c, () => ye.value, (e) => ye.value = e), H(e, r);
	}, b = (e) => {
		var t = ot();
		H(e, t);
	};
	O(g, (e) => {
		f(o) ? e(_) : e(b, -1);
	}), H(e, h), C();
}
//#endregion
//#region frontend/InstrumentPanel.svelte
var ct = i("<label class=\"instrument-toggle svelte-o1xgsa\"><input type=\"checkbox\" class=\"svelte-o1xgsa\"/> </label>"), lt = i("<p class=\"instrument-empty svelte-o1xgsa\">Choose an instrument to see it.</p>"), ut = i("<div class=\"layer scale-layer svelte-o1xgsa\"></div>"), dt = i("<div></div>"), ft = i("<p class=\"instrument-empty svelte-o1xgsa\">No layer selected.</p>"), pt = i("<p class=\"instrument-empty svelte-o1xgsa\"> </p>"), mt = i("<div class=\"instrument-card svelte-o1xgsa\"><h4 class=\"svelte-o1xgsa\"> </h4> <div class=\"diagram-stack svelte-o1xgsa\"><!> <!> <!></div></div>"), ht = i("<div class=\"instrument-grid svelte-o1xgsa\"></div>"), gt = i("<div class=\"instrument-toggles svelte-o1xgsa\"><!> <span class=\"layer-gap svelte-o1xgsa\"></span> <label class=\"instrument-toggle svelte-o1xgsa\"><input type=\"checkbox\" class=\"svelte-o1xgsa\"/> Scale</label> <label class=\"instrument-toggle svelte-o1xgsa\"><input type=\"checkbox\" class=\"svelte-o1xgsa\"/> Chord</label></div> <!>", 1);
function _t(e, t) {
	T(t, !0);
	let r = R(() => t.timeline.find((e) => t.playhead >= e.start && t.playhead < e.end)), i = R(() => Object.keys(be).filter((e) => be[e]));
	var a = gt(), o = n(a), s = W(o);
	V(s, 17, () => Object.keys(be), U, (e, t) => {
		var n = ct(), r = W(n);
		k(r);
		var i = x(r);
		B(n), d(() => v(i, ` ${f(t) ?? ""}`)), L(r, () => be[f(t)], (e) => be[f(t)] = e), H(e, n);
	});
	var c = x(s, 4), l = W(c);
	k(l), A(), B(c);
	var u = x(c, 2), p = W(u);
	k(p), A(), B(u), B(o);
	var m = x(o, 2), h = (e) => {
		var t = lt();
		H(e, t);
	}, g = (e) => {
		var n = ht();
		V(n, 21, () => f(i), U, (e, n) => {
			let i = R(() => t.diagrams.scale?.[f(n)]), a = R(() => f(r) ? t.diagrams.chords?.[f(n)]?.[f(r).name] : void 0);
			var o = mt(), s = W(o), c = W(s, !0);
			B(s);
			var l = x(s, 2), u = W(l), p = (e) => {
				var t = ut();
				E(t, () => f(i), !0), B(t), H(e, t);
			};
			O(u, (e) => {
				$.scale && f(i) && e(p);
			});
			var m = x(u, 2), h = (e) => {
				var t = dt();
				let n;
				E(t, () => f(a), !0), B(t), d(() => n = P(t, 1, "layer chord-layer svelte-o1xgsa", null, n, { stacked: $.scale && f(i) })), H(e, t);
			};
			O(m, (e) => {
				$.chord && f(a) && e(h);
			});
			var g = x(m, 2), _ = (e) => {
				var t = ft();
				H(e, t);
			}, y = (e) => {
				var t = pt(), n = W(t, !0);
				B(t), d(() => v(n, f(r) ? "No chord picture for this bar." : "Nothing playing yet.")), H(e, t);
			};
			O(g, (e) => {
				!$.scale && !$.chord ? e(_) : $.chord && !f(a) && e(y, 1);
			}), B(l), B(o), d(() => v(c, f(n))), H(e, o);
		}), B(n), H(e, n);
	};
	O(m, (e) => {
		f(i).length ? e(g, -1) : e(h);
	}), L(l, () => $.scale, (e) => $.scale = e), L(p, () => $.chord, (e) => $.chord = e), H(e, a), C();
}
//#endregion
//#region frontend/Index.svelte
var vt = /* @__PURE__ */ new Set([
	"$$slots",
	"$$events",
	"$$legacy"
]), yt = i("<!> <!>", 1), bt = i("<div class=\"mixer svelte-r41nsf\"><!> <!> <!> <!> <!> <!> <!></div>");
function xt(e, t) {
	T(t, !0);
	let r = new fe(oe(t, vt)), i = R(() => r.props.value?.layers ?? []), a = R(() => r.props.value?.timeline ?? []), c = R(() => r.props.value?.notes ?? []), l = R(() => r.props.value?.phrases ?? []), d = R(() => r.props.value?.diagrams ?? {
		scale: {},
		chords: {}
	});
	J.noteLayers(f(i)), _(() => {
		for (let e of f(i)) e.name in J.levels || (J.levels[e.name] = e.level);
	}), r.props.value?.loop_start != null && J.loopFrom === null && (J.loopFrom = r.props.value.loop_start, J.loopTo = r.props.value.loop_end ?? null);
	let p = u(s(J.position())), m = null;
	function h() {
		o(p, J.position(), !0), m = requestAnimationFrame(h);
	}
	h(), z(() => {
		m !== null && cancelAnimationFrame(m);
	});
	let g = u(!0);
	function v() {
		r.props.value && (r.props.value.loop_start = J.loopFrom, r.props.value.loop_end = J.loopTo), r.dispatch("change");
	}
	function y(e, t) {
		let n = J.playing, r = J.select(e, t.shiftKey);
		o(p, J.position(), !0), r && v(), n && J.play(f(i));
	}
	function b(e) {
		let t = J.playing, n = J.selectRange(e.start, e.end);
		o(p, J.position(), !0), n && v(), t && J.play(f(i));
	}
	function S() {
		J.clearLoop(), o(p, 0), v();
	}
	function w() {
		J.playing && J.play(f(i), J.position());
	}
	function E(e) {
		J.setLevel(e, J.levels[e]), r.dispatch("input");
	}
	ge(e, {
		get visible() {
			return r.shared.visible;
		},
		get elem_id() {
			return r.shared.elem_id;
		},
		get elem_classes() {
			return r.shared.elem_classes;
		},
		get scale() {
			return r.shared.scale;
		},
		get min_width() {
			return r.shared.min_width;
		},
		allow_overflow: !0,
		padding: !0,
		children: (e, t) => {
			var r = bt(), s = W(r);
			{
				let e = R(() => f(a).length > 0);
				we(s, {
					get layers() {
						return f(i);
					},
					get playhead() {
						return f(p);
					},
					get hasTimeline() {
						return f(e);
					},
					onClearSelection: S,
					onToggleRepeat: w,
					get follow() {
						return f(g);
					},
					set follow(e) {
						o(g, e, !0);
					}
				});
			}
			var u = x(s, 2);
			{
				let e = R(() => f(a).length > 0), t = R(() => f(c).length > 0), n = R(() => Object.keys(f(d).scale ?? {}).length > 0);
				ke(u, {
					get hasTimeline() {
						return f(e);
					},
					get hasNotes() {
						return f(t);
					},
					get hasDiagrams() {
						return f(n);
					}
				});
			}
			var m = x(u, 2), h = (e) => {
				Me(e, {
					get timeline() {
						return f(a);
					},
					get playhead() {
						return f(p);
					},
					get follow() {
						return f(g);
					},
					onSelectBar: y
				});
			};
			O(m, (e) => {
				Y.strip && e(h);
			});
			var _ = x(m, 2), v = (e) => {
				var t = yt(), r = n(t);
				Qe(r, {
					get phrases() {
						return f(l);
					},
					onSelectPhrase: b
				}), Ye(x(r, 2), {
					get notes() {
						return f(c);
					},
					get timeline() {
						return f(a);
					},
					get phrases() {
						return f(l);
					},
					get playhead() {
						return f(p);
					}
				}), H(e, t);
			};
			O(_, (e) => {
				Y.notes && e(v);
			});
			var C = x(_, 2), T = (e) => {
				st(e, {
					get notes() {
						return f(c);
					},
					get phrases() {
						return f(l);
					},
					get playhead() {
						return f(p);
					}
				});
			};
			O(C, (e) => {
				Y.lyrics && e(T);
			});
			var D = x(C, 2), ee = (e) => {
				Fe(e, {
					get layers() {
						return f(i);
					},
					onLevelChanged: E
				});
			};
			O(D, (e) => {
				Y.faders && e(ee);
			});
			var k = x(D, 2), A = (e) => {
				_t(e, {
					get diagrams() {
						return f(d);
					},
					get timeline() {
						return f(a);
					},
					get playhead() {
						return f(p);
					}
				});
			};
			O(k, (e) => {
				Y.instruments && e(A);
			}), B(r), H(e, r);
		},
		$$slots: { default: !0 }
	}), C();
}
//#endregion
export { xt as default };

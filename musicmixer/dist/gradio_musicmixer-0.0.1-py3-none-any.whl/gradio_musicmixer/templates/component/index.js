import { $ as e, A as t, B as n, C as r, D as i, E as a, F as o, G as s, H as c, I as l, J as u, K as d, L as f, M as p, N as m, O as h, P as g, Q as _, R as v, T as y, U as b, V as x, W as S, X as C, Y as w, Z as T, _ as E, a as D, c as O, d as k, et as A, f as j, g as ee, h as M, i as te, j as N, k as ne, l as re, m as P, n as F, o as I, p as ie, q as L, r as ae, s as oe, t as R, tt as z, u as se, v as B, w as ce, x as V, y as H, z as U } from "./index-client-DKjFtQav.js";
//#region frontend/node_modules/@gradio/theme/dist/src/colors.js
var le = [
	{
		color: "red",
		primary: 600,
		secondary: 100
	},
	{
		color: "green",
		primary: 600,
		secondary: 100
	},
	{
		color: "blue",
		primary: 600,
		secondary: 100
	},
	{
		color: "yellow",
		primary: 500,
		secondary: 100
	},
	{
		color: "purple",
		primary: 600,
		secondary: 100
	},
	{
		color: "teal",
		primary: 600,
		secondary: 100
	},
	{
		color: "orange",
		primary: 600,
		secondary: 100
	},
	{
		color: "cyan",
		primary: 600,
		secondary: 100
	},
	{
		color: "lime",
		primary: 500,
		secondary: 100
	},
	{
		color: "pink",
		primary: 600,
		secondary: 100
	}
], W = {
	inherit: "inherit",
	current: "currentColor",
	transparent: "transparent",
	black: "#000",
	white: "#fff",
	slate: {
		50: "#f8fafc",
		100: "#f1f5f9",
		200: "#e2e8f0",
		300: "#cbd5e1",
		400: "#94a3b8",
		500: "#64748b",
		600: "#475569",
		700: "#334155",
		800: "#1e293b",
		900: "#0f172a",
		950: "#020617"
	},
	gray: {
		50: "#f9fafb",
		100: "#f3f4f6",
		200: "#e5e7eb",
		300: "#d1d5db",
		400: "#9ca3af",
		500: "#6b7280",
		600: "#4b5563",
		700: "#374151",
		800: "#1f2937",
		900: "#111827",
		950: "#030712"
	},
	zinc: {
		50: "#fafafa",
		100: "#f4f4f5",
		200: "#e4e4e7",
		300: "#d4d4d8",
		400: "#a1a1aa",
		500: "#71717a",
		600: "#52525b",
		700: "#3f3f46",
		800: "#27272a",
		900: "#18181b",
		950: "#09090b"
	},
	neutral: {
		50: "#fafafa",
		100: "#f5f5f5",
		200: "#e5e5e5",
		300: "#d4d4d4",
		400: "#a3a3a3",
		500: "#737373",
		600: "#525252",
		700: "#404040",
		800: "#262626",
		900: "#171717",
		950: "#0a0a0a"
	},
	stone: {
		50: "#fafaf9",
		100: "#f5f5f4",
		200: "#e7e5e4",
		300: "#d6d3d1",
		400: "#a8a29e",
		500: "#78716c",
		600: "#57534e",
		700: "#44403c",
		800: "#292524",
		900: "#1c1917",
		950: "#0c0a09"
	},
	red: {
		50: "#fef2f2",
		100: "#fee2e2",
		200: "#fecaca",
		300: "#fca5a5",
		400: "#f87171",
		500: "#ef4444",
		600: "#dc2626",
		700: "#b91c1c",
		800: "#991b1b",
		900: "#7f1d1d",
		950: "#450a0a"
	},
	orange: {
		50: "#fff7ed",
		100: "#ffedd5",
		200: "#fed7aa",
		300: "#fdba74",
		400: "#fb923c",
		500: "#f97316",
		600: "#ea580c",
		700: "#c2410c",
		800: "#9a3412",
		900: "#7c2d12",
		950: "#431407"
	},
	amber: {
		50: "#fffbeb",
		100: "#fef3c7",
		200: "#fde68a",
		300: "#fcd34d",
		400: "#fbbf24",
		500: "#f59e0b",
		600: "#d97706",
		700: "#b45309",
		800: "#92400e",
		900: "#78350f",
		950: "#451a03"
	},
	yellow: {
		50: "#fefce8",
		100: "#fef9c3",
		200: "#fef08a",
		300: "#fde047",
		400: "#facc15",
		500: "#eab308",
		600: "#ca8a04",
		700: "#a16207",
		800: "#854d0e",
		900: "#713f12",
		950: "#422006"
	},
	lime: {
		50: "#f7fee7",
		100: "#ecfccb",
		200: "#d9f99d",
		300: "#bef264",
		400: "#a3e635",
		500: "#84cc16",
		600: "#65a30d",
		700: "#4d7c0f",
		800: "#3f6212",
		900: "#365314",
		950: "#1a2e05"
	},
	green: {
		50: "#f0fdf4",
		100: "#dcfce7",
		200: "#bbf7d0",
		300: "#86efac",
		400: "#4ade80",
		500: "#22c55e",
		600: "#16a34a",
		700: "#15803d",
		800: "#166534",
		900: "#14532d",
		950: "#052e16"
	},
	emerald: {
		50: "#ecfdf5",
		100: "#d1fae5",
		200: "#a7f3d0",
		300: "#6ee7b7",
		400: "#34d399",
		500: "#10b981",
		600: "#059669",
		700: "#047857",
		800: "#065f46",
		900: "#064e3b",
		950: "#022c22"
	},
	teal: {
		50: "#f0fdfa",
		100: "#ccfbf1",
		200: "#99f6e4",
		300: "#5eead4",
		400: "#2dd4bf",
		500: "#14b8a6",
		600: "#0d9488",
		700: "#0f766e",
		800: "#115e59",
		900: "#134e4a",
		950: "#042f2e"
	},
	cyan: {
		50: "#ecfeff",
		100: "#cffafe",
		200: "#a5f3fc",
		300: "#67e8f9",
		400: "#22d3ee",
		500: "#06b6d4",
		600: "#0891b2",
		700: "#0e7490",
		800: "#155e75",
		900: "#164e63",
		950: "#083344"
	},
	sky: {
		50: "#f0f9ff",
		100: "#e0f2fe",
		200: "#bae6fd",
		300: "#7dd3fc",
		400: "#38bdf8",
		500: "#0ea5e9",
		600: "#0284c7",
		700: "#0369a1",
		800: "#075985",
		900: "#0c4a6e",
		950: "#082f49"
	},
	blue: {
		50: "#eff6ff",
		100: "#dbeafe",
		200: "#bfdbfe",
		300: "#93c5fd",
		400: "#60a5fa",
		500: "#3b82f6",
		600: "#2563eb",
		700: "#1d4ed8",
		800: "#1e40af",
		900: "#1e3a8a",
		950: "#172554"
	},
	indigo: {
		50: "#eef2ff",
		100: "#e0e7ff",
		200: "#c7d2fe",
		300: "#a5b4fc",
		400: "#818cf8",
		500: "#6366f1",
		600: "#4f46e5",
		700: "#4338ca",
		800: "#3730a3",
		900: "#312e81",
		950: "#1e1b4b"
	},
	violet: {
		50: "#f5f3ff",
		100: "#ede9fe",
		200: "#ddd6fe",
		300: "#c4b5fd",
		400: "#a78bfa",
		500: "#8b5cf6",
		600: "#7c3aed",
		700: "#6d28d9",
		800: "#5b21b6",
		900: "#4c1d95",
		950: "#2e1065"
	},
	purple: {
		50: "#faf5ff",
		100: "#f3e8ff",
		200: "#e9d5ff",
		300: "#d8b4fe",
		400: "#c084fc",
		500: "#a855f7",
		600: "#9333ea",
		700: "#7e22ce",
		800: "#6b21a8",
		900: "#581c87",
		950: "#3b0764"
	},
	fuchsia: {
		50: "#fdf4ff",
		100: "#fae8ff",
		200: "#f5d0fe",
		300: "#f0abfc",
		400: "#e879f9",
		500: "#d946ef",
		600: "#c026d3",
		700: "#a21caf",
		800: "#86198f",
		900: "#701a75",
		950: "#4a044e"
	},
	pink: {
		50: "#fdf2f8",
		100: "#fce7f3",
		200: "#fbcfe8",
		300: "#f9a8d4",
		400: "#f472b6",
		500: "#ec4899",
		600: "#db2777",
		700: "#be185d",
		800: "#9d174d",
		900: "#831843",
		950: "#500724"
	},
	rose: {
		50: "#fff1f2",
		100: "#ffe4e6",
		200: "#fecdd3",
		300: "#fda4af",
		400: "#fb7185",
		500: "#f43f5e",
		600: "#e11d48",
		700: "#be123c",
		800: "#9f1239",
		900: "#881337",
		950: "#4c0519"
	}
};
le.reduce((e, { color: t, primary: n, secondary: r }) => ({
	...e,
	[t]: {
		primary: W[t][n],
		secondary: W[t][r]
	}
}), {});
//#endregion
//#region frontend/node_modules/svelte/src/store/index-client.js
function ue(e) {
	let t, n = L((n) => {
		let r = !1, i = e.subscribe((e) => {
			t = e, r && n();
		});
		return r = !0, i;
	});
	function r() {
		return m() ? (n(), t) : u(e);
	}
	return "set" in e ? {
		get current() {
			return r();
		},
		set current(t) {
			e.set(t);
		}
	} : { get current() {
		return r();
	} };
}
var G = [
	"label",
	"info",
	"placeholder",
	"description",
	"title",
	"value"
], K = /* @__PURE__ */ "elem_id.elem_classes.visible.interactive.server_fns.server.id.target.theme_mode.version.root.autoscroll.max_file_size.formatter.client.load_component.scale.min_width.theme.padding.loading_status.label.show_label.validation_error.show_progress.api_prefix.container.attached_events.register_component.unregister_component.dispatcher".split(".");
function q(e) {
	return typeof e == "string" && e.includes("__i18n__");
}
var de = class {
	load_component;
	#e = s(x({}));
	get shared() {
		return N(this.#e);
	}
	set shared(e) {
		S(this.#e, e, !0);
	}
	#t = s(x({}));
	get props() {
		return N(this.#t);
	}
	set props(e) {
		S(this.#t, e, !0);
	}
	#n = s((e) => e);
	get i18n() {
		return N(this.#n);
	}
	set i18n(e) {
		S(this.#n, e, !0);
	}
	i18n_store;
	_i18n_from_store;
	translatable_props = {};
	dispatcher;
	last_update = null;
	shared_props = K;
	mounted = !1;
	old_value;
	register_component;
	unregister_component;
	set_data_callback;
	get_data_callback;
	registered_id = null;
	last_shared_props;
	last_props;
	constructor(e, t) {
		for (let t in e.shared_props) this.shared[t] = e.shared_props[t];
		for (let t in e.props) t !== "i18n_store" && (this.props[t] = e.props[t]);
		if (t) for (let e in t) this.props[e] === void 0 && (this.props[e] = t[e]);
		this.i18n = this.props.i18n ?? ((e) => e), this.i18n_store = e.props.i18n_store, this._i18n_from_store = this.i18n_store ? ue(this.i18n_store) : void 0;
		for (let t of G) this.shared[t] = this._translate_and_store("shared", t, e.shared_props[t]), this.props[t] = this._translate_and_store("props", t, e.props[t]);
		this.load_component = this.shared.load_component, this.register_component = this.shared.register_component || (() => {}), this.unregister_component = this.shared.unregister_component || (() => {}), this.dispatcher = this.shared.dispatcher || (() => {}), this.set_data_callback = this.set_data.bind(this), this.get_data_callback = this.get_data.bind(this), this.register_component(this.shared.id, this.set_data_callback, this.get_data_callback), this.registered_id = this.shared.id, this.last_shared_props = e.shared_props, this.last_props = e.props, f(() => {
			let t = e.shared_props.id;
			if (this.last_shared_props !== e.shared_props) {
				for (let t in e.shared_props) {
					let n = e.shared_props[t];
					n !== void 0 && (this._is_i18n_managed(`shared.${t}`, n) || (this.shared[t] = n));
				}
				this.last_shared_props = e.shared_props;
			}
			if (this.last_props !== e.props) {
				for (let t in e.props) {
					if (t === "i18n_store") continue;
					let n = e.props[t];
					n !== void 0 && (this._is_i18n_managed(`props.${t}`, n) || (this.props[t] = n));
				}
				this.last_props = e.props;
			}
			this.registered_id !== null && this.registered_id !== t && this.unregister_component(this.registered_id, this.set_data_callback), this.register_component(t, this.set_data_callback, this.get_data_callback), this.registered_id = t, p(() => {
				this.shared.id = t;
			});
		}), f(() => () => {
			this.registered_id !== null && this.unregister_component(this.registered_id, this.set_data_callback);
		}), f(() => {
			if (this.i18n_store) return this.i18n_store.subscribe(() => {
				for (let [e, t] of Object.entries(this.translatable_props)) {
					let [n, r] = e.split("."), i = this.i18n(t);
					n === "shared" ? this.shared[r] = i : this.props[r] = i;
				}
			});
		});
	}
	_is_i18n_managed(e, t) {
		let n = this.translatable_props[e];
		return n ? t === n || (delete this.translatable_props[e], !1) : !1;
	}
	_translate_and_store(e, t, n) {
		if (typeof n != "string") return n;
		let r = this.i18n(n);
		return r !== n && (this.translatable_props[`${e}.${t}`] = n), r;
	}
	live_i18n = (e) => (this._i18n_from_store?.current, this.i18n(e));
	dispatch(e, t) {
		this.dispatcher(this.shared.id, e, t);
	}
	async get_data() {
		return T(this.props);
	}
	update(e) {
		this.set_data(e);
	}
	set_data(e) {
		for (let t in e) {
			let n = e[t], r = q(n) ? this._translate_and_store(this.shared_props.includes(t) ? "shared" : "props", t, n) : n;
			if (this.shared_props.includes(t)) {
				let e = t;
				this.shared[e] = r;
				continue;
			}
			this.props[t] = r;
		}
	}
	watch_for_change() {
		f(() => {
			this.mounted ||= (this.old_value = this.props.value, !0), this.old_value != this.props.value && (this.old_value = this.props.value, this.dispatch("change"));
		});
	}
};
//#endregion
//#region frontend/node_modules/svelte/src/internal/flags/legacy.js
_();
//#endregion
//#region frontend/node_modules/@gradio/atoms/dist/src/Block.svelte
var fe = a("<svg class=\"resize-handle svelte-1stq1b1\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 10 10\"><line x1=\"1\" y1=\"9\" x2=\"9\" y2=\"1\" stroke=\"gray\" stroke-width=\"0.5\" class=\"svelte-1stq1b1\"></line><line x1=\"5\" y1=\"9\" x2=\"9\" y2=\"5\" stroke=\"gray\" stroke-width=\"0.5\" class=\"svelte-1stq1b1\"></line></svg>"), pe = y("<!> <!>", 1), me = y("<div class=\"placeholder svelte-1stq1b1\"></div>");
function he(e, i) {
	C(i, !1);
	let a = F(i, "height", 8, void 0), s = F(i, "min_height", 8, void 0), u = F(i, "max_height", 8, void 0), d = F(i, "width", 8, void 0), f = F(i, "elem_id", 8, ""), m = F(i, "elem_classes", 24, () => []), h = F(i, "variant", 8, "solid"), _ = F(i, "border_mode", 8, "base"), v = F(i, "padding", 8, !0), y = F(i, "type", 8, "normal"), x = F(i, "test_id", 8, void 0), T = F(i, "explicit_call", 8, !1), E = F(i, "container", 8, !0), k = F(i, "visible", 8, !0), A = F(i, "allow_overflow", 8, !0), j = F(i, "overflow_behavior", 8, "auto"), P = F(i, "scale", 8, null), I = F(i, "min_width", 8, 0), L = F(i, "flex", 12, !1), ae = F(i, "resizable", 8, !1), oe = F(i, "rtl", 8, !1), R = F(i, "fullscreen", 12, !1), z = F(i, "label", 8, void 0), B = c(R()), V = c(), le = y() === "fieldset" ? "fieldset" : "div", W = c(0), ue = c(0), G = c(null), K = null, q = null;
	function de(e) {
		R() && e.key === "Escape" && R(!1);
	}
	function he() {
		let e = N(V).getRootNode();
		return N(V).closest(".gradio-container") ?? (e instanceof ShadowRoot ? e : document.body);
	}
	function J(e) {
		let t = document.createElement("div");
		t.style.cssText = "position: fixed; top: 0; left: 0; width: 100%; height: 100%; visibility: hidden; pointer-events: none;", e.appendChild(t);
		let n = t.getBoundingClientRect();
		return t.remove(), n;
	}
	function Y(e) {
		let t = N(V).parentNode;
		if (!t || t === e) return !1;
		let n = J(t), r = J(e);
		return Math.abs(n.top - r.top) > 1 || Math.abs(n.left - r.left) > 1 || Math.abs(n.width - r.width) > 1 || Math.abs(n.height - r.height) > 1;
	}
	function X(e) {
		!N(V).parentNode || N(V).parentNode === e || (K = N(V).parentNode, q = document.createComment("fullscreen block"), K.insertBefore(q, N(V)), e.appendChild(N(V)));
	}
	function Z() {
		if (!K) return;
		let e = q && q.parentNode === K ? q : null;
		K.insertBefore(N(V), e), e?.remove(), K = null, q = null;
	}
	let Q = (e) => {
		if (e !== void 0) {
			if (typeof e == "number") return e + "px";
			if (typeof e == "string") return e;
		}
	}, $ = (e) => {
		let t = e.clientY, n = (e) => {
			let n = e.clientY - t;
			t = e.clientY, b(V, N(V).style.height = `${N(V).offsetHeight + n}px`);
		}, r = () => {
			window.removeEventListener("mousemove", n), window.removeEventListener("mouseup", r);
		};
		window.addEventListener("mousemove", n), window.addEventListener("mouseup", r);
	};
	g(() => (t(R()), N(B), N(V)), () => {
		if (R() !== N(B)) {
			if (S(B, R()), R()) {
				S(G, N(V).getBoundingClientRect()), S(W, N(V).offsetHeight), S(ue, N(V).offsetWidth);
				let e = he();
				Y(e) && X(e), window.addEventListener("keydown", de);
			} else Z(), S(G, null), window.removeEventListener("keydown", de);
		}
	}), g(() => t(k()), () => {
		k() || L(!1);
	}), o(), te();
	var ge = ce(), _e = U(ge), ve = (e) => {
		var o = pe(), c = U(o);
		M(c, () => le, !1, (e, o) => {
			D(e, (e) => S(V, e), () => N(V)), se(e, (e, t) => ({
				"data-testid": x(),
				id: f(),
				class: `block ${e ?? ""}`,
				dir: oe() ? "rtl" : "ltr",
				"aria-label": z(),
				style: "",
				[O]: {
					hidden: k() === "hidden",
					padded: v(),
					flex: L(),
					border_focus: _() === "focus",
					border_contrast: _() === "contrast",
					"hide-container": !T() && !E(),
					fullscreen: R(),
					animating: R() && N(G) !== null,
					"auto-margin": P() === null
				},
				[re]: t
			}), [() => (t(m()), p(() => m()?.join(" ") || "")), () => ({
				height: (t(R()), t(a()), p(() => R() ? void 0 : Q(a()))),
				"min-height": (t(R()), t(s()), p(() => R() ? void 0 : Q(s()))),
				"max-height": (t(R()), t(u()), p(() => R() ? void 0 : Q(u()))),
				"--start-top": (N(G), p(() => N(G) ? `${N(G).top}px` : "0px")),
				"--start-left": (N(G), p(() => N(G) ? `${N(G).left}px` : "0px")),
				"--start-width": (N(G), p(() => N(G) ? `${N(G).width}px` : "0px")),
				"--start-height": (N(G), p(() => N(G) ? `${N(G).height}px` : "0px")),
				width: (t(R()), t(d()), p(() => R() ? void 0 : typeof d() == "number" ? `calc(min(${d()}px, 100%))` : Q(d()))),
				"border-style": h(),
				overflow: A() ? j() : "hidden",
				"flex-grow": P(),
				"min-width": `calc(min(${I()}px, 100%))`
			})], void 0, void 0, "svelte-1stq1b1");
			var c = pe(), l = U(c);
			ee(l, i, "default", {}, null);
			var g = n(l, 2), y = (e) => {
				var t = fe();
				ne("mousedown", t, $), r(e, t);
			};
			H(g, (e) => {
				ae() && e(y);
			}), r(o, c);
		});
		var g = n(c, 2), y = (e) => {
			var t = me();
			let n;
			l(() => n = ie(t, "", n, {
				height: N(W) + "px",
				width: N(ue) + "px"
			})), r(e, t);
		};
		H(g, (e) => {
			R() && e(y);
		}), r(e, o);
	};
	H(_e, (e) => {
		(k() === !0 || k() === "hidden") && e(ve);
	}), r(e, ge), w();
}
//#endregion
//#region frontend/node_modules/@gradio/atoms/dist/src/SelectSource.svelte
i(["click"]), i(["click"]);
var J = new class {
	#e;
	get playing() {
		return N(this.#e);
	}
	set playing(e) {
		S(this.#e, e, !0);
	}
	#t;
	get offset() {
		return N(this.#t);
	}
	set offset(e) {
		S(this.#t, e, !0);
	}
	#n;
	get loopFrom() {
		return N(this.#n);
	}
	set loopFrom(e) {
		S(this.#n, e, !0);
	}
	#r;
	get loopTo() {
		return N(this.#r);
	}
	set loopTo(e) {
		S(this.#r, e, !0);
	}
	#i;
	get levels() {
		return N(this.#i);
	}
	set levels(e) {
		S(this.#i, e, !0);
	}
	#a;
	get repeat() {
		return N(this.#a);
	}
	set repeat(e) {
		S(this.#a, e, !0);
	}
	constructor() {
		this.context = null, this.master = null, this.buffers = {}, this.gains = {}, this.sources = [], this.startedAt = 0, this.fingerprint = "", this.selectionFingerprint = "", this.#e = s(!1), this.#t = s(0), this.#n = s(null), this.#r = s(null), this.#i = s(x({})), this.anchor = null, this.#a = s(!0);
	}
	position() {
		if (!this.context || !this.playing) return this.offset;
		let e = this.offset + (this.context.currentTime - this.startedAt);
		if (this.loopFrom !== null && this.loopTo !== null && e > this.loopTo) {
			let t = this.loopTo - this.loopFrom;
			e = this.loopFrom + (e - this.loopFrom) % t;
		}
		return e;
	}
	bytesFrom(e) {
		let t = atob(e), n = new Uint8Array(t.length);
		for (let e = 0; e < t.length; e++) n[e] = t.charCodeAt(e);
		return n.buffer;
	}
	computeFingerprint(e) {
		return e.map((e) => {
			let t = e.wav;
			return e.name + ":" + t.length + ":" + t.slice(0, 24) + ":" + t.slice(-24);
		}).join("|");
	}
	noteLayers(e) {
		let t = this.computeFingerprint(e);
		t !== this.selectionFingerprint && (this.clearLoop(), this.selectionFingerprint = t);
	}
	async ensureAudio(e) {
		if (!this.context) {
			this.context = new (window.AudioContext || window.webkitAudioContext)();
			let e = this.context.createGain();
			e.gain.value = .7;
			let t = this.context.createDynamicsCompressor();
			t.threshold.value = -6, t.knee.value = 0, t.ratio.value = 20, t.attack.value = .003, t.release.value = .15, e.connect(t), t.connect(this.context.destination), this.master = e;
		}
		let t = this.computeFingerprint(e);
		if (this.fingerprint !== t) {
			for (let e of Object.keys(this.gains)) this.gains[e].disconnect();
			this.buffers = {}, this.gains = {};
			for (let t of e) {
				let e = this.context.createGain();
				e.gain.value = this.levels[t.name] ?? t.level, e.connect(this.master), this.gains[t.name] = e, this.buffers[t.name] = await this.context.decodeAudioData(this.bytesFrom(t.wav));
			}
			this.fingerprint = t;
		}
	}
	stopSources() {
		for (let e of this.sources) {
			e.onended = null;
			try {
				e.stop();
			} catch {}
			e.disconnect();
		}
		this.sources = [];
	}
	async play(e, t) {
		let n = t ?? this.offset;
		if (this.stopSources(), this.playing = !1, await this.ensureAudio(e), this.context) {
			this.context.state === "suspended" && await this.context.resume(), this.offset = n, this.startedAt = this.context.currentTime, this.playing = !0;
			for (let t of e) {
				let e = this.context.createBufferSource();
				e.buffer = this.buffers[t.name], this.loopFrom !== null && this.loopTo !== null && this.repeat && (e.loop = !0, e.loopStart = this.loopFrom, e.loopEnd = this.loopTo), e.connect(this.gains[t.name]), e.start(this.startedAt, this.offset), this.loopFrom !== null && this.loopTo !== null && !this.repeat && e.stop(this.startedAt + (this.loopTo - this.offset)), this.sources.push(e);
			}
			this.sources.length && (this.sources[0].onended = () => {
				this.playing = !1;
			});
		}
	}
	stop() {
		this.offset = this.position(), this.stopSources(), this.playing = !1;
	}
	select(e, t) {
		let n = this.loopFrom !== null && this.loopTo !== null, r = this.loopFrom, i = this.loopTo, a = n && e.start >= this.loopFrom - .001 && e.end <= this.loopTo + .001;
		if (t && this.anchor !== null && !n) {
			let t = Math.min(this.anchor.start, e.start), n = Math.max(this.anchor.end, e.end);
			this.loopFrom = t, this.loopTo = Math.max(n, t + .05), this.offset = this.loopFrom;
		} else !t && a ? this.offset = e.start : (this.anchor = e, this.loopFrom = e.start, this.loopTo = null, this.offset = e.start);
		return this.stopSources(), this.playing = !1, this.loopFrom !== r || this.loopTo !== i;
	}
	selectRange(e, t) {
		let n = this.loopFrom, r = this.loopTo;
		return this.anchor = null, this.loopFrom = e, this.loopTo = Math.max(t, e + .05), this.offset = e, this.stopSources(), this.playing = !1, this.loopFrom !== n || this.loopTo !== r;
	}
	clearLoop() {
		this.anchor = null, this.loopFrom = null, this.loopTo = null, this.offset = 0, this.stopSources(), this.playing = !1;
	}
	setLevel(e, t) {
		this.levels[e] = t, this.gains[e] && this.context && this.gains[e].gain.setTargetAtTime(t, this.context.currentTime, .01);
	}
}(), Y = x({
	strip: !0,
	faders: !0,
	notes: !1,
	lyrics: !1
}), X = x({
	Melody: !0,
	"Harmony above": !1,
	"Harmony below": !1,
	Bass: !1
}), Z = x({ value: !1 }), Q = x({ value: !1 }), $ = x({ value: !1 }), ge = y("<label class=\"repeat svelte-d89286\"><input type=\"checkbox\" class=\"svelte-d89286\"/> Repeat</label>"), _e = y("<label class=\"repeat svelte-d89286\"><input type=\"checkbox\" class=\"svelte-d89286\"/> Follow</label>"), ve = y("<div class=\"transport svelte-d89286\"><button class=\"svelte-d89286\">Play</button> <button class=\"svelte-d89286\">Stop</button> <button class=\"svelte-d89286\">Clear selection</button> <!> <span class=\"time svelte-d89286\"> </span> <!></div>");
function ye(t, i) {
	C(i, !0);
	let a = F(i, "follow", 15);
	var o = ve(), s = v(o), c = n(s, 2), u = n(c, 2), d = n(u, 2), f = (t) => {
		var n = ge(), a = v(n);
		k(a), e(), A(n), h("change", a, function(...e) {
			i.onToggleRepeat?.apply(this, e);
		}), I(a, () => J.repeat, (e) => J.repeat = e), r(t, n);
	};
	H(d, (e) => {
		J.loopFrom !== null && J.loopTo !== null && e(f);
	});
	var p = n(d, 2), m = v(p);
	A(p);
	var g = n(p, 2), _ = (t) => {
		var n = _e(), i = v(n);
		k(i), e(), A(n), I(i, a), r(t, n);
	};
	H(g, (e) => {
		i.hasTimeline && e(_);
	}), A(o), l((e) => V(m, `${e ?? ""}s`), [() => i.playhead.toFixed(1)]), h("click", s, () => J.play(i.layers)), h("click", c, () => J.stop()), h("click", u, function(...e) {
		i.onClearSelection?.apply(this, e);
	}), r(t, o), w();
}
i(["click", "change"]);
//#endregion
//#region frontend/PanelToggles.svelte
var be = y("<label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Chart</label>"), xe = y("<label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Notes</label> <label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Lyrics</label>", 1), Se = y("<div class=\"panel-toggles svelte-1mngm7u\"><!> <!> <label class=\"panel-toggle svelte-1mngm7u\"><input type=\"checkbox\" class=\"svelte-1mngm7u\"/> Mixer</label></div>");
function Ce(t, i) {
	C(i, !0);
	var a = Se(), o = v(a), s = (t) => {
		var n = be(), i = v(n);
		k(i), e(), A(n), I(i, () => Y.strip, (e) => Y.strip = e), r(t, n);
	};
	H(o, (e) => {
		i.hasTimeline && e(s);
	});
	var c = n(o, 2), l = (t) => {
		var i = xe(), a = U(i), o = v(a);
		k(o), e(), A(a);
		var s = n(a, 2), c = v(s);
		k(c), e(), A(s), I(o, () => Y.notes, (e) => Y.notes = e), I(c, () => Y.lyrics, (e) => Y.lyrics = e), r(t, i);
	};
	H(c, (e) => {
		i.hasNotes && e(l);
	});
	var u = n(c, 2), d = v(u);
	k(d), e(), A(u), A(a), I(d, () => Y.faders, (e) => Y.faders = e), r(t, a), w();
}
//#endregion
//#region frontend/ChordStrip.svelte
var we = y("<button type=\"button\"><div class=\"number svelte-65z4tz\"> </div> <div class=\"chord svelte-65z4tz\"> </div> <div class=\"words svelte-65z4tz\"> </div></button>"), Te = y("<div class=\"strip svelte-65z4tz\"></div> <p class=\"note svelte-65z4tz\"> </p>", 1);
function Ee(e, t) {
	C(t, !0);
	let i = d(() => t.timeline.find((e) => t.playhead >= e.start && t.playhead < e.end)), a = d(() => J.loopFrom === null ? t.timeline.length ? "Click a bar to select where Play starts. Shift-click a later bar to loop a stretch." : "" : J.loopTo === null ? `Play starts at ${J.loopFrom.toFixed(1)}s. Shift-click a later bar to select a stretch, or press Play.` : J.repeat ? `Repeating ${J.loopFrom.toFixed(1)}s to ${J.loopTo.toFixed(1)}s. Untick Repeat to play it once, or Clear selection to release it.` : `Selected ${J.loopFrom.toFixed(1)}s to ${J.loopTo.toFixed(1)}s, playing once. Tick Repeat to loop it.`), o = {};
	f(() => {
		t.follow && N(i) && o[N(i).bar] && o[N(i).bar].scrollIntoView({
			behavior: "smooth",
			inline: "center",
			block: "nearest"
		});
	});
	var s = ce(), c = U(s), u = (e) => {
		var s = Te(), c = U(s);
		E(c, 21, () => t.timeline, (e) => e.bar, (e, a) => {
			var s = we();
			let c;
			var u = v(s), d = v(u, !0);
			A(u);
			var f = n(u, 2), p = v(f, !0);
			A(f);
			var m = n(f, 2), g = v(m, !0);
			A(m), A(s), D(s, (e, t) => o[t.bar] = e, (e) => o?.[e.bar], () => [N(a)]), l(() => {
				c = P(s, 1, "bar svelte-65z4tz", null, c, {
					playing: N(i) === N(a),
					looped: J.loopFrom !== null && J.loopTo !== null && N(a).start >= J.loopFrom - .001 && N(a).end <= J.loopTo + .001
				}), j(s, "data-bar", N(a).bar), V(d, N(a).bar), V(p, N(a).name), V(g, N(a).words);
			}), h("click", s, (e) => t.onSelectBar(N(a), e)), h("keydown", s, (e) => {
				(e.key === "Enter" || e.key === " ") && (e.preventDefault(), t.onSelectBar(N(a), e));
			}), r(e, s);
		}), A(c);
		var u = n(c, 2), d = v(u, !0);
		A(u), l(() => V(d, N(a))), r(e, s);
	};
	H(c, (e) => {
		t.timeline.length && e(u);
	}), r(e, s), w();
}
i(["click", "keydown"]);
//#endregion
//#region frontend/FaderPanel.svelte
var De = y("<div class=\"fader-row svelte-ma6git\"><span class=\"name svelte-ma6git\"> </span> <button class=\"mute svelte-ma6git\">M</button> <input type=\"range\" min=\"0\" max=\"1\" step=\"0.05\" class=\"svelte-ma6git\"/> <span class=\"value svelte-ma6git\"> </span></div>"), Oe = y("<div class=\"faders\"></div>");
function ke(e, t) {
	C(t, !0);
	function i(e, n) {
		J.levels[e] = J.levels[e] > 0 ? 0 : n, t.onLevelChanged(e);
	}
	var a = Oe();
	E(a, 21, () => t.layers, (e) => e.name, (e, a) => {
		var o = De(), s = v(o), c = v(s, !0);
		A(s);
		var u = n(s, 2), d = n(u, 2);
		k(d);
		var f = n(d, 2), p = v(f);
		A(f), A(o), l((e) => {
			ie(s, `color:${N(a).colour ?? ""}`), V(c, N(a).name), V(p, `${e ?? ""}%`);
		}, [() => Math.round((J.levels[N(a).name] ?? 0) * 100)]), h("click", u, () => i(N(a).name, N(a).level)), h("input", d, () => t.onLevelChanged(N(a).name)), oe(d, () => J.levels[N(a).name], (e) => J.levels[N(a).name] = e), r(e, o);
	}), A(a), r(e, a), w();
}
i(["click", "input"]);
//#endregion
//#region frontend/NotesPanel.svelte
var Ae = a("<rect class=\"loop-region svelte-1nlxyec\" y=\"0\"></rect>"), je = a("<line class=\"bar-line svelte-1nlxyec\" y1=\"0\"></line>"), Me = a("<text class=\"note-label svelte-1nlxyec\"> </text>"), Ne = a("<text class=\"note-word svelte-1nlxyec\"> </text>"), Pe = a("<g><rect class=\"note-box svelte-1nlxyec\"></rect><!><!></g>"), Fe = a("<line class=\"playhead svelte-1nlxyec\" y1=\"0\"></line>"), Ie = a("<svg><!><!><!><!></svg>"), Le = y("<label class=\"layer-toggle svelte-1nlxyec\"><input type=\"checkbox\" class=\"svelte-1nlxyec\"/> </label>"), Re = y("<label class=\"layer-toggle svelte-1nlxyec\"><input type=\"checkbox\" class=\"svelte-1nlxyec\"/> Side by side</label>"), ze = y("<div class=\"notes-container next-page svelte-1nlxyec\"><!></div>"), Be = y("<div><div class=\"notes-container svelte-1nlxyec\"><!></div> <!></div>"), Ve = y("<p class=\"note-empty svelte-1nlxyec\">No layers selected to show.</p>"), He = y("<div class=\"notes-toggles svelte-1nlxyec\"><!> <label class=\"layer-toggle preview-toggle svelte-1nlxyec\"><input type=\"checkbox\" class=\"svelte-1nlxyec\"/> Preview next phrase</label> <!></div> <!>", 1);
function Ue(t, i) {
	C(i, !0);
	let a = (e, t = z, a = z, s = z) => {
		var c = Ie();
		let u;
		var d = v(c), f = (e) => {
			var n = Ae();
			l((e, r) => {
				j(n, "x", e), j(n, "width", r), j(n, "height", t().height);
			}, [() => O(t(), Math.max(J.loopFrom, t().phrase.start)), () => Math.max(0, O(t(), Math.min(J.loopTo, t().phrase.end)) - O(t(), Math.max(J.loopFrom, t().phrase.start)))]), r(e, n);
		};
		H(d, (e) => {
			a() && J.loopFrom !== null && J.loopTo !== null && e(f);
		});
		var p = n(d);
		E(p, 17, () => t().bars, B, (e, n) => {
			var i = je();
			l((e, n) => {
				j(i, "x1", e), j(i, "x2", n), j(i, "y2", t().height);
			}, [() => O(t(), N(n).start), () => O(t(), N(n).start)]), r(e, i);
		});
		var m = n(p);
		E(m, 17, () => t().notes, B, (e, i) => {
			var a = Pe(), s = v(a);
			j(s, "height", o - 2);
			var c = n(s), u = (e) => {
				var n = Me(), a = v(n, !0);
				A(n), l((e, t, r) => {
					j(n, "x", e), j(n, "y", t), j(n, "fill", N(i).colour), V(a, r);
				}, [
					() => O(t(), N(i).start) + N(i).length * t().pxPerSecond / 2,
					() => T(t(), N(i).midi) + o / 2,
					() => h(N(i).midi)
				]), r(e, n);
			};
			H(c, (e) => {
				N(i).length * t().pxPerSecond > 20 && e(u);
			});
			var d = n(c), f = (e) => {
				var n = Ne(), a = v(n, !0);
				A(n), l((e, t) => {
					j(n, "x", e), j(n, "y", t), V(a, N(i).word);
				}, [() => O(t(), N(i).start) + N(i).length * t().pxPerSecond / 2, () => T(t(), N(i).midi) + o + 10]), r(e, n);
			};
			H(d, (e) => {
				N(i).word && e(f);
			}), A(a), l((e, t, n) => {
				j(s, "x", e), j(s, "y", t), j(s, "width", n), j(s, "fill", N(i).colour), j(s, "fill-opacity", N(i).layer === "Melody" ? .22 : .14), j(s, "stroke", N(i).colour);
			}, [
				() => O(t(), N(i).start),
				() => T(t(), N(i).midi) + 1,
				() => Math.max(N(i).length * t().pxPerSecond - 1, 2)
			]), r(e, a);
		});
		var g = n(m), _ = (e) => {
			var n = Fe();
			l((e, r) => {
				j(n, "x1", e), j(n, "x2", r), j(n, "y2", t().height);
			}, [() => O(t(), i.playhead), () => O(t(), i.playhead)]), r(e, n);
		};
		H(g, (e) => {
			a() && e(_);
		}), A(c), l(() => {
			j(c, "width", t().width), j(c, "height", t().height), j(c, "viewBox", `0 0 ${t().width ?? ""} ${t().height ?? ""}`), u = P(c, 0, "svelte-1nlxyec", null, u, { dimmed: s() });
		}), r(e, c);
	}, o = 14, c = d(() => i.phrases.length ? i.phrases : i.notes.length ? [{
		start: 0,
		end: i.notes.reduce((e, t) => Math.max(e, t.start + t.length), 0),
		label: "1. Whole part"
	}] : []), u = d(() => {
		if (!N(c).length) return -1;
		let e = N(c).findIndex((e) => i.playhead < e.end);
		return e === -1 ? N(c).length - 1 : e;
	}), p = d(() => N(u) >= 0 ? N(c)[N(u)] : null), m = d(() => N(u) >= 0 && N(u) + 1 < N(c).length ? N(c)[N(u) + 1] : null);
	function h(e) {
		return [
			"C",
			"C#",
			"D",
			"D#",
			"E",
			"F",
			"F#",
			"G",
			"G#",
			"A",
			"A#",
			"B"
		][e % 12] + Math.floor(e / 12 - 1);
	}
	let g = s(null), _ = s(600);
	f(() => {
		N(g) && S(_, N(g).clientWidth || N(_), !0);
	});
	function y(e, t) {
		if (!e) return null;
		let n = i.timeline.filter((t) => t.start < e.end && t.end > e.start), r = i.notes.filter((t) => X[t.layer] && t.start >= e.start && t.start < e.end), a = 60, o = 72;
		if (r.length) {
			a = r[0].midi, o = r[0].midi;
			for (let e of r) e.midi < a && (a = e.midi), e.midi > o && (o = e.midi);
			--a, o += 1;
		}
		let s = (o - a + 1) * 14, c = e.end - e.start, l = c > 0 ? t / c : 60;
		return {
			phrase: e,
			bars: n,
			notes: r,
			pitchRange: {
				lowest: a,
				highest: o
			},
			width: t,
			height: s,
			pxPerSecond: l
		};
	}
	let b = d(() => {
		let e = Z.value && Q.value ? (N(_) - 8) / 2 : N(_);
		return y(N(p), e);
	}), x = d(() => {
		if (!Z.value) return null;
		let e = Q.value ? (N(_) - 8) / 2 : N(_);
		return y(N(m), e);
	});
	function T(e, t) {
		return (e.pitchRange.highest - t) * 14;
	}
	function O(e, t) {
		return (t - e.phrase.start) * e.pxPerSecond;
	}
	var ee = He(), M = U(ee), te = v(M);
	E(te, 17, () => Object.keys(X), B, (e, t) => {
		var i = Le(), a = v(i);
		k(a);
		var o = n(a);
		A(i), l(() => V(o, ` ${N(t) ?? ""}`)), I(a, () => X[N(t)], (e) => X[N(t)] = e), r(e, i);
	});
	var ne = n(te, 2), re = v(ne);
	k(re), e(), A(ne);
	var F = n(ne, 2), ie = (t) => {
		var n = Re(), i = v(n);
		k(i), e(), A(n), I(i, () => Q.value, (e) => Q.value = e), r(t, n);
	};
	H(F, (e) => {
		Z.value && e(ie);
	}), A(M);
	var L = n(M, 2), ae = (e) => {
		var t = Be();
		let i;
		var o = v(t), s = v(o);
		a(s, () => N(b), () => !0, () => !1), A(o);
		var c = n(o, 2), u = (e) => {
			var t = ze(), n = v(t);
			a(n, () => N(x), () => !1, () => !0), A(t), r(e, t);
		};
		H(c, (e) => {
			N(x) && e(u);
		}), A(t), D(t, (e) => S(g, e), () => N(g)), l(() => i = P(t, 1, "pages svelte-1nlxyec", null, i, { row: Z.value && Q.value })), r(e, t);
	}, oe = (e) => {
		var t = Ve();
		r(e, t);
	};
	H(L, (e) => {
		N(b) ? e(ae) : e(oe, -1);
	}), I(re, () => Z.value, (e) => Z.value = e), r(t, ee), w();
}
//#endregion
//#region frontend/PhraseList.svelte
var We = y("<button type=\"button\" class=\"phrase svelte-8xxexk\"> </button>"), Ge = y("<div class=\"phrase-list svelte-8xxexk\"></div>");
function Ke(e, t) {
	C(t, !0);
	var n = ce(), i = U(n), a = (e) => {
		var n = Ge();
		E(n, 21, () => t.phrases, B, (e, n) => {
			var i = We(), a = v(i, !0);
			A(i), l(() => V(a, N(n).label)), h("click", i, () => t.onSelectPhrase(N(n))), h("keydown", i, (e) => {
				(e.key === "Enter" || e.key === " ") && (e.preventDefault(), t.onSelectPhrase(N(n)));
			}), r(e, i);
		}), A(n), r(e, n);
	};
	H(i, (e) => {
		t.phrases.length && e(a);
	}), r(e, n), w();
}
i(["click", "keydown"]);
//#endregion
//#region frontend/LyricsPanel.svelte
var qe = y("<span> </span>"), Je = y("<p class=\"sentence next svelte-4o08vh\"></p>"), Ye = y("<p class=\"sentence current svelte-4o08vh\"></p> <!>", 1), Xe = y("<span class=\"word next svelte-4o08vh\"> </span>"), Ze = y("<span class=\"row-gap svelte-4o08vh\"></span> <!>", 1), Qe = y("<div class=\"word-row svelte-4o08vh\"><!> <!></div>"), $e = y("<div class=\"lyrics-panel svelte-4o08vh\"><label class=\"style-toggle svelte-4o08vh\"><input type=\"checkbox\" class=\"svelte-4o08vh\"/> Sentence style</label> <!></div>"), et = y("<p class=\"lyrics-empty svelte-4o08vh\">No lyrics to show yet.</p>");
function tt(t, i) {
	C(i, !0);
	let a = d(() => i.notes.filter((e) => e.layer === "Melody" && e.word)), o = d(() => i.phrases.length ? i.phrases : N(a).length ? [{
		start: 0,
		end: N(a).reduce((e, t) => Math.max(e, t.start + t.length), 0),
		label: "Whole part"
	}] : []), s = d(() => {
		if (!N(o).length) return -1;
		let e = N(o).findIndex((e) => i.playhead < e.end);
		return e === -1 ? N(o).length - 1 : e;
	}), c = d(() => N(s) >= 0 ? N(o)[N(s)] : null), u = d(() => N(s) >= 0 && N(s) + 1 < N(o).length ? N(o)[N(s) + 1] : null);
	function f(e) {
		return e ? N(a).filter((t) => t.start >= e.start && t.start < e.end) : [];
	}
	let p = d(() => f(N(c))), m = d(() => f(N(u))), h = d(() => {
		let e = null;
		for (let t of N(p)) if (t.start <= i.playhead) e = t;
		else break;
		return e;
	});
	function g(e) {
		return e?.endsWith("-") ? "" : " ";
	}
	var _ = ce(), y = U(_), b = (t) => {
		var a = $e(), o = v(a), s = v(o);
		k(s), e(), A(o);
		var c = n(o, 2), u = (e) => {
			var t = Ye(), a = U(t);
			E(a, 21, () => N(p), B, (e, t) => {
				var n = qe();
				let a;
				var o = v(n);
				A(n), l((e) => {
					a = P(n, 1, "sentence-word svelte-4o08vh", null, a, { sung: N(t).start <= i.playhead }), V(o, `${N(t).word ?? ""}${e ?? ""}`);
				}, [() => g(N(t).word)]), r(e, n);
			}), A(a);
			var o = n(a, 2), s = (e) => {
				var t = Je();
				E(t, 21, () => N(m), B, (e, t) => {
					var n = qe(), i = v(n);
					A(n), l((e) => V(i, `${N(t).word ?? ""}${e ?? ""}`), [() => g(N(t).word)]), r(e, n);
				}), A(t), r(e, t);
			};
			H(o, (e) => {
				N(m).length && e(s);
			}), r(e, t);
		}, d = (e) => {
			var t = Qe(), i = v(t);
			E(i, 17, () => N(p), B, (e, t) => {
				var n = qe();
				let i;
				var a = v(n, !0);
				A(n), l(() => {
					i = P(n, 1, "word svelte-4o08vh", null, i, { active: N(t) === N(h) }), V(a, N(t).word);
				}), r(e, n);
			});
			var a = n(i, 2), o = (e) => {
				var t = Ze(), i = n(U(t), 2);
				E(i, 17, () => N(m), B, (e, t) => {
					var n = Xe(), i = v(n, !0);
					A(n), l(() => V(i, N(t).word)), r(e, n);
				}), r(e, t);
			};
			H(a, (e) => {
				N(m).length && e(o);
			}), A(t), r(e, t);
		};
		H(c, (e) => {
			$.value ? e(u) : e(d, -1);
		}), A(a), I(s, () => $.value, (e) => $.value = e), r(t, a);
	}, x = (e) => {
		var t = et();
		r(e, t);
	};
	H(y, (e) => {
		N(c) ? e(b) : e(x, -1);
	}), r(t, _), w();
}
//#endregion
//#region frontend/Index.svelte
var nt = /* @__PURE__ */ new Set([
	"$$slots",
	"$$events",
	"$$legacy"
]), rt = y("<!> <!>", 1), it = y("<div class=\"mixer svelte-r41nsf\"><!> <!> <!> <!> <!> <!></div>");
function at(e, t) {
	C(t, !0);
	let i = new de(ae(t, nt)), a = d(() => i.props.value?.layers ?? []), o = d(() => i.props.value?.timeline ?? []), c = d(() => i.props.value?.notes ?? []), l = d(() => i.props.value?.phrases ?? []);
	J.noteLayers(N(a)), f(() => {
		for (let e of N(a)) e.name in J.levels || (J.levels[e.name] = e.level);
	}), i.props.value?.loop_start != null && J.loopFrom === null && (J.loopFrom = i.props.value.loop_start, J.loopTo = i.props.value.loop_end ?? null);
	let u = s(x(J.position())), p = null;
	function m() {
		S(u, J.position(), !0), p = requestAnimationFrame(m);
	}
	m(), R(() => {
		p !== null && cancelAnimationFrame(p);
	});
	let h = s(!0);
	function g() {
		i.props.value && (i.props.value.loop_start = J.loopFrom, i.props.value.loop_end = J.loopTo), i.dispatch("change");
	}
	function _(e, t) {
		let n = J.playing, r = J.select(e, t.shiftKey);
		S(u, J.position(), !0), r && g(), n && J.play(N(a));
	}
	function y(e) {
		let t = J.playing, n = J.selectRange(e.start, e.end);
		S(u, J.position(), !0), n && g(), t && J.play(N(a));
	}
	function b() {
		J.clearLoop(), S(u, 0), g();
	}
	function T() {
		J.playing && J.play(N(a), J.position());
	}
	function E(e) {
		J.setLevel(e, J.levels[e]), i.dispatch("input");
	}
	he(e, {
		get visible() {
			return i.shared.visible;
		},
		get elem_id() {
			return i.shared.elem_id;
		},
		get elem_classes() {
			return i.shared.elem_classes;
		},
		get scale() {
			return i.shared.scale;
		},
		get min_width() {
			return i.shared.min_width;
		},
		allow_overflow: !0,
		padding: !0,
		children: (e, t) => {
			var i = it(), s = v(i);
			{
				let e = d(() => N(o).length > 0);
				ye(s, {
					get layers() {
						return N(a);
					},
					get playhead() {
						return N(u);
					},
					get hasTimeline() {
						return N(e);
					},
					onClearSelection: b,
					onToggleRepeat: T,
					get follow() {
						return N(h);
					},
					set follow(e) {
						S(h, e, !0);
					}
				});
			}
			var f = n(s, 2);
			{
				let e = d(() => N(o).length > 0), t = d(() => N(c).length > 0);
				Ce(f, {
					get hasTimeline() {
						return N(e);
					},
					get hasNotes() {
						return N(t);
					}
				});
			}
			var p = n(f, 2), m = (e) => {
				Ee(e, {
					get timeline() {
						return N(o);
					},
					get playhead() {
						return N(u);
					},
					get follow() {
						return N(h);
					},
					onSelectBar: _
				});
			};
			H(p, (e) => {
				Y.strip && e(m);
			});
			var g = n(p, 2), x = (e) => {
				var t = rt(), i = U(t);
				Ke(i, {
					get phrases() {
						return N(l);
					},
					onSelectPhrase: y
				}), Ue(n(i, 2), {
					get notes() {
						return N(c);
					},
					get timeline() {
						return N(o);
					},
					get phrases() {
						return N(l);
					},
					get playhead() {
						return N(u);
					}
				}), r(e, t);
			};
			H(g, (e) => {
				Y.notes && e(x);
			});
			var C = n(g, 2), w = (e) => {
				tt(e, {
					get notes() {
						return N(c);
					},
					get phrases() {
						return N(l);
					},
					get playhead() {
						return N(u);
					}
				});
			};
			H(C, (e) => {
				Y.lyrics && e(w);
			});
			var D = n(C, 2), O = (e) => {
				ke(e, {
					get layers() {
						return N(a);
					},
					onLevelChanged: E
				});
			};
			H(D, (e) => {
				Y.faders && e(O);
			}), A(i), r(e, i);
		},
		$$slots: { default: !0 }
	}), w();
}
//#endregion
export { at as default };

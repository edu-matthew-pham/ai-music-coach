//#region frontend/node_modules/svelte/src/internal/shared/utils.js
var e = Array.isArray, t = Array.prototype.indexOf, n = Array.prototype.includes, r = Array.from, i = Object.defineProperty, a = Object.getOwnPropertyDescriptor, o = Object.prototype, s = Array.prototype, c = Object.getPrototypeOf, l = Object.isExtensible, u = () => {};
function d(e) {
	for (var t = 0; t < e.length; t++) e[t]();
}
function f() {
	var e, t;
	return {
		promise: new Promise((n, r) => {
			e = n, t = r;
		}),
		resolve: e,
		reject: t
	};
}
var p = 1024, m = 2048, h = 4096, g = 8192, _ = 16384, v = 32768, y = 1 << 25, ee = 65536, te = 1 << 19, ne = 1 << 20, re = 65536, ie = 1 << 21, ae = 1 << 22, oe = 1 << 23, se = Symbol("$state"), ce = Symbol("legacy props"), le = Symbol("attributes"), ue = Symbol("class"), de = Symbol("style"), fe = Symbol("text"), pe = new class extends Error {
	name = "StaleReactionError";
	message = "The reaction that called `getAbortSignal()` was re-run or destroyed";
}();
globalThis.document?.contentType;
function me(e) {
	throw Error("https://svelte.dev/e/lifecycle_outside_component");
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/errors.js
function he() {
	throw Error("https://svelte.dev/e/async_derived_orphan");
}
function ge(e) {
	throw Error("https://svelte.dev/e/effect_in_teardown");
}
function _e() {
	throw Error("https://svelte.dev/e/effect_in_unowned_derived");
}
function ve(e) {
	throw Error("https://svelte.dev/e/effect_orphan");
}
function ye() {
	throw Error("https://svelte.dev/e/effect_update_depth_exceeded");
}
function be(e) {
	throw Error("https://svelte.dev/e/props_invalid_value");
}
function xe() {
	throw Error("https://svelte.dev/e/state_descriptors_fixed");
}
function Se() {
	throw Error("https://svelte.dev/e/state_prototype_fixed");
}
function Ce() {
	throw Error("https://svelte.dev/e/state_unsafe_mutation");
}
function we() {
	throw Error("https://svelte.dev/e/svelte_boundary_reset_onerror");
}
//#endregion
//#region frontend/node_modules/svelte/src/constants.js
var b = Symbol("uninitialized");
function Te() {
	console.warn("https://svelte.dev/e/derived_inert");
}
function Ee() {
	console.warn("https://svelte.dev/e/svelte_boundary_reset_noop");
}
function De(e) {}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/reactivity/equality.js
function Oe(e) {
	return e === this.v;
}
function ke(e, t) {
	return e == e ? e !== t || typeof e == "object" && !!e || typeof e == "function" : t == t;
}
function Ae(e) {
	return !ke(e, this.v);
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/context.js
var x = null;
function S(e) {
	x = e;
}
function je(e, t = !1, n) {
	x = {
		p: x,
		i: !1,
		c: null,
		e: null,
		s: e,
		x: null,
		r: W,
		l: null
	};
}
function Me(e) {
	var t = x, n = t.e;
	if (n !== null) {
		t.e = null;
		for (var r of n) zt(r);
	}
	return e !== void 0 && (t.x = e), t.i = !0, x = t.p, e ?? {};
}
function C() {
	return !0;
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/dom/task.js
var w = [];
function Ne() {
	var e = w;
	w = [], d(e);
}
function T(e) {
	if (w.length === 0 && !st) {
		var t = w;
		queueMicrotask(() => {
			t === w && Ne();
		});
	}
	w.push(e);
}
function Pe(e) {
	var t = W;
	if (t === null) return V.f |= oe, e;
	if (!(t.f & 32768) && !(t.f & 4)) throw e;
	E(e, t);
}
function E(e, t) {
	if (!(t !== null && t.f & 16384)) {
		for (; t !== null;) {
			if (t.f & 128) {
				if (!(t.f & 32768)) throw e;
				try {
					t.b.error(e);
					return;
				} catch (t) {
					e = t;
				}
			}
			t = t.parent;
		}
		throw e;
	}
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/reactivity/status.js
var Fe = ~(m | h | p);
function D(e, t) {
	e.f = e.f & Fe | t;
}
function Ie(e) {
	e.f & 512 || e.deps === null ? D(e, p) : D(e, h);
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/reactivity/utils.js
function Le(e) {
	if (e !== null) for (let t of e) !(t.f & 2) || !(t.f & 65536) || (t.f ^= re, Le(t.deps));
}
function Re(e, t, n) {
	e.f & 2048 ? t.add(e) : e.f & 4096 && n.add(e), Le(e.deps), D(e, p);
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/reactivity/store.js
var ze = !1;
function Be(e) {
	var t = ze;
	try {
		return ze = !1, [e(), ze];
	} finally {
		ze = t;
	}
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/dom/elements/bindings/shared.js
function Ve(e) {
	var t = V, n = W;
	U(null), G(null);
	try {
		return e();
	} finally {
		U(t), G(n);
	}
}
//#endregion
//#region frontend/node_modules/svelte/src/reactivity/create-subscriber.js
function He(e) {
	let t = 0, n = bt(0), r;
	return () => {
		It() && ($(n), Ut(() => (t === 0 && (r = _n(() => e(() => I(n)))), t += 1, () => {
			T(() => {
				--t, t === 0 && (r?.(), r = void 0, I(n));
			});
		})));
	};
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/dom/blocks/boundary.js
var Ue = ee | te;
function We(e, t, n, r) {
	new Ge(e, t, n, r);
}
var Ge = class {
	parent;
	is_pending = !1;
	transform_error;
	#e;
	#t;
	#n;
	#r;
	#i = null;
	#a = null;
	#o = null;
	#s = null;
	#c = 0;
	#l = 0;
	#u = !1;
	#d = /* @__PURE__ */ new Set();
	#f = /* @__PURE__ */ new Set();
	#p = null;
	#m = He(() => (this.#p = bt(this.#c), () => {
		this.#p = null;
	}));
	constructor(e, t, n, r) {
		this.#e = e, this.#t = t, this.#n = (e) => {
			var t = W;
			t.b = this, t.f |= 128, n(e);
		}, this.parent = W.b, this.transform_error = r ?? this.parent?.transform_error ?? ((e) => e), this.#r = Gt(() => {
			this.#g();
		}, Ue);
	}
	#h(e) {
		var t = !1, n = !1;
		let r = () => {
			if (t) {
				Ee();
				return;
			}
			t = !0, n && we(), this.#o !== null && Qt(this.#o, () => {
				this.#o = null;
			}), this.#v(() => {
				this.#g();
			});
		};
		return {
			reset: r,
			invoke_onerror: () => {
				try {
					n = !0, this.#t.onerror?.(e, r), n = !1;
				} catch (e) {
					E(e, this.#r && this.#r.parent);
				}
			}
		};
	}
	#g() {
		try {
			if (this.is_pending = this.has_pending_snippet(), this.#l = 0, this.#c = 0, this.#i = Kt(() => {
				this.#n(this.#e);
			}), this.#l > 0) {
				var e = this.#s = document.createDocumentFragment();
				en(this.#i, e);
				let t = this.#t.pending;
				this.#a = Kt(() => t(this.#e));
			} else this.#_(k);
		} catch (e) {
			this.error(e);
		}
	}
	#_(e) {
		this.is_pending = !1, e.transfer_effects(this.#d, this.#f);
	}
	defer_effect(e) {
		Re(e, this.#d, this.#f);
	}
	is_rendered() {
		return !this.is_pending && (!this.parent || this.parent.is_rendered());
	}
	has_pending_snippet() {
		return !!this.#t.pending;
	}
	#v(e) {
		var t = W, n = V, r = x;
		G(this.#r), U(this.#r), S(this.#r.ctx);
		try {
			return ft.ensure(), e();
		} catch (e) {
			return Pe(e), null;
		} finally {
			G(t), U(n), S(r);
		}
	}
	#y(e, t) {
		if (!this.has_pending_snippet()) {
			this.parent && this.parent.#y(e, t);
			return;
		}
		this.#l += e, this.#l === 0 && (this.#_(t), this.#a && Qt(this.#a, () => {
			this.#a = null;
		}), this.#s &&= (this.#e.before(this.#s), null));
	}
	update_pending_count(e, t) {
		this.#y(e, t), this.#c += e, !(!this.#p || this.#u) && (this.#u = !0, T(() => {
			this.#u = !1, this.#p && xt(this.#p, this.#c);
		}));
	}
	get_effect_pending() {
		return this.#m(), $(this.#p);
	}
	error(e) {
		if (!this.#t.onerror && !this.#t.failed) throw e;
		k?.is_fork ? (this.#i && k.skip_effect(this.#i), this.#a && k.skip_effect(this.#a), this.#o && k.skip_effect(this.#o), k.oncommit(() => {
			this.#b(e);
		})) : this.#b(e);
	}
	#b(e) {
		this.#i &&= (z(this.#i), null), this.#a &&= (z(this.#a), null), this.#o &&= (z(this.#o), null);
		let t = this.#t.failed, n = (e) => {
			let { reset: n, invoke_onerror: r } = this.#h(e);
			r(), t && (this.#o = this.#v(() => {
				try {
					return Kt(() => {
						var r = W;
						r.b = this, r.f |= 128, t(this.#e, () => e, () => n);
					});
				} catch (e) {
					return E(e, this.#r.parent), null;
				}
			}));
		};
		T(() => {
			var t;
			try {
				t = this.transform_error(e);
			} catch (e) {
				E(e, this.#r && this.#r.parent);
				return;
			}
			typeof t == "object" && t && typeof t.then == "function" ? t.then(n, (e) => E(e, this.#r && this.#r.parent)) : n(t);
		});
	}
};
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/reactivity/async.js
function Ke(e, t, n, r) {
	let i = C() ? Xe : $e;
	var a = e.filter((e) => !e.settled), o = t.map(i);
	if (n.length === 0 && a.length === 0) {
		r(o);
		return;
	}
	var s = W, c = qe(), l = a.length === 1 ? a[0].promise : a.length > 1 ? Promise.all(a.map((e) => e.promise)) : null;
	function u(e) {
		if (!(s.f & 16384)) {
			c();
			try {
				r([...o, ...e]);
			} catch (e) {
				E(e, s);
			}
			Je();
		}
	}
	var d = Ye();
	if (n.length === 0) {
		l.then(() => u([])).finally(d);
		return;
	}
	function f() {
		Promise.all(n.map((e) => /* @__PURE__ */ Qe(e))).then(u).catch((e) => E(e, s)).finally(d);
	}
	l ? l.then(() => {
		c(), f(), Je();
	}) : f();
}
function qe() {
	var e = W, t = V, n = x, r = k;
	return function(i = !0) {
		G(e), U(t), S(n), i && !(e.f & 16384) && (r?.activate(), r?.apply());
	};
}
function Je(e = !0) {
	G(null), U(null), S(null), e && k?.deactivate();
}
function Ye() {
	var e = W, t = e.b, n = k, r = !!t?.is_rendered();
	return t?.update_pending_count(1, n), n.increment(r, e), () => {
		t?.update_pending_count(-1, n), n.decrement(r, e);
	};
}
/*#__NO_SIDE_EFFECTS__*/
function Xe(e) {
	var t = 2 | m;
	return W !== null && (W.f |= te), {
		ctx: x,
		deps: null,
		effects: null,
		equals: Oe,
		f: t,
		fn: e,
		reactions: null,
		rv: 0,
		v: b,
		wv: 0,
		parent: W,
		ac: null
	};
}
var Ze = Symbol("obsolete");
/*#__NO_SIDE_EFFECTS__*/
function Qe(e, t, n) {
	let r = W;
	r === null && he();
	var i = void 0, a = bt(b), o = !V, s = /* @__PURE__ */ new Set();
	return Ht(() => {
		var t = W, n = f();
		i = n.promise;
		try {
			Promise.resolve(e()).then(n.resolve, (e) => {
				e !== pe && n.reject(e);
			}).finally(Je);
		} catch (e) {
			n.reject(e), Je();
		}
		var c = k;
		if (o) {
			if (t.f & 32768) var l = Ye();
			if (r.b?.is_rendered()) c.async_deriveds.get(t)?.reject(Ze);
			else for (let e of s.values()) e.reject(Ze);
			s.add(n), c.async_deriveds.set(t, n);
		}
		let u = (e, t = void 0) => {
			l?.(), s.delete(n), t !== Ze && (c.activate(), t ? (a.f |= oe, xt(a, t)) : (a.f & 8388608 && (a.f ^= oe), xt(a, e)), c.deactivate());
		};
		n.promise.then(u, (e) => u(null, e || "unknown"));
	}), Lt(() => {
		for (let e of s) e.reject(Ze);
	}), new Promise((e) => {
		function t(n) {
			function r() {
				n === i ? e(a) : t(i);
			}
			n.then(r, r);
		}
		t(i);
	});
}
/*#__NO_SIDE_EFFECTS__*/
function $e(e) {
	let t = /* @__PURE__ */ Xe(e);
	return t.equals = Ae, t;
}
function et(e) {
	var t = e.effects;
	if (t !== null) {
		e.effects = null;
		for (var n = 0; n < t.length; n += 1) z(t[n]);
	}
}
function tt(e) {
	var t, n = W, r = e.parent;
	if (!B && r !== null && e.v !== b && r.f & 24576) return Te(), e.v;
	G(r);
	try {
		e.f &= ~re, et(e), t = fn(e);
	} finally {
		G(n);
	}
	return t;
}
function nt(e) {
	var t = tt(e);
	if (!e.equals(t) && (e.wv = ln(), (!k?.is_fork || e.deps === null) && (k === null ? e.v = t : (k.capture(e, t, !0), at?.capture(e, t, !0)), e.deps === null))) {
		D(e, p);
		return;
	}
	B || (A === null ? Ie(e) : (It() || k?.is_fork) && A.set(e, t));
}
function rt(e) {
	if (e.effects !== null) for (let t of e.effects) (t.teardown || t.ac) && (t.teardown?.(), t.ac !== null && Ve(() => {
		t.ac.abort(pe), t.ac = null;
	}), t.fn !== null && (t.teardown = u), mn(t, 0), Jt(t));
}
function it(e) {
	if (e.effects !== null) for (let t of e.effects) t.teardown && t.fn !== null && Q(t);
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/reactivity/batch.js
var O = null, k = null, at = null, A = null, ot = null, st = !1, ct = !1, j = null, lt = null, ut = 0, dt = 1, ft = class e {
	id = dt++;
	#e = !1;
	linked = !0;
	#t = null;
	#n = null;
	async_deriveds = /* @__PURE__ */ new Map();
	current = /* @__PURE__ */ new Map();
	previous = /* @__PURE__ */ new Map();
	#r = /* @__PURE__ */ new Set();
	#i = /* @__PURE__ */ new Set();
	#a = 0;
	#o = /* @__PURE__ */ new Map();
	#s = null;
	#c = [];
	#l = [];
	#u = /* @__PURE__ */ new Set();
	#d = /* @__PURE__ */ new Set();
	#f = /* @__PURE__ */ new Map();
	#p = /* @__PURE__ */ new Set();
	is_fork = !1;
	#m = !1;
	constructor() {
		O === null ? O = this : (O.#n = this, this.#t = O), O = this;
	}
	#h() {
		if (this.is_fork) return !0;
		for (let n of this.#o.keys()) {
			for (var e = n, t = !1; e.parent !== null;) {
				if (this.#f.has(e)) {
					t = !0;
					break;
				}
				e = e.parent;
			}
			if (!t) return !0;
		}
		return !1;
	}
	skip_effect(e) {
		this.#f.has(e) || this.#f.set(e, {
			d: [],
			m: []
		}), this.#p.delete(e);
	}
	unskip_effect(e, t = (e) => this.schedule(e)) {
		var n = this.#f.get(e);
		if (n) {
			this.#f.delete(e);
			for (var r of n.d) D(r, m), t(r);
			for (r of n.m) D(r, h), t(r);
		}
		this.#p.add(e);
	}
	#g() {
		this.#e = !0, ut++ > 1e3 && (this.#x(), pt());
		for (let e of this.#u) this.#d.delete(e), D(e, m), this.schedule(e);
		for (let e of this.#d) D(e, h), this.schedule(e);
		let t = this.#c;
		this.#c = [], this.apply();
		var n = j = [], r = [], i = lt = [];
		for (let e of t) try {
			this.#_(e, n, r);
		} catch (t) {
			throw _t(e), this.#h() || this.discard(), t;
		}
		if (k = null, i.length > 0) {
			var a = e.ensure();
			for (let e of i) a.schedule(e);
		}
		if (j = null, lt = null, this.#h()) {
			this.#b(r), this.#b(n);
			for (let [e, t] of this.#f) gt(e, t);
			i.length > 0 && k.#g();
			return;
		}
		let o = this.#v();
		if (o) {
			this.#b(r), this.#b(n), o.#y(this);
			return;
		}
		this.#u.clear(), this.#d.clear();
		for (let e of this.#r) e(this);
		this.#r.clear(), at = this, mt(r), mt(n), at = null, this.#s?.resolve();
		var s = k;
		if (this.#a === 0 && (this.#c.length === 0 || s !== null) && this.#x(), this.#c.length > 0) {
			if (s !== null) {
				let e = s;
				e.#c.push(...this.#c.filter((t) => !e.#c.includes(t)));
			} else s = this;
		}
		s !== null && s.#g();
	}
	#_(e, t, n) {
		e.f ^= p;
		for (var r = e.first; r !== null;) {
			var i = r.f, a = !!(i & 96);
			if (!(a && i & 1024 || i & 8192 || this.#f.has(r)) && r.fn !== null) {
				a ? r.f ^= p : i & 4 ? t.push(r) : un(r) && (i & 16 && this.#d.add(r), Q(r));
				var o = r.first;
				if (o !== null) {
					r = o;
					continue;
				}
			}
			for (; r !== null;) {
				var s = r.next;
				if (s !== null) {
					r = s;
					break;
				}
				r = r.parent;
			}
		}
	}
	#v() {
		for (var e = this.#t; e !== null;) {
			if (!e.is_fork) {
				for (let [t, [, n]] of this.current) if (e.current.has(t) && !n) return e;
			}
			e = e.#t;
		}
		return null;
	}
	#y(e) {
		for (let [t, n] of e.current) !this.previous.has(t) && e.previous.has(t) && this.previous.set(t, e.previous.get(t)), this.current.set(t, n);
		for (let [t, n] of e.async_deriveds) {
			let e = this.async_deriveds.get(t);
			e && n.promise.then(e.resolve).catch(e.reject);
		}
		e.async_deriveds.clear(), this.transfer_effects(e.#u, e.#d);
		let t = (e) => {
			var n = e.reactions;
			if (n !== null && !(e.f & 2 && !(e.f & 6144))) for (let e of n) {
				var r = e.f;
				if (r & 2) t(e);
				else {
					var i = e;
					r & 4194320 && !this.async_deriveds.has(i) && (this.#d.delete(i), D(i, m), this.schedule(i));
				}
			}
		};
		for (let e of this.current.keys()) t(e);
		this.oncommit(() => e.discard()), e.#x(), k = this, this.#g();
	}
	#b(e) {
		for (var t = 0; t < e.length; t += 1) Re(e[t], this.#u, this.#d);
	}
	capture(e, t, n = !1) {
		e.v !== b && !this.previous.has(e) && this.previous.set(e, e.v), e.f & 8388608 || (this.current.set(e, [t, n]), A?.set(e, t)), this.is_fork || (e.v = t);
	}
	activate() {
		k = this;
	}
	deactivate() {
		k = null, A = null;
	}
	flush() {
		try {
			ct = !0, k = this, this.#g();
		} finally {
			ut = 0, ot = null, j = null, lt = null, ct = !1, k = null, A = null, N.clear();
		}
	}
	discard() {
		for (let e of this.#i) e(this);
		this.#i.clear();
		for (let e of this.async_deriveds.values()) e.reject(Ze);
		this.#x(), this.#s?.resolve();
	}
	register_created_effect(e) {
		this.#l.push(e);
	}
	increment(e, t) {
		if (this.#a += 1, e) {
			let e = this.#o.get(t) ?? 0;
			this.#o.set(t, e + 1);
		}
	}
	decrement(e, t) {
		if (--this.#a, e) {
			let e = this.#o.get(t) ?? 0;
			e === 1 ? this.#o.delete(t) : this.#o.set(t, e - 1);
		}
		this.#m || (this.#m = !0, T(() => {
			this.#m = !1, this.linked && this.flush();
		}));
	}
	transfer_effects(e, t) {
		for (let t of e) this.#u.add(t);
		for (let e of t) this.#d.add(e);
		e.clear(), t.clear();
	}
	oncommit(e) {
		this.#r.add(e);
	}
	ondiscard(e) {
		this.#i.add(e);
	}
	settled() {
		return (this.#s ??= f()).promise;
	}
	static ensure() {
		if (k === null) {
			let t = k = new e();
			!ct && T(() => {
				t.#e || t.flush();
			});
		}
		return k;
	}
	apply() {
		A = null;
	}
	schedule(e) {
		if (ot = e, e.b?.is_pending && e.f & 16777228 && !(e.f & 32768)) {
			e.b.defer_effect(e);
			return;
		}
		for (var t = e; t.parent !== null;) {
			t = t.parent;
			var n = t.f;
			if (j !== null && t === W && (V === null || !(V.f & 2))) return;
			if (n & 96) {
				if (!(n & 1024)) return;
				t.f ^= p;
			}
		}
		this.#c.push(t);
	}
	#x() {
		if (this.linked) {
			var e = this.#t, t = this.#n;
			e === null || (e.#n = t), t === null ? O = e : t.#t = e, this.linked = !1;
		}
	}
};
function pt() {
	try {
		ye();
	} catch (e) {
		E(e, ot);
	}
}
var M = null;
function mt(e) {
	var t = e.length;
	if (t !== 0) {
		for (var n = 0; n < t;) {
			var r = e[n++];
			if (!(r.f & 24576) && un(r) && (M = /* @__PURE__ */ new Set(), Q(r), r.deps === null && r.first === null && r.nodes === null && r.teardown === null && r.ac === null && Zt(r), M?.size > 0)) {
				N.clear();
				for (let e of M) {
					if (e.f & 24576) continue;
					let t = [e], n = e.parent;
					for (; n !== null;) M.has(n) && (M.delete(n), t.push(n)), n = n.parent;
					for (let e = t.length - 1; e >= 0; e--) {
						let n = t[e];
						n.f & 24576 || Q(n);
					}
				}
				M.clear();
			}
		}
		M = null;
	}
}
function ht(e) {
	k.schedule(e);
}
function gt(e, t) {
	if (!(e.f & 32 && e.f & 1024)) {
		e.f & 2048 ? t.d.push(e) : e.f & 4096 && t.m.push(e), D(e, p);
		for (var n = e.first; n !== null;) gt(n, t), n = n.next;
	}
}
function _t(e) {
	D(e, p);
	for (var t = e.first; t !== null;) _t(t), t = t.next;
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/reactivity/sources.js
var vt = /* @__PURE__ */ new Set(), N = /* @__PURE__ */ new Map(), yt = !1;
function bt(e, t) {
	return {
		f: 0,
		v: e,
		reactions: null,
		equals: Oe,
		rv: 0,
		wv: 0
	};
}
/*#__NO_SIDE_EFFECTS__*/
function P(e, t) {
	let n = bt(e, t);
	return an(n), n;
}
function F(e, t, n = !1) {
	return V !== null && (!H || V.f & 131072) && C() && V.f & 4325394 && (K === null || !K.has(e)) && Ce(), xt(e, n ? L(t) : t, lt);
}
function xt(e, t, n = null) {
	if (!e.equals(t)) {
		N.set(e, B ? t : e.v);
		var r = ft.ensure();
		if (r.capture(e, t), e.f & 2) {
			let t = e;
			e.f & 2048 && tt(t), A === null && Ie(t);
		}
		e.wv = ln(), Ct(e, m, n), C() && W !== null && W.f & 1024 && !(W.f & 96) && (Y === null ? on([e]) : Y.push(e)), !r.is_fork && vt.size > 0 && !yt && St();
	}
	return t;
}
function St() {
	yt = !1;
	for (let e of vt) {
		e.f & 1024 && D(e, h);
		let t;
		try {
			t = un(e);
		} catch {
			t = !0;
		}
		t && Q(e);
	}
	vt.clear();
}
function I(e) {
	F(e, e.v + 1);
}
function Ct(e, t, n) {
	var r = e.reactions;
	if (r !== null) for (var i = C(), a = r.length, o = 0; o < a; o++) {
		var s = r[o], c = s.f;
		if (!(!i && s === W)) {
			var l = (c & m) === 0;
			if (l && D(s, t), c & 131072) vt.add(s);
			else if (c & 2) {
				var u = s;
				A?.delete(u), c & 65536 || (c & 512 && (W === null || !(W.f & 2097152)) && (s.f |= re), Ct(u, h, n));
			} else if (l) {
				var d = s;
				c & 16 && M !== null && M.add(d), n === null ? ht(d) : n.push(d);
			}
		}
	}
}
function L(t) {
	if (typeof t != "object" || !t || se in t) return t;
	let n = c(t);
	if (n !== o && n !== s) return t;
	var r = /* @__PURE__ */ new Map(), i = e(t), l = /* @__PURE__ */ P(0), u = null, d = Z, f = (e) => {
		if (Z === d) return e();
		var t = V, n = Z;
		U(null), cn(d);
		var r = e();
		return U(t), cn(n), r;
	};
	return i && r.set("length", /* @__PURE__ */ P(t.length, u)), new Proxy(t, {
		defineProperty(e, t, n) {
			(!("value" in n) || n.configurable === !1 || n.enumerable === !1 || n.writable === !1) && xe();
			var i = r.get(t);
			return i === void 0 ? f(() => {
				var e = /* @__PURE__ */ P(n.value, u);
				return r.set(t, e), e;
			}) : F(i, n.value, !0), !0;
		},
		deleteProperty(e, t) {
			var n = r.get(t);
			if (n === void 0) {
				if (t in e) {
					let e = f(() => /* @__PURE__ */ P(b, u));
					r.set(t, e), I(l);
				}
			} else F(n, b), I(l);
			return !0;
		},
		get(e, n, i) {
			if (n === se) return t;
			var o = r.get(n), s = n in e;
			if (o === void 0 && (!s || a(e, n)?.writable) && (o = f(() => /* @__PURE__ */ P(L(s ? e[n] : b), u)), r.set(n, o)), o !== void 0) {
				var c = $(o);
				return c === b ? void 0 : c;
			}
			return Reflect.get(e, n, i);
		},
		getOwnPropertyDescriptor(e, t) {
			var n = Reflect.getOwnPropertyDescriptor(e, t);
			if (n && "value" in n) {
				var i = r.get(t);
				i && (n.value = $(i));
			} else if (n === void 0) {
				var a = r.get(t), o = a?.v;
				if (a !== void 0 && o !== b) return {
					enumerable: !0,
					configurable: !0,
					value: o,
					writable: !0
				};
			}
			return n;
		},
		has(e, t) {
			if (t === se) return !0;
			var n = r.get(t), i = n !== void 0 && n.v !== b || Reflect.has(e, t);
			return (n !== void 0 || W !== null && (!i || a(e, t)?.writable)) && (n === void 0 && (n = f(() => /* @__PURE__ */ P(i ? L(e[t]) : b, u)), r.set(t, n)), $(n) === b) ? !1 : i;
		},
		set(e, t, n, o) {
			var s = r.get(t), c = t in e;
			if (i && t === "length") for (var d = n; d < s.v; d += 1) {
				var p = r.get(d + "");
				p === void 0 ? d in e && (p = f(() => /* @__PURE__ */ P(b, u)), r.set(d + "", p)) : F(p, b);
			}
			if (s === void 0) (!c || a(e, t)?.writable) && (s = f(() => /* @__PURE__ */ P(void 0, u)), F(s, L(n)), r.set(t, s));
			else {
				c = s.v !== b;
				var m = f(() => L(n));
				F(s, m);
			}
			var h = Reflect.getOwnPropertyDescriptor(e, t);
			if (h?.set && h.set.call(o, n), !c) {
				if (i && typeof t == "string") {
					var g = r.get("length"), _ = Number(t);
					Number.isInteger(_) && _ >= g.v && F(g, _ + 1);
				}
				I(l);
			}
			return !0;
		},
		ownKeys(e) {
			$(l);
			var t = Reflect.ownKeys(e).filter((e) => {
				var t = r.get(e);
				return t === void 0 || t.v !== b;
			});
			for (var [n, i] of r) i.v !== b && !(n in e) && t.push(n);
			return t;
		},
		setPrototypeOf() {
			Se();
		}
	});
}
var wt, Tt, Et, Dt;
function Ot() {
	if (wt === void 0) {
		wt = window, Tt = /Firefox/.test(navigator.userAgent);
		var e = Element.prototype, t = Node.prototype, n = Text.prototype;
		Et = a(t, "firstChild").get, Dt = a(t, "nextSibling").get, l(e) && (e[ue] = void 0, e[le] = null, e[de] = void 0, e.__e = void 0), l(n) && (n[fe] = void 0);
	}
}
function kt(e = "") {
	return document.createTextNode(e);
}
/*@__NO_SIDE_EFFECTS__*/
function At(e) {
	return Et.call(e);
}
/*@__NO_SIDE_EFFECTS__*/
function jt(e) {
	return Dt.call(e);
}
function Mt(e, t) {
	return /* @__PURE__ */ At(e);
}
function Nt(e, t, n) {
	return t == null || t === "http://www.w3.org/1999/xhtml" ? n ? document.createElement(e, { is: n }) : document.createElement(e) : n ? document.createElementNS(t, e, { is: n }) : document.createElementNS(t, e);
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/reactivity/effects.js
function Pt(e) {
	W === null && (V === null && ve(e), _e()), B && ge(e);
}
function Ft(e, t) {
	var n = t.last;
	n === null ? t.last = t.first = e : (n.next = e, e.prev = n, t.last = e);
}
function R(e, t) {
	var n = W;
	n !== null && n.f & 8192 && (e |= g);
	var r = {
		ctx: x,
		deps: null,
		nodes: null,
		f: e | m | 512,
		first: null,
		fn: t,
		last: null,
		next: null,
		parent: n,
		b: n && n.b,
		prev: null,
		teardown: null,
		wv: 0,
		ac: null
	};
	k?.register_created_effect(r);
	var i = r;
	if (e & 4) j === null ? ft.ensure().schedule(r) : j.push(r);
	else if (t !== null) {
		try {
			Q(r);
		} catch (e) {
			throw z(r), e;
		}
		i.deps === null && i.teardown === null && i.nodes === null && i.first === i.last && !(i.f & 524288) && (i = i.first, e & 16 && e & 65536 && i !== null && (i.f |= ee));
	}
	if (i !== null && (i.parent = n, n !== null && Ft(i, n), V !== null && V.f & 2 && !(e & 64))) {
		var a = V;
		(a.effects ??= []).push(i);
	}
	return r;
}
function It() {
	return V !== null && !H;
}
function Lt(e) {
	let t = R(8, null);
	return D(t, p), t.teardown = e, t;
}
function Rt(e) {
	Pt("$effect");
	var t = W.f;
	if (!V && t & 32 && x !== null && !x.i) {
		var n = x;
		(n.e ??= []).push(e);
	} else return zt(e);
}
function zt(e) {
	return R(4 | ne, e);
}
function Bt(e) {
	ft.ensure();
	let t = R(64 | te, e);
	return (e = {}) => new Promise((n) => {
		e.outro ? Qt(t, () => {
			z(t), n(void 0);
		}) : (z(t), n(void 0));
	});
}
function Vt(e) {
	return R(4, e);
}
function Ht(e) {
	return R(ae | te, e);
}
function Ut(e, t = 0) {
	return R(8 | t, e);
}
function Wt(e, t = [], n = [], r = []) {
	Ke(r, t, n, (t) => {
		R(8, () => {
			e(...t.map($));
		});
	});
}
function Gt(e, t = 0) {
	return R(16 | t, e);
}
function Kt(e) {
	return R(32 | te, e);
}
function qt(e) {
	var t = e.teardown;
	if (t !== null) {
		let e = B, n = V;
		rn(!0), U(null);
		try {
			t.call(null);
		} finally {
			rn(e), U(n);
		}
	}
}
function Jt(e, t = !1) {
	var n = e.first;
	for (e.first = e.last = null; n !== null;) {
		let e = n.ac;
		e !== null && Ve(() => {
			e.abort(pe);
		});
		var r = n.next;
		n.f & 64 ? n.parent = null : z(n, t), n = r;
	}
}
function Yt(e) {
	for (var t = e.first; t !== null;) {
		var n = t.next;
		t.f & 32 || z(t), t = n;
	}
}
function z(e, t = !0) {
	var n = !1;
	(t || e.f & 262144) && e.nodes !== null && e.nodes.end !== null && (Xt(e.nodes.start, e.nodes.end), n = !0), e.f |= y, Jt(e, t && !n), mn(e, 0);
	var r = e.nodes && e.nodes.t;
	if (r !== null) for (let e of r) e.stop();
	qt(e), e.f ^= y, e.f |= _;
	var i = e.parent;
	i !== null && i.first !== null && Zt(e), e.next = e.prev = e.teardown = e.ctx = e.deps = e.fn = e.nodes = e.ac = e.b = null;
}
function Xt(e, t) {
	for (; e !== null;) {
		var n = e === t ? null : /* @__PURE__ */ jt(e);
		e.remove(), e = n;
	}
}
function Zt(e) {
	var t = e.parent, n = e.prev, r = e.next;
	n !== null && (n.next = r), r !== null && (r.prev = n), t !== null && (t.first === e && (t.first = r), t.last === e && (t.last = n));
}
function Qt(e, t, n = !0) {
	var r = [];
	$t(e, r, !0);
	var i = () => {
		n && z(e), t && t();
	}, a = r.length;
	if (a > 0) {
		var o = () => --a || i();
		for (var s of r) s.out(o);
	} else i();
}
function $t(e, t, n) {
	if (!(e.f & 8192)) {
		e.f ^= g;
		var r = e.nodes && e.nodes.t;
		if (r !== null) for (let e of r) (e.is_global || n) && t.push(e);
		for (var i = e.first; i !== null;) {
			var a = i.next;
			if (!(i.f & 64)) {
				var o = !!(i.f & 65536) || !!(i.f & 32) && !!(e.f & 16);
				$t(i, t, o ? n : !1);
			}
			i = a;
		}
	}
}
function en(e, t) {
	if (e.nodes) for (var n = e.nodes.start, r = e.nodes.end; n !== null;) {
		var i = n === r ? null : /* @__PURE__ */ jt(n);
		t.append(n), n = i;
	}
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/legacy.js
var tn = null, nn = !1, B = !1;
function rn(e) {
	B = e;
}
var V = null, H = !1;
function U(e) {
	V = e;
}
var W = null;
function G(e) {
	W = e;
}
var K = null;
function an(e) {
	V !== null && (K ??= /* @__PURE__ */ new Set()).add(e);
}
var q = null, J = 0, Y = null;
function on(e) {
	Y = e;
}
var sn = 1, X = 0, Z = X;
function cn(e) {
	Z = e;
}
function ln() {
	return ++sn;
}
function un(e) {
	var t = e.f;
	if (t & 2048) return !0;
	if (t & 2 && (e.f &= ~re), t & 4096) {
		for (var n = e.deps, r = n.length, i = 0; i < r; i++) {
			var a = n[i];
			if (un(a) && nt(a), a.wv > e.wv) return !0;
		}
		t & 512 && A === null && D(e, p);
	}
	return !1;
}
function dn(e, t, n = !0) {
	var r = e.reactions;
	if (r !== null && !(K !== null && K.has(e))) for (var i = 0; i < r.length; i++) {
		var a = r[i];
		a.f & 2 ? dn(a, t, !1) : t === a && (n ? D(a, m) : a.f & 1024 && D(a, h), ht(a));
	}
}
function fn(e) {
	var t = q, n = J, r = Y, i = V, a = K, o = x, s = H, c = Z, l = e.f;
	q = null, J = 0, Y = null, V = l & 96 ? null : e, K = null, S(e.ctx), H = !1, Z = ++X, e.ac !== null && (Ve(() => {
		e.ac.abort(pe);
	}), e.ac = null);
	try {
		e.f |= ie;
		var u = e.fn, d = u();
		e.f |= v;
		var f = e.deps, p = k?.is_fork;
		if (q !== null) {
			var m;
			if (p || mn(e, J), f !== null && J > 0) for (f.length = J + q.length, m = 0; m < q.length; m++) f[J + m] = q[m];
			else e.deps = f = q;
			if (It() && e.f & 512) for (m = J; m < f.length; m++) (f[m].reactions ??= []).push(e);
		} else !p && f !== null && J < f.length && (mn(e, J), f.length = J);
		if (C() && Y !== null && !H && f !== null && !(e.f & 6146)) for (m = 0; m < Y.length; m++) dn(Y[m], e);
		if (i !== null && i !== e) {
			if (X++, i.deps !== null) for (let e = 0; e < n; e += 1) i.deps[e].rv = X;
			if (t !== null) for (let e of t) e.rv = X;
			Y !== null && (r === null ? r = Y : r.push(...Y));
		}
		return e.f & 8388608 && (e.f ^= oe), d;
	} catch (e) {
		return Pe(e);
	} finally {
		e.f ^= ie, q = t, J = n, Y = r, V = i, K = a, S(o), H = s, Z = c;
	}
}
function pn(e, r) {
	let i = r.reactions;
	if (i !== null) {
		var a = t.call(i, e);
		if (a !== -1) {
			var o = i.length - 1;
			o === 0 ? i = r.reactions = null : (i[a] = i[o], i.pop());
		}
	}
	if (i === null && r.f & 2 && (q === null || !n.call(q, r))) {
		var s = r;
		s.f & 512 && (s.f ^= 512, s.f &= ~re), s.v !== b && Ie(s), s.ac !== null && Ve(() => {
			s.ac.abort(pe), s.ac = null, D(s, m);
		}), rt(s), mn(s, 0);
	}
}
function mn(e, t) {
	var n = e.deps;
	if (n !== null) for (var r = t; r < n.length; r++) pn(e, n[r]);
}
function Q(e) {
	var t = e.f;
	if (!(t & 16384)) {
		D(e, p);
		var n = W, r = nn;
		W = e, nn = !(t & 96);
		try {
			t & 16777232 ? Yt(e) : Jt(e), qt(e);
			var i = fn(e);
			e.teardown = typeof i == "function" ? i : null, e.wv = sn;
		} finally {
			nn = r, W = n;
		}
	}
}
function $(e) {
	var t = !!(e.f & 2);
	if (tn?.add(e), V !== null && !H && !(W !== null && W.f & 16384) && (K === null || !K.has(e))) {
		var r = V.deps;
		if (V.f & 2097152) e.rv < X && (e.rv = X, q === null && r !== null && r[J] === e ? J++ : q === null ? q = [e] : q.push(e));
		else {
			V.deps ??= [], n.call(V.deps, e) || V.deps.push(e);
			var i = e.reactions;
			i === null ? e.reactions = [V] : n.call(i, V) || i.push(V);
		}
	}
	if (B && N.has(e)) return N.get(e);
	if (t) {
		var a = e;
		if (B) {
			var o = a.v;
			return (!(a.f & 1024) && a.reactions !== null || gn(a)) && (o = tt(a)), N.set(a, o), o;
		}
		var s = !(a.f & 512) && !H && V !== null && (nn || !!(V.f & 512)), c = (a.f & v) === 0;
		un(a) && (s && (a.f |= 512), nt(a)), s && !c && (it(a), hn(a));
	}
	if (A?.has(e)) return A.get(e);
	if (e.f & 8388608) throw e.v;
	return e.v;
}
function hn(e) {
	if (e.f |= 512, e.deps !== null) for (let t of e.deps) (t.reactions ??= []).push(e), t.f & 2 && !(t.f & 512) && (it(t), hn(t));
}
function gn(e) {
	if (e.v === b) return !0;
	if (e.deps === null) return !1;
	for (let t of e.deps) if (N.has(t) || t.f & 2 && gn(t)) return !0;
	return !1;
}
function _n(e) {
	var t = H;
	try {
		return H = !0, e();
	} finally {
		H = t;
	}
}
[.../* @__PURE__ */ "allowfullscreen.async.autofocus.autoplay.checked.controls.default.disabled.formnovalidate.indeterminate.inert.ismap.loop.multiple.muted.nomodule.novalidate.open.playsinline.readonly.required.reversed.seamless.selected.webkitdirectory.defer.disablepictureinpicture.disableremoteplayback".split(".")];
var vn = ["touchstart", "touchmove"];
function yn(e) {
	return vn.includes(e);
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/dom/elements/events.js
var bn = Symbol("events"), xn = /* @__PURE__ */ new Set(), Sn = /* @__PURE__ */ new Set(), Cn = null;
function wn(e) {
	var t = this, n = t.ownerDocument, r = e.type, a = e.composedPath?.() || [], o = a[0] || e.target;
	Cn = e;
	var s = 0, c = Cn === e && e[bn];
	if (c) {
		var l = a.indexOf(c);
		if (l !== -1 && (t === document || t === window)) {
			e[bn] = t;
			return;
		}
		var u = a.indexOf(t);
		if (u === -1) return;
		l <= u && (s = l);
	}
	if (o = a[s] || e.target, o !== t) {
		i(e, "currentTarget", {
			configurable: !0,
			get() {
				return o || n;
			}
		});
		var d = V, f = W;
		U(null), G(null);
		try {
			for (var p, m = []; o !== null && o !== t;) {
				try {
					var h = o[bn]?.[r];
					h != null && (!o.disabled || e.target === o) && h.call(o, e);
				} catch (e) {
					p ? m.push(e) : p = e;
				}
				if (e.cancelBubble) break;
				s++, o = s < a.length ? a[s] : null;
			}
			if (p) {
				for (let e of m) queueMicrotask(() => {
					throw e;
				});
				throw p;
			}
		} finally {
			e[bn] = t, delete e.currentTarget, U(d), G(f);
		}
	}
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/dom/reconciler.js
var Tn = globalThis?.window?.trustedTypes && /* @__PURE__ */ globalThis.window.trustedTypes.createPolicy("svelte-trusted-html", { createHTML: (e) => e });
function En(e) {
	return Tn?.createHTML(e) ?? e;
}
function Dn(e) {
	var t = Nt("template");
	return t.innerHTML = En(e.replaceAll("<!>", "<!---->")), t.content;
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/dom/template.js
function On(e, t) {
	var n = W;
	n.nodes === null && (n.nodes = {
		start: e,
		end: t,
		a: null,
		t: null
	});
}
/*#__NO_SIDE_EFFECTS__*/
function kn(e, t) {
	var n = !!(t & 1), r = !!(t & 2), i, a = !e.startsWith("<!>");
	return () => {
		i === void 0 && (i = Dn(a ? e : "<!>" + e), n || (i = /* @__PURE__ */ At(i)));
		var t = r || Tt ? document.importNode(i, !0) : i.cloneNode(!0);
		if (n) {
			var o = /* @__PURE__ */ At(t), s = t.lastChild;
			On(o, s);
		} else On(t, t);
		return t;
	};
}
function An(e, t) {
	e !== null && e.before(t);
}
function jn(e, t) {
	var n = t == null ? "" : typeof t == "object" ? `${t}` : t;
	n !== (e[fe] ??= e.nodeValue) && (e[fe] = n, e.nodeValue = `${n}`);
}
function Mn(e, t) {
	return Pn(e, t);
}
var Nn = /* @__PURE__ */ new Map();
function Pn(e, { target: t, anchor: n, props: i = {}, events: a, context: o, intro: s = !0, transformError: c }) {
	Ot();
	var l = void 0, u = Bt(() => {
		var s = n ?? t.appendChild(kt());
		We(s, { pending: () => {} }, (t) => {
			je({});
			var n = x;
			o && (n.c = o), a && (i.$$events = a), l = e(t, i) || {}, Me();
		}, c);
		var u = /* @__PURE__ */ new Set(), d = (e) => {
			for (var n = 0; n < e.length; n++) {
				var r = e[n];
				if (!u.has(r)) {
					u.add(r);
					var i = yn(r);
					for (let e of [t, document]) {
						var a = Nn.get(e);
						a === void 0 && (a = /* @__PURE__ */ new Map(), Nn.set(e, a));
						var o = a.get(r);
						o === void 0 ? (e.addEventListener(r, wn, { passive: i }), a.set(r, 1)) : a.set(r, o + 1);
					}
				}
			}
		};
		return d(r(xn)), Sn.add(d), () => {
			for (var e of u) for (let n of [t, document]) {
				var r = Nn.get(n), i = r.get(e);
				--i == 0 ? (n.removeEventListener(e, wn), r.delete(e), r.size === 0 && Nn.delete(n)) : r.set(e, i);
			}
			Sn.delete(d), s !== n && s.parentNode?.removeChild(s);
		};
	});
	return Fn.set(l, u), l;
}
var Fn = /* @__PURE__ */ new WeakMap();
function In(e, t) {
	let n = Fn.get(e);
	return n ? (Fn.delete(e), n(t)) : Promise.resolve();
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/shared/attributes.js
var Ln = [..." 	\n\r\f\xA0\v﻿"];
function Rn(e, t, n) {
	var r = e == null ? "" : "" + e;
	if (t && (r = r ? r + " " + t : t), n) {
		for (var i of Object.keys(n)) if (n[i]) r = r ? r + " " + i : i;
		else if (r.length) for (var a = i.length, o = 0; (o = r.indexOf(i, o)) >= 0;) {
			var s = o + a;
			(o === 0 || Ln.includes(r[o - 1])) && (s === r.length || Ln.includes(r[s])) ? r = (o === 0 ? "" : r.substring(0, o)) + r.substring(s + 1) : o = s;
		}
	}
	return r === "" ? null : r;
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/dom/elements/class.js
function zn(e, t, n, r, i, a) {
	var o = e[ue];
	if (o !== n || o === void 0) {
		var s = Rn(n, r, a);
		s == null ? e.removeAttribute("class") : t ? e.className = s : e.setAttribute("class", s), e[ue] = n;
	} else if (a && i !== a) for (var c in a) {
		var l = !!a[c];
		(i == null || l !== !!i[c]) && e.classList.toggle(c, l);
	}
	return a;
}
var Bn = /* @__PURE__ */ new class e {
	#e = /* @__PURE__ */ new WeakMap();
	#t;
	#n;
	static entries = /* @__PURE__ */ new WeakMap();
	constructor(e) {
		this.#n = e;
	}
	observe(e, t) {
		var n = this.#e.get(e) || /* @__PURE__ */ new Set();
		return n.add(t), this.#e.set(e, n), this.#r().observe(e, this.#n), () => {
			var n = this.#e.get(e);
			n.delete(t), n.size === 0 && (this.#e.delete(e), this.#t.unobserve(e));
		};
	}
	#r() {
		return this.#t ??= new ResizeObserver((t) => {
			for (var n of t) {
				e.entries.set(n.target, n);
				for (var r of this.#e.get(n.target) || []) r(n);
			}
		});
	}
}({ box: "border-box" });
function Vn(e, t, n) {
	var r = Bn.observe(e, () => n(e[t]));
	Vt(() => (_n(() => n(e[t])), r));
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/dom/elements/bindings/this.js
function Hn(e, t) {
	return e === t || e?.[se] === t;
}
function Un(e = {}, t, n, r) {
	var i = x.r, a = W;
	return Vt(() => {
		var o, s;
		return Ut(() => {
			o = s, s = r?.() || [], _n(() => {
				Hn(n(...s), e) || (t(e, ...s), o && Hn(n(...o), e) && t(null, ...o));
			});
		}), () => {
			let r = a;
			for (; r !== i && r.parent !== null && r.parent.f & 33554432;) r = r.parent;
			let o = () => {
				s && Hn(n(...s), e) && t(null, ...s);
			}, c = r.teardown;
			r.teardown = () => {
				o(), c?.();
			};
		};
	}), e;
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/reactivity/props.js
function Wn(e, t, n, r) {
	var i = !0, o = !!(n & 8), s = !!(n & 16), c = r, l = !0, u = void 0, d = () => s && i ? (u ??= /* @__PURE__ */ Xe(r), $(u)) : (l && (l = !1, c = s ? _n(r) : r), c);
	let f;
	if (o) {
		var p = se in e || ce in e;
		f = a(e, t)?.set ?? (p && t in e ? (n) => e[t] = n : void 0);
	}
	var m, h = !1;
	o ? [m, h] = Be(() => e[t]) : m = e[t], m === void 0 && r !== void 0 && (m = d(), f && (i && be(t), f(m)));
	var g = i ? () => {
		var n = e[t];
		return n === void 0 ? d() : (l = !0, n);
	} : () => {
		var n = e[t];
		return n !== void 0 && (c = void 0), n === void 0 ? c : n;
	};
	if (i && !(n & 4)) return g;
	if (f) {
		var _ = e.$$legacy;
		return (function(e, t) {
			return arguments.length > 0 ? ((!i || !t || _ || h) && f(t ? g() : e), e) : g();
		});
	}
	var v = !1, y = (n & 1 ? Xe : $e)(() => (v = !1, g()));
	o && $(y);
	var ee = W;
	return (function(e, t) {
		if (arguments.length > 0) {
			let n = t ? $(y) : i && o ? L(e) : e;
			return F(y, n), v = !0, c !== void 0 && (c = n), e;
		}
		return B && v || ee.f & 16384 ? y.v : $(y);
	});
}
function Gn(e) {
	x === null && me("onMount"), Rt(() => {
		let t = _n(e);
		if (typeof t == "function") return t;
	});
}
//#endregion
export { je as _, zn as a, In as c, $ as d, Wt as f, Me as g, P as h, Vn as i, An as l, F as m, Wn as n, Mn as o, Mt as p, Un as r, jn as s, Gn as t, kn as u, De as v };

import { _ as e, a as t, d as n, f as r, g as i, h as a, i as o, l as s, m as c, n as l, p as u, r as d, s as f, t as p, u as m, v as h } from "./index-client-DzEV2yJg.js";
//#region frontend/Example.svelte
var g = m("<div> </div>");
function _(m, _) {
	e(_, !0);
	let v = l(_, "selected", 3, !1), y = a(0), b = a(void 0);
	function x(e, t) {
		e.style.setProperty("--local-text-width", `${t && t < 150 ? t : 200}px`), e.style.whiteSpace = "unset";
	}
	function S(e, t = 60) {
		if (!e) return "";
		let n = String(e);
		return n.length <= t ? n : n.slice(0, t) + "...";
	}
	p(() => {
		n(b) && x(n(b), n(y));
	});
	var C = g();
	let w;
	var T = u(C, !0);
	h(C), d(C, (e) => c(b, e), () => n(b)), r((e) => {
		w = t(C, 1, "svelte-s3apn9", null, w, {
			table: _.type === "table",
			gallery: _.type === "gallery",
			selected: v()
		}), f(T, e);
	}, [() => S(_.value)]), o(C, "clientWidth", (e) => c(y, e)), s(m, C), i();
}
//#endregion
export { _ as default };

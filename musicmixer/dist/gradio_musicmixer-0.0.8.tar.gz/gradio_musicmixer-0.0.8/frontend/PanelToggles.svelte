<script lang="ts">
	import { panels } from "./mixerPanels.svelte";

	interface Props {
		hasTimeline: boolean;
		hasNotes: boolean;
		hasDiagrams: boolean;
	}

	let { hasTimeline, hasNotes, hasDiagrams }: Props = $props();
</script>

<div class="panel-toggles">
	{#if hasTimeline}
		<label class="panel-toggle">
			<input type="checkbox" bind:checked={panels.strip} />
			Chart
		</label>
	{/if}
	{#if hasNotes}
		<label class="panel-toggle">
			<input type="checkbox" bind:checked={panels.phrases} />
			Phrases
		</label>
		<label class="panel-toggle">
			<input type="checkbox" bind:checked={panels.notes} />
			Visual notes
		</label>
		<label class="panel-toggle">
			<input type="checkbox" bind:checked={panels.lyrics} />
			Lyrics
		</label>
	{/if}
	<label class="panel-toggle">
		<input type="checkbox" bind:checked={panels.faders} />
		Mixer
	</label>
	{#if hasDiagrams}
		<label class="panel-toggle">
			<input type="checkbox" bind:checked={panels.instruments} />
			Instruments
		</label>
	{/if}
</div>
<style>
	.panel-toggles {
		display: flex;
		flex-wrap: wrap;
		align-items: center;
		gap: 14px;
	}
	.panel-toggle {
		font-size: 12px;
		color: var(--body-text-color-subdued);
		display: flex;
		align-items: center;
		gap: 4px;
		cursor: pointer;
	}
	.panel-toggle input[type="checkbox"] {
		appearance: auto;
		accent-color: #607d8b;
		width: 13px;
		height: 13px;
	}
</style>